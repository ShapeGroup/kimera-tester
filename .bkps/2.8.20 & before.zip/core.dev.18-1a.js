


const ui = (() => {

        console.log('yooo');
        Image.prototype.load = function( url, callback ) {

            var img = this, xmlHTTP = new XMLHttpRequest();
        
            img.completedPercentage = 0;
        
            xmlHTTP.open( 'GET', url , true );
            xmlHTTP.responseType = 'arraybuffer';
            xmlHTTP.crossOrigin  = 'Anonymous';
        
            xmlHTTP.onload = function( e )
            {
                let imgblob = new Blob([xmlHTTP.response]),
                    makeurl = window.URL || window.webkitURL;

                img.src = makeurl.createObjectURL( imgblob );
                if ( callback ) callback( this );

            };
        
            xmlHTTP.onprogress = function( e ) {
                if ( e.lengthComputable ) img.completedPercentage = parseInt( ( e.loaded / e.total ) * 100 );
                // Update your progress bar here. Make sure to check if the progress value
                // has changed to avoid spamming the DOM.
                // Something like: 
                // if ( prevValue != thisImage completedPercentage ) display_progress();
            };
        
            xmlHTTP.onloadstart = function() {
                // Display your progress bar here, starting at 0
                img.completedPercentage = 0;
            };
        
            xmlHTTP.onloadend = function() {
                // You can also remove your progress bar here, if you like.
                img.completedPercentage = 100;
            }
        
            xmlHTTP.send();
        };


        // Image.prototype.load = function(url){
        // 
        //     let This = this, xmlHTTP = new XMLHttpRequest();
        // 
        //     xmlHTTP.open('GET',url,true);
        // 
        //     xmlHTTP.crossOrigin  = 'Anonymous';
        //     xmlHTTP.responseType = 'arraybuffer';
        // 
        //     xmlHTTP.onload = function(e) {
        //         let blob = new Blob([This.response]), makeurl = window.URL || window.webkitURL;
        //         This.src = makeurl.createObjectURL(blob);
        //         This.result = true;
        //     };
        // 
        //     xmlHTTP.onprogress = function(e) {
        //         This.percent  = ( e.lengthComputable ) ? parseInt((e.loaded / e.total) * 100) : 0;
        //     };
        // 
        //     xmlHTTP.onloadstart = function() {
        //         This.percent = 0;
        //     };
        // 
        //     xmlHTTP.onerror = function() {
        //         This.message = 'unable to get the image ['+xmlHTTP.status+']';
        //         This.result = false;
        //     };
        // 
        //     xmlHTTP.send(null);
        // 
        // }; 

        console.log(Image.prototype);
        
        let getImg = new Image;
        getImg.load("https://www.learningcontainer.com/wp-content/uploads/2020/07/Large-Sample-Image-download-for-Testing.jpg",
        result =>{
            console.log(result);
        });
        
        // getImg.onloadstart = ev => {
        //   console.log('Image load started',ev,getImg);        
        // };
        // getImg.onprogress = ev => {
        //   console.log('Image loading...',ev,getImg);
        // };
        // getImg.onload =  ev =>{
        //     console.log('Image loaded',ev,getImg);
        // };
        // getImg.addEventListener('error', ev =>{
        //     console.log('Image error',ev,getImg);
        //     console.log(ev.message);
        // },false);
       
    


           /*
        //	[ kimera framework V 2.8.beta - mod maremapp ] [gapkit project beta 0.0.8 ]
        //	Credits: Alberto Marà & Shape group - All right reserved
        //	https://github.com/ShapeGroup/kimera-frontend-framework/wiki
        //	https://www.facebook.com/kimeraframework/
        */


        function debug(){ console.debug.apply(console,arguments); }

        debug(`:: [🛈 Version] V2.8 kimera || Visor 0.8`);
        debug(`:: [🛈 Project] https://git.io/JIJEt`);
        debug(`:: [🛈 wikizone] https://git.io/fhSzk`);
        debug(`:: [🛈 licence] GNU V3 https://git.io/JJVw0`);



    //--------------------------------------------------//


        // micro-libs // touch check


        const is_touch_device = () =>
        {
            return 'ontouchstart' in window;
        }


        // micro-libs // if event done


        const eventDone = F =>
        {
            var timer; return (event) =>
            {
                if(timer) clearTimeout(timer); timer = setTimeout(F,100,event);
            }

        }


        // micro-libs // get real offeset top
       

        const getoffsetTop  = el =>
        {
            let top = 0; while(el) { top += el.offsetTop; el = el.offsetParent; } return top;
        }


        // micro-libs // get real offeset top


        const getoffsetLeft = el =>
        {
            let left = 0; while(el) { left += el.offsetLeft; el = el.offsetParent; } return left;
        }


        // micro-libs // Computed Translate X


        function getComputedTranslateX(obj)
        {

            if(!window.getComputedStyle) return false;

            let style = getComputedStyle(obj),
                transform = style.transform || style.webkitTransform || style.mozTransform;

            let mat = transform.match(/^matrix3d\((.+)\)$/);

            //if(mat)return parseFloat(mat[1].split(', ')[13]);
            mat = transform.match(/^matrix\((.+)\)$/);
            if(mat)
            {
                mat = parseFloat(mat[1].split(', ')[4]);
                if(!isNaN(mat)) return mat;
            }
            //return mat ? parseFloat(mat[1].split(', ')[4]) : 0;

        }


        // micro-libs // Computed Translate Y


        function getComputedTranslateY(obj)
        {

            if(!window.getComputedStyle) return false;

            let style = getComputedStyle(obj),
                transform = style.transform || style.webkitTransform || style.mozTransform;

            let mat = transform.match(/^matrix3d\((.+)\)$/);

            //if(mat)return parseFloat(mat[1].split(', ')[13]);
            mat = transform.match(/^matrix\((.+)\)$/);

            if(mat)
            {
                mat = parseFloat(mat[1].split(', ')[5])
                if(!isNaN(mat)) return mat;
            }

        }



    //--------------------------------------------------//



        const checkLessJs = () =>
        {

            if( document.querySelector('script[src="//cdnjs.cloudflare.com/ajax/libs/less.js/3.9.0/less.min.js"]')||document.querySelector('script[src="https://cdnjs.cloudflare.com/ajax/libs/less.js/3.9.0/less.min.js"]') )
            {

                debug(`:: [⚠ ui alert]: LessJs via simple script\n   ⮑ if you are using lessjs via script remember to put async='true' or something will not work!\n   -> Comment the Less script and load the compiled css parameters into a css file.\n\n::::  -> Remember that even if excellent, the script version is extremely slow!\n::::     We recommend using compilation via node js or php.\n::::     via php: shorturl.at/apy09\n::::     via node: shorturl.at/esSUY\n\n`);

                let themecompiled = document.querySelector('style[id^="less:').innerHTML;
                alert("\n\n[⚠ ui alert]: LessJs Finished - you can copy the theme and deactivate less.js\n\n");
                prompt("Compiled code:", ""+themecompiled);

            }

        }



    //--------------------------------------------------//



        const nomobar = () =>
        {

            let DOCY = document.querySelector('html'),
                BODY = document.querySelector('body');

            if(document.documentElement.clientWidth <= 920) // fuck mobile browser bar!
            {
                DOCY.style.height = window.innerHeight + 'px';
                BODY.style.height = window.innerHeight + 'px';
            }
            else
            {
                DOCY.style.height = ''; if(DOCY.style=='') DOCY.removeAttribute('style'); 
                BODY.style.height = ''; if(BODY.style=='') BODY.removeAttribute('style');
            }

        }



    //--------------------------------------------------//



        const inserter = () =>
        {

            let templatelist = document.getElementsByTagName('tempalte');

            for(let template of templatelist)
            {

                if(template.getAttribute('data-src'))
                {

                    fetch(template.dataset.src).then(
                    file => {

                        file.text().then(
                        filecontent => {

                            template.insertAdjacentHTML('afterend', filecontent);
                            el.remove();

                        })

                    })

                }

            }

        }



    //--------------------------------------------------//



        const lazyloader = () =>
        {
            

            // getImg.src = imageURL;

            // let url = 'https://hg1.funnyjunk.com/large/pictures/ca/7f/ca7ff7_7232938.jpg';
            // 
            // // 1. Create a new XMLHttpRequest object
            // let xhr = new XMLHttpRequest();
            // 
            // // 2. Configure it: GET-request for the URL /article/.../load
            // xhr.open('GET', url, true);
            // xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
            // xhr.crossOrigin = "anonymous"; // Anonymous
            // xhr.withCredentials = "false";
            // xhr.responseType = "arraybuffer";
            // // 3. Send the request over the network
            // xhr.send();
            // 
            // console.log(xhr.status);
            // 
            // 
            // var img = new Image();
            // 
            // setInterval(()=>{
            //     console.log(img.completedPercentage);
            // },100)
            // 
            // // // 4. This will be called after the response is received
            // // xhr.onload = function() {
            // //   if (xhr.status != 200) { // analyze HTTP status of the response
            // //     alert(`Error ${xhr.status}: ${xhr.statusText}`); // e.g. 404: Not Found
            // //   } else { // show the result
            // //     alert(`Done, got ${xhr.response.length} bytes`); // response is the server response
            // //   }
            // // };
            // // 
            // // xhr.onprogress = function(event) {
            // //   if (event.lengthComputable) {
            // //     alert(`Received ${event.loaded} of ${event.total} bytes`);
            // //   } else {
            // //     alert(`Received ${event.loaded} bytes`); // no Content-Length
            // //   }
            // // 
            // // };
            // 
            // xhr.onerror = function() {
            //   alert("Request failed");
            // };
            // 
            // function handleResult(result) {
            //     console.log('result',result);
            // }

// 
// 
//             var _request = new XMLHttpRequest() || new ActiveXObject("Microsoft.XMLHTTP") || new ActiveXObject("Msxml2.XMLHTTP") || new ActiveXObject("Msxml2.XMLHTTP.6.0") || new ActiveXObject("Msxml2.XMLHTTP.3.0");
//                 _request.open('GET', 'https://www.learningcontainer.com/wp-content/uploads/2020/07/Large-Sample-Image-download-for-Testing.jpg', true);
//                 // _request.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
//                 // _request.setRequestHeader('Access-Control-Allow-Origin', '*');
//                 // _request.setRequestHeader('Content-Type', 'text/html');
//                 // _request.withCredentials = "false";
//                 // _request.crossOrigin = "anonymous"; // Anonymous
//                 // _request.responseType = "arraybuffer";
//                 console.log('type: ',_request.responseType);
// // _request.setRequestHeader("Content-Type", "text/plain;charset=UTF-8");
//  _request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
//                 // _request.responseType = 'text/html';
//                 if (_request.withCredentials !== undefined) console.log('probably cors error');
// 
//                 console.log(_request);
// 
//                 // imageInLoad = transfered =>{
//                 //     console.log(`Received `+transfered.loaded+` of `+transfered.total+` bytes // `+~~((transfered.loaded/transfered.total)*100)+'%');
//                 //     if(transfered.loaded==transfered.total)
//                 //     { console.log(_request.response); }
//                 // }
//                 // _request.onprogress = () => {
//                 //     console.log('progess....');
//                 // }
// console.log('headers: ', _request.getAllResponseHeaders() );
// 
// 
// _request.onreadystatechange = function() {
//     if (_request.readyState == 4 && _request.status == 200 || XMLHttpRequest.DONE)
//     {
//         console.log('IMAGE IS LOADED',_request.response);
//     }
//     else
//     {
//         console.log('? ',_request.responseText);
//     }
// };
//                 _request.onload = () => {
// 
// 
//                     // let bufferized = new Uint8Array(_request.response),
//                     //     datablob   = new Blob([bufferized], {'type': 'image\/jpeg'}),
//                     //     windowurl  = window.URL || window.webkitURL,
//                     //     imageurl  = windowurl.createObjectURL(datablob);
// 
//                 }
// 
//                 _request.send(null);

            // _request.onerror = () => { console.log(_request.onerror); };
            // _request.onabort = () => {console.log(_request.onabort);};


            let Loader = document.querySelectorAll('.loader')[0];

            Loader.style.transitionTime='0';
            Loader.classList.remove('active','hide');
            Loader.classList.add('active');

            setlazy ( lazy_sets_is_end => {  

                document.querySelectorAll('body[class*="mode-"]')[0].style.opacity='1';

                setTimeout(()=>{

                    Loader.classList.add('off');

                },150); // wait elements call

                setTimeout(()=>{

                    Loader.classList.add('hide');
                    Loader.classList.remove('active','off','gpuboost');

                },750); // wait css exit out animation

            });


            // collect all elements
            function setlazy( lazy_sets_is_end )
            {


                let lazyed          = document.querySelectorAll('.lazy'),
                    lazyonstartlist = [], // on load page, if in view (not unload)
                    onviewenterlist = [], // on scroll load when you view it (not unload)
                    sauron          = []; // on-off start on view (forever active if have an element)


                if(lazyed.length<=0)
                {
                    return lazy_sets_is_end();
                } 

                else
                {

                    for (let element of lazyed)
                    {


                        let elementname     = element.tagName.toLowerCase(),
                            validtype       = ['div','span','picture','figure'];

                        if( element.classList.contains('lazy') && validtype.indexOf(elementname)<0 )
                        {
                            debug(`:: [⚠ ui alert]: wrong lazy preload\n   ⮑ The tag "`+elementname+`" is not valid for a preload action!\n      Read more on: https://git.io/vldt456`);
                        }

                        else
                        {

                            // who si progressbar and who the content?
                            let elementcontent  = element.firstElementChild;
                            let elementbar = (element.lastElementChild.className.includes('progress-')) ? element.lastElementChild : false;
                            if(elementbar==elementcontent || elementcontent==undefined ){ debug(`:: [⚠ ui alert]: wrong preload\n   ⮑ contents not defined, probably it's not first child of lazy.`);}

                            //check content type and...
                            let contenttype    = elementcontent.tagName.toLowerCase(),
                                contentclasses = elementcontent.classList;

                            if(contenttype == 'div' || contenttype == 'span')
                            {
                                if(!elementcontent.dataset.src)
                                {
                                    debug(`:: [⚠ ui alert]: wrong preload\n   ⮑ data-src not found on an image with preload\n      Read more on: https://git.io/vldt456`);
                                    element.classList.add('debug-error');
                                }
                                else
                                {
                                    lazyonstartlist.push(element);
                                }
                            }

                            else if(contenttype=='img')
                            {

                                let classes    = [...element.classList].join(''),
                                    imgs       = element.querySelectorAll('*>img'),
                                    isvalid    = true;

                                //checks images...
                                for (let img of imgs)
                                {

                                    if(!elementcontent.dataset.src)
                                    {
                                        isvalid = `:: [⚠ ui alert]: wrong preload\n   ⮑ data-src not found on an image with preload\n      Read more on: https://git.io/vldt456`;
                                        element.classList.add('debug-error');
                                    }

                                    else if(!classes.match(/ratio/g) && !img.dataset.size )
                                    {
                                        isvalid = `:: [⚠ ui alert]: wrong preload\n   ⮑ data-size or ratio not found on an image: `+img.dataset.src.match(/.*\/(.*)$/)[1]+`\n      Read more on: https://git.io/vldt456`;
                                        img.src=img.dataset.src;
                                    }

                                }

                                if(isvalid===true)
                                {

                                    (getoffsetTop(element)<=(window.scrollTop||document.documentElement.scrollTop)+screen.availHeight)
                                        ? lazyonstartlist.push(element)        // it's in view
                                        : onviewenterlist.push(element)    // on scrolling

                                }

                                else
                                {
                                    debug(isvalid);
                                }

                            }

                            else if(contenttype == 'video' || contenttype == 'iframe' || contentclasses.contains('type-player') )
                            {

                                onviewenterlist.push(element);

                                if(elementcontent.getAttribute('data-options'))
                                {
                                    if(elementcontent.getAttribute('data-options').includes('autohide')) { sauron.push(element);}
                                }

                            }

                            else
                            {
                                debug(`:: [⚠ ui alert]: wrong preload\n   ⮑ Element validation for: `,element); 
                            }

                        }


                    }


                    // clean load array
                    for(let in_onviewlist of onviewenterlist)
                    {
                        for(let in_lazynow of lazyonstartlist)
                        {
                            if(in_onviewlist == in_lazynow)
                            {
                                onviewenterlist.splice(onviewenterlist.indexOf(in_onviewlist),1);
                            }
                        }
                    }


                    //load if in view now
                    lazynow(lazyonstartlist,null,null);

                    //load when in view or when is ready
                    // lazyobserver(onviewenterlist,sauron);



                }

                //return set is end
                return lazy_sets_is_end();

            }


            // on scroll observe.. what is in start, else stop
            // function lazyobserver(onviewenterlist,sauron) 
            // {
            // 
            //     if(sauron.length>-1 || onviewenterlist.length>-1)
            //     {
            // 
            //         window.onscroll = ev_scrollpage => {
            // 
            //             let scrollpage = setInterval( ()=> {
            // 
            //                 window.clearInterval( scrollpage ); 
            // 
            //                 let wintop = window.scrollTop || document.documentElement.scrollTop,
            //                     winbottom = wintop + screen.availHeight;
            // 
            // 
            //                 //is it in or under screen view?
            //                 if(onviewenterlist.length>-1)
            //                 {
            //                     let index=-1;
            //                     for (let element of onviewenterlist)
            //                     {
            //                         index++;
            //                         if(getoffsetTop(element)<winbottom )
            //                         {
            //                             if(!element.className.includes('[lazing]'))
            //                             {
            //                                 lazynow(onviewenterlist,index,element);
            //                             }
            //                         }
            //                         else
            //                         {
            //                             onviewenterlist.splice(index,1);
            //                         }
            // 
            // 
            //                     }
            //                 }
            // 
            //                 //is it in or out screen view? (players controllers)
            //                 if(onviewenterlist.length<=0 && sauron.length>-1 )
            //                 {
            // 
            //                     for (let element of sauron)
            //                     {
            // 
            //                         let elementcontent  = element.firstElementChild,
            //                             classelist      = elementcontent.classList.toString(),
            //                             ePosition       = getoffsetTop(element),
            //                             isInView        = (ePosition<winbottom&&(ePosition+element.offsetHeight)>wintop);
            // 
            //                         //if not in view
            //                         if(isInView)
            //                         {
            // 
            //                             elementcontent.classList.add('[ON]'); elementcontent.classList.remove('[OFF]');
            // 
            //                                  if(classelist.includes('facebook','autounload'))    { elementcontent.src=elementcontent.dataset.relink; }
            //                             else if(classelist.includes('youtube','autohide'))       { elementcontent.contentWindow.postMessage('{"event":"command","func":"' + 'playVideo' + '","args":""}','*');}
            //                             else if(classelist.includes('vimeo','autohide'))         { elementcontent.contentWindow.postMessage('{"method":"play"}','*');}
            //                             else if(classelist.includes('instagram','autohide'))     { elementcontent.play();}
            // 
            // 
            //                         }
            // 
            //                         //if is in view
            //                         else 
            //                         {
            // 
            //                             elementcontent.classList.add('[OFF]'); elementcontent.classList.remove('[ON]'); 
            // 
            //                                  if(classelist.includes('facebook', 'autounload'))              { elementcontent.src=''; }
            //                             else if(classelist.includes('youtube', 'autohide', 'autostop'))     { elementcontent.contentWindow.postMessage('{"event":"command","func":"' + 'pauseVideo' + '","args":""}', '*'); }
            //                             else if(classelist.includes('vimeo', 'autohide', 'autostop'))       { elementcontent.contentWindow.postMessage('{"method":"pause"}', '*'); }
            //                             else if(classelist.includes('instagram', 'autohide', 'autostop'))   { elementcontent.pause(); }
            // 
            //                         }
            // 
            //                     }
            //                 }
            // 
            //             },300) // 3.x fps; 
            // 
            //         }
            // 
            //     }
            // 
            // }


            // if in view load it
            function lazynow(list)
            {
                let index=-1;
                for (let element of list)
                {

                    index++;

                    if( !element.className.includes('status-[on]') )
                    {

                        element.classList.remove('status-[off]');
                        element.classList.add('status-[on]');


                        let contenttype  = element.firstElementChild.tagName.toLowerCase(),
                            bar          = (element.lastElementChild.className.includes('progress-')) ? element.lastElementChild : false;
                     

                        if(contenttype=='img')
                        {


                            let wrappedimages = [],
                                tags = element.querySelectorAll('img');

                            // push in list the image
                            for (let tagimg of tags)
                            {

                                wrappedimages.push({

                                        'img'    : tagimg,
                                        'loaded' : false,
                                        'percent': '00',
                                        'waiting': 0

                                    });

                                tagimg.classList.add('hidden');
                                tagimg.src=tagimg.dataset.src;

                            }

                            // checl wrapped images
                            let qnt = wrappedimages.length;
                            let checkstatus = setInterval(
                                ()=>{

                                    for (let i=0;i<qnt;i++) 
                                    {

                                        // set actual img
                                        let image = wrappedimages[i];

                                        //set if is loaded
                                        image.img.onload = () => {
                                            image.loaded= true;
                                            console.log('laoded');
                                        }

                                        // set bar limit
                                        let steplimit = parseInt(100/qnt);

                                        // set frametime passed
                                        image.waiting += 1;

                                        //if is in error
                                        if( image.percent>steplimit) { image.img.onabort = 'out of max time for preload' };
                                        if( image.percent>steplimit || image.img.onerror!=null || image.img.onabort!=null)
                                        {

                                            if(element.getElementsByClassName('loadererrormessage').length<=0)
                                            {

                                                bar.insertAdjacentHTML('afterend', `<div class="loadererrormessage"><span class="absolute-center radius-small pad-[10] align-center bkg-error" style="color:white;min-height:unset;min-width:unset;"><p>OPS! IMAGE NOT LOADED</p></span></div>`);
                                                bar.remove();

                                                (image.onerror!=null || image.onabort!=null) 
                                                        ? debug(`:: [⚠ ui alert]: preload error\n   ⮑ generic error or abort\n      Read more on: https://git.io/vldt456`,wrappedimages)
                                                        : debug(`:: [⚠ ui alert]: preload out of ranges\n   ⮑ image on preload is out of times\n      Read more on: https://git.io/vldt456`,wrappedimages);


                                                if(i==qnt) list.splice(index,1);

                                            }

                                            clearInterval(checkstatus);

                                        }

                                        else
                                        {

                                            // calc % of wait from time
                                            image.percent =  ( !image.loaded ) ? parseInt( (image.waiting) / qnt) : parseInt(steplimit);

                                            // print time
                                            let totalpercentinstring = 0; for(let x=0;x<qnt;x++){ totalpercentinstring+=parseInt(wrappedimages[x].percent) }
                                            bar.className='progress-['+((parseInt(totalpercentinstring)<10)?'0'+totalpercentinstring:''+totalpercentinstring)+']';

                                        }

                                        if(i==qnt-1)
                                        {
                                            //check if all is loaded
                                            let imgloadended=true; for(let x of wrappedimages){if(!x.loaded){imgloadended=false;}}

                                            //check if all loaded
                                            if(imgloadended)
                                            {

                                                //100%,show image
                                                for (let x=0;x<qnt;x++)
                                                {
                                                    wrappedimages[x].img.classList.remove('hidden');
                                                    wrappedimages[x].img.removeAttribute('data-src');
                                                }

                                                bar.className='progress-[100]';
                                                element.classList.add('status-[off]');

                                                //remove image from list
                                                list.splice(index,1);

                                                clearInterval(checkstatus);
                                               
                                                //reset and view result
                                                setTimeout(()=>{

                                                    bar.remove();

                                                    element.classList.remove('status-[on]');
                                                    element.classList.remove('status-[off]');

                                                    if(element.getAttribute('class')=='')
                                                    element.removeAttribute('class')

                                                },750)

                                            }
                                        }


                                    }

                                    console.log(wrappedimages);

                                },1000);


                        }


                        else if(element.firstElementChild.tagName.toLowerCase()=='div' || element.firstElementChild.tagName.toLowerCase()=='span')
                        {

                            if( !element.className.includes('[lazing]') ) element.classList.add('[lazing]');

                            fetch(element.firstElementChild.dataset.src).then(
                            file => {

                                file.text().then(
                                content => {

                                    element.firstElementChild.innerHTML = content;
                                    // element.firstElementChild.insertAdjacentHTML('afterend', content);


                                })
                            })

                        }

                        else if(element.firstElementChild.tagName.toLowerCase()=='video' || element.firstElementChild.tagName.toLowerCase()=='iframe')
                        {


                            let isvideoframe = false, videoframe = ['watch','youtu','youtube','vimeo','instagram','facebook','fb','twitter','twitch'];
                            for(let frametypename of videoframe){if( element.firstElementChild.src.indexOf(frametypename)){isvideoframe=true;}};


                            // is it a frame?
                            if(isvideoframe||element.firstElementChild.tagName.toLowerCase()=='iframe') //element.firstElementChild.tagName.toLowerCase()=='iframe' || 
                            {
                                if( !element.className.includes('[lazing]') ) element.classList.add('[lazing]');

                                // console.log('fidend videoframe: '+isvideoframe+' for:',element.firstElementChild);

                                let doneframe = () =>
                                {

                                    if(onviewenterlist) onviewenterlist.splice(index,1);

                                    element.classList.add('status-[off]');

                                    setTimeout(()=>{

                                        element.classList.remove('status-[on]');
                                        element.classList.remove('status-[off]');

                                        if(element.getAttribute('class')=='')
                                        element.removeAttribute('class') 

                                    },750)


                                }


                                if(element.firstElementChild) { doneframe() } else {element.firstElementChild.onload = doneframe;}

                            }

                            // is it video?
                            else
                            {


                                element.firstElementChild.oncanplay = () =>
                                {

                                    if(onviewenterlist) onviewenterlist.splice(index,1);

                                    element.classList.add('status-[off]');

                                    if(i==imgslenght)
                                    {

                                        setTimeout(()=>{

                                            element.classList.remove('status-[on]');
                                            element.classList.remove('status-[off]');

                                            if(element.getAttribute('class')=='')
                                            element.removeAttribute('class')

                                        },750)

                                    }

                                }

                            }

                        }

                    }

                }

            }


        }




    //--------------------------------------------------//



        const unloader = () =>
        {


            let selflinkslist = [...document.querySelectorAll('[target*="_self"], [target*="_parent]"')];

            for (let link of selflinkslist)
            {

                link.onclick = ev_unload =>
                {


                    ev_unload.preventDefault();


                    let loader      = [...document.querySelectorAll('.loader')][0],
                        destination = link.getAttribute('href'),
                        disabled    = link.getAttribute('disabled');


                    if(loader.querySelectorAll('.spinner-box').length>0)
                    {
                        loader.querySelectorAll('.spinner-box')[0].classList.add('hide');
                    }


                    loader.classList.add('off');


                    if(!disabled)
                    {

                        loader.classList.remove('hide');


                        setTimeout( () => {

                            loader.classList.add('gpuboost','active');
                            loader.classList.remove('off');

                        }, 10); // after add gpuboost

                        setTimeout( () => {

                            (destination==='#') ? location.reload() : location.href=destination;

                        }, 250); // after loader fadein

                    }

                }

            }


        }



    //--------------------------------------------------//



        const tagcode = () =>
        {

            let codewraps = document.getElementsByTagName('code');
            for(let incode of codewraps)
            incode.textContent = incode.innerHTML.trimStart().trimEnd();
        }



    //--------------------------------------------------//



        const modeapp = () =>
        {


            // options
            let lockScroll  = false,
                draglimit   = parseInt((document.body.clientWidth/2.5)), // drag
                sensibility = 50; // swipe


            // get body viewport

            if([...document.querySelectorAll('.mode-app')][0])
            { 

                document.getElementsByTagName('HTML')[0].style.overflow ="hidden";

                let ViewPortModelApp = [...document.querySelectorAll('body.mode-app')][0];

                // set all controller elements

                let Controller    = [...ViewPortModelApp.querySelectorAll('.view-controller')][0],
                    ContentBox    = [...ViewPortModelApp.querySelectorAll('.view-group')][0],
                    Section       = [...ContentBox.querySelectorAll('.view')],
                    Pointers      = [...Controller.querySelectorAll('.pointer')],
                    PrevView      = [...ViewPortModelApp.querySelectorAll('.prev-view')],
                    NextView      = [...ViewPortModelApp.querySelectorAll('.next-view')],
                    Dots          = ViewPortModelApp.querySelector('.dots'),
                    Steps         = ViewPortModelApp.querySelector('.steps');


                if(Dots)
                {
                  if(Dots.closest('.snap-x')||Dots.closest('.snap-y')){ Dots = null;}
                }

                //check controller elements

                let isPointed, isDots, isSteps;
                if(Pointers<=0) { isPointed=false } else { isPointed=true };
                if(!Dots) { isDots=false } else { isDots=true };
                if(!Steps) { isSteps=false } else { isSteps=true };



                ////// swipe actions

                let sectionsize = Section.length;
                for (let i = 0; i < sectionsize; i++)
                {


                    ////// on first, find start viewbox by active

                    if(Section[i].className.match('active'))
                    {

                        let start = i, StartPosition = Section[start].offsetLeft;

                        if(isPointed) Pointers[start].classList.add('active');

                        ContentBox.style.transform = 'translate('+StartPosition*-1+'px,0)';

                    }



                    /////// steps manager

                    if( isSteps )
                    {

                        let StepSpan  = document.createElement('span');

                        Steps.appendChild(StepSpan);

                        StepSpan.classList.add('step');

                        if(Section[i].className.match('active'))
                        {

                            let sai = i, steps = [...Steps.querySelectorAll('.step')];
                            for (sai = 0; sai < steps.length; sai++) {steps[sai].classList.add("active");}

                        }

                    }



                    /////// dots manager

                    if( isDots )
                    {

                        let DotSpan  = document.createElement('span');

                        Dots.appendChild(DotSpan);

                        DotSpan.classList.add('dot');

                        if(Section[i].className.match('active')) DotSpan.classList.add('active');

                    }



                    ////// controllers manager

                    if( isPointed )
                    {

                        if(i > sectionsize  || Pointers[i] == undefined || Pointers[i] == null)
                        { debug(`:: [⚠ ui alert]: wrong mode-app\n   ⮑ Pointers and views\n   ⮑ pointers don't match the amount of views, make sure there is one view for each pointer!`) }

                        Pointers[i].onclick = VievportEvent =>
                        {


                            //ContentBox.classList.remove('smooth'); //immidiatly! native app like.

                            VievportEvent.preventDefault(/*stop all return click.*/);

                            if(Section[i].className.match('lock'))
                            {

                                Pointers[i].classList.add('border-error');

                                let Stopleft = document.createElement('DIV'),
                                    Stopright = document.createElement('DIV');

                                Stopleft.classList.add('stop-left');
                                Stopright.classList.add('stop-right');

                                ViewPortModelApp.appendChild(Stopleft);
                                ViewPortModelApp.appendChild(Stopright);
                                setTimeout(()=>{
                                  Pointers[i].classList.remove('active');
                                  Pointers[i].classList.remove('border-error');
                                  Pointers[i].blur();
                                  ViewPortModelApp.removeChild(Stopleft);
                                  ViewPortModelApp.removeChild(Stopright);
                                },1500)

                            }

                            else
                            {

                                resetActiveClasses();

                                Pointers[i].classList.add('active');
                                Section[i].classList.add(/*'visible',*/'active');

                                //define relative panel offset

                                let RelativePanel;


                                if( i >= Pointers.length-1 )
                                {

                                    let SWidth = parseInt( window.getComputedStyle(Section[i]).width ),
                                        WWidth = parseInt( window.innerWidth),
                                        Offset = Section[i].offsetLeft;

                                    RelativePanel = parseInt( (Offset)-(WWidth-SWidth) );

                                }

                                else
                                {
                                    RelativePanel = Section[i].offsetLeft;
                                }


                                updateSteps();
                                updateDots();
                                updateController();


                                //go on panel

                                // addSmooth();

                                ContentBox.style.transform = 'translateX('+RelativePanel*-1+'px)';

                                // removeSmooth();

                            }

                        }

                    }



                    ////// content manager

                    var EventTarget,
                        PanelTarget,

                        PrevPanel,
                        NextPanel,
                        PrevOffset,
                        NextOffset,

                        Zone,
                        DragPosition,
                        StartX, StartY,
                        DistX, DistY, DragX, DragY,

                        StartTouchPosition,
                        StandardPosition,
                        underScroll,

                        StartTime;



                    ContentBox.ontouchstart = VievportEvent =>
                    {

                        //ContentBox.classList.remove("smooth"); /*immidiatly! native app like.*/

                        //set target of actions

                        PanelTarget = VievportEvent.target.closest('.view');
                        EventTarget = VievportEvent.target;


                        //you can drag?

                        if(
                            VievportEvent.target.closest('.snapGroup') || VievportEvent.target.closest('.snap-x') || VievportEvent.target.closest('.snap-y') ||
                            VievportEvent.target.closest('.scroll-x') || VievportEvent.target.closest('.scroll-y') ||
                            VievportEvent.target.closest('.button-number') || VievportEvent.target.closest('.button-range *') ||
                            VievportEvent.target.closest('a') || VievportEvent.target.tagName.toLowerCase() == 'a' ||
                            VievportEvent.target.className.match("nofx")
                          )
                        {
                            PanelTarget.setAttribute('draggable','false');
                            PanelTarget.removeAttribute("draggable");
                        }
                        else
                        {
                            PanelTarget.setAttribute('draggable','true');
                        }


                        //set event starter variable

                        Zone        = VievportEvent.changedTouches[0],
                        StartX      = Zone.pageX,
                        StartY      = Zone.pageY,
                        StartTime   = new Date(),

                        StartTouchPosition =  parseInt( Zone.clientX ),
                        PrevPanel = PanelTarget.previousElementSibling,
                        NextPanel = PanelTarget.nextElementSibling,

                        underScroll = false;

                        //check who is the active

                        if(!PanelTarget.className.match('active'))
                        {
                            resetActiveClasses();
                            PanelTarget.classList.add('active');
                            updateController();
                            updateSteps();
                            updateDots();
                        }


                        // set previous elements

                        if(PrevPanel)
                        {
                            PrevOffset = parseInt( PanelTarget.previousElementSibling.offsetLeft*-1 )
                        }
                        else
                        {
                            PrevOffset = PanelTarget.offsetLeft
                        }
                           


                        // set next elements

                        if(NextPanel)
                        {
                            NextOffset  = parseInt( PanelTarget.nextElementSibling.offsetLeft*-1 )
                        }

                        else if(NextPanel === null)
                        {
                            NextOffset  = parseInt( PanelTarget.offsetLeft*-1 )
                        }

                        else if(NextPanel === null && (parseInt(NextPanel.nextElementSibling.offsetWidth) <  parseInt(ContentBox.offsetWidth)))
                        {  //note: else is last and have a small width... recalculate final scroll by pre-last
                            NextOffset  = parseInt( PanelTarget.offsetLeft*-1 );
                        }

                    }

                    ContentBox.ontouchmove = VievportEvent =>
                    {


                        //refresh starter variable on dragging

                        Zone                 = VievportEvent.changedTouches[0],
                        StandardPosition     = PanelTarget.offsetLeft,
                        DragPosition         = parseInt( ( (StandardPosition+StartTouchPosition) ) + (Zone.pageX*-1) ),
                        DragY                = Zone.pageY-StartY,
                        DragX                = StandardPosition-DragPosition;


                        PanelTarget.onscroll = VievportEvent =>
                        {
                            underScroll = true;
                            return false;
                        }

                        let X = Math.abs(DragX), Y = Math.abs(DragY);
                        if(PanelTarget.hasAttribute('draggable') && X>Y)
                        {

                            if( DragX < 0 && !NextPanel || DragX > 0 && !PrevPanel)
                            {
                                DragX = 0;

                                // addSmooth();

                                ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
                                PanelTarget.removeAttribute('draggable');

                                // removeSmooth();
                            }
                            else if( DragX != 0 && !underScroll )
                            {
                                DragY = 0;
                                ContentBox.style.transform = 'translate('+DragPosition*-1+'px,0)';
                            }

                        }
                        else
                        {

                            DragX = 0;

                            // addSmooth();

                            ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
                            PanelTarget.removeAttribute('draggable');

                            // removeSmooth();

                        }

                    }

                    ContentBox.ontouchend = VievportEvent =>
                    {


                        //refresh starter variable on dragging

                        Zone = VievportEvent.changedTouches[0],
                        StandardPosition = PanelTarget.offsetLeft,
                        DistX = parseInt(Zone.pageX - StartX),
                        DistY = parseInt(Zone.pageY - StartY)


                        //Drag Release
                        let X = Math.abs(DistX), Y = Math.abs(DistY);

                        let Sensibility
                        if(
                            VievportEvent.target.closest('.snapGroup') || VievportEvent.target.closest('.snap-x') || VievportEvent.target.closest('.snap-y') ||
                            VievportEvent.target.closest('.scroll-x') || VievportEvent.target.closest('.scroll-y') ||
                            VievportEvent.target.closest('.button-number') || VievportEvent.target.closest('.button-range *') ||
                            VievportEvent.target.closest('a') || VievportEvent.target.tagName.toLowerCase() == 'a' ||
                            VievportEvent.target.className.match("nofx")
                          )
                        {
                            Sensibility = 0;
                            DistX = 0;
                        }
                        else
                        {
                            Sensibility = sensibility;
                        }


                        // let SwipeRangeY = DistY <= (Sensibility*2) && DistY >= -(Sensibility*2),
                        //     stoptime = new Date() - StartTime;
                        //     swipemin = parseInt( Sensibility*12/(Sensibility/4) );
                        //     swipemax = parseInt( Sensibility*82/(Sensibility/4)  ),
                        //     timerange = stoptime >= swipemin && stoptime <= swipemax;

                        if(PanelTarget.hasAttribute('draggable'))
                        {

                            DistY = 0;
                            DistX = DistX*-1;

                            if( DistX > (draglimit) )
                            // if( (DistX >= (draglimit/2) && timerange) || (DistX > draglimit))
                            {

                                goNext();

                            }
                            else if( DistX <= (-draglimit))
                            // else if( (DistX <= -(draglimit/2)&& timerange) ||  (DistX < (-draglimit)))
                            {

                                goPrev();

                            }
                            else
                            {
                                // addSmooth();

                                ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
                                PanelTarget.removeAttribute('draggable');

                                // removeSmooth();
                            }

                        }


                        //stop all and fuckoff.
                        PanelTarget.blur();
                        underScroll = false;


                    }


                    ////// Next\Prev manager

                    if( NextView )
                    {

                        let nvl = NextView.length;
                        for (let n = 0; n < nvl; n++)
                        {

                            NextView[n].onclick = VievportEvent =>
                            {

                                VievportEvent.preventDefault();
                                VievportEvent.stopPropagation();


                                let sl = Section.length;
                                for (let i = 0; i < sl; i++)
                                {

                                    let nextindex;
                                    if(Section[i].className.match('active'))
                                    {

                                        if(Section[i+1].className.match('lock'))
                                        {

                                            let Stopright = document.createElement('DIV');

                                            Stopright.classList.add('stop-right');

                                            ViewPortModelApp.appendChild(Stopright);
                                            setTimeout(()=>{
                                                ViewPortModelApp.removeChild(Stopright);
                                            },1500)

                                        }
                                        else
                                        {
                                            nextindex = parseInt(i+1);
                                            __next(nextindex);
                                            return false;
                                        }

                                    }

                                    function __next(nextindex)
                                    {

                                        if(Section[nextindex] === undefined) {  return false; }
                                        else(nextindex>=0 && nextindex<=Section.length)
                                        {

                                            let offset = Section[nextindex].offsetLeft;

                                            resetActiveClasses();

                                            // addSmooth();

                                            ContentBox.style.transform = 'translate('+offset*-1+'px,0)';
                                            Section[nextindex].classList.add("active");

                                            // removeSmooth();

                                            updateController();
                                            updateSteps();
                                            updateDots();

                                        }

                                    }

                                }

                            }

                        }

                    }
                    else{ NextView = null; }

                    if( PrevView )
                    {

                        let pvl = PrevView.length;
                        for (let p = 0; p < pvl; p++)
                        {

                            PrevView[p].onclick = VievportEvent =>
                            {

                                VievportEvent.preventDefault();
                                VievportEvent.stopPropagation();


                                let sl = Section.length;
                                for (let i = 0; i < sl; i++)
                                {


                                    let previndex;
                                    if(Section[i].className.match('active'))
                                    {
                                        if(Section[i-1].className.match('lock'))
                                        {

                                            let Stopleft = document.createElement('DIV');

                                            Stopleft.classList.add('stop-left');

                                            ViewPortModelApp.appendChild(Stopleft);
                                            setTimeout(()=>{
                                                ViewPortModelApp.removeChild(Stopleft);
                                            },1500)

                                        }
                                        else
                                        {
                                            previndex = parseInt(i-1);
                                            __prev(previndex);
                                            return false;
                                        }
                                    }

                                    function __prev(previndex)
                                    {

                                        if(Section[previndex] === undefined) {  return false; }
                                        else(previndex>=0 && previndex<=Section.length)
                                        {

                                            let offset = Section[previndex].offsetLeft;

                                            resetActiveClasses();

                                            // addSmooth();

                                            ContentBox.style.transform = 'translate('+offset*-1+'px,0)';
                                            Section[previndex].classList.add('active');

                                            // removeSmooth();



                                            updateController();
                                            updateSteps();
                                            updateDots();

                                        }
                                    }


                                }

                            }

                        }
                    }
                    else{ PrevView = null; }



                    ////// methods...


                    let addSmooth = () =>
                    {
                        ContentBox.classList.add('smooth');
                    }

                    let removeSmooth = () =>
                    {
                        setTimeout(()=>{
                            ContentBox.classList.remove('smooth');
                        },600)
                    }

                    let resetActiveClasses = () =>
                    {

                        for (let p = 0; p < Pointers.length; p++)
                            Pointers[p].classList.remove('active');

                        for (let s = 0; s < Section.length; s++)
                            Section[s].classList.remove('active'/*,'hidden'*/);

                    }


                    let updateDots = () =>
                    {
                        if( Dots )
                        {

                            let dot = [...Dots.querySelectorAll('.dot')];

                            for (let i = 0; i < Section.length; i++)
                            {
                                (Section[i].className.match('active')) ? dot[i].classList.add('active') : dot[i].classList.remove('active');
                            }

                        }

                    }


                    let updateSteps = () =>
                    {

                        if( Steps )
                        {

                            let step = [...Steps.querySelectorAll('.step')];

                            for (let i = 0; i < step.length; i++)
                            {
                                step[i].classList.remove("active");
                            }

                            for (let i = 0; i < Section.length; i++)
                            {

                                if(Section[i].className.match('active'))
                                {
                                    let filled = step.fill(0,1+i);
                                    for (let f = 0; f < 1+i; f++) filled[f].classList.add('active');
                                }
                            }

                        }

                    }


                    let updateController = () =>
                    {

                        for (let i = 0; i < Section.length; i++)
                        {

                            if(Section[i].className.match('active'))
                            {

                                if( isPointed )
                                {

                                    Pointers[i].classList.add('active');
                                    //Section[i].classList.replace('hidden','visible');

                                    if(Controller.className.match('autostep'))
                                    {

                                        let Last = Pointers[Section.length-1],

                                            pPos = parseInt(Pointers[i].offsetLeft),
                                            lPos = parseInt(Pointers[Section.length-1].offsetLeft),
                                            lWidh = parseInt( window.getComputedStyle(Last, null).getPropertyValue('width') ),
                                            cWidth = parseInt( window.getComputedStyle(Controller, null).getPropertyValue('width') ),
                                            maxPos = lPos-cWidth,

                                            cPos = parseInt(getComputedTranslateX(Controller))*-1;

                                        if(pPos<maxPos || !pPos)
                                        {
                                            Controller.style.transform = 'translate('+pPos*-1+'px,0)';
                                        }
                                        else if(pPos>=maxPos)
                                        {
                                            Controller.style.transform = 'translate('+(maxPos+lWidh)*-1+'px,0)';
                                        }

                                    }

                                }

                            }

                            else
                            {
                                if( isPointed ) { Pointers[i].classList.remove('active'); }
                            }

                        }


                    }

                    let goNext = () =>
                    {

                        if(NextPanel.className.match('lock'))
                        {

                            ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
                            PanelTarget.removeAttribute('draggable');

                            let Stopright = document.createElement('DIV');

                            Stopright.classList.add('stop-right');

                            ViewPortModelApp.appendChild(Stopright);
                            setTimeout(()=>{
                                ViewPortModelApp.removeChild(Stopright);
                            },1500)

                        }

                        else
                        {

                            //addSmooth();

                            PanelTarget.removeAttribute('draggable');
                            PanelTarget.classList.remove('active');
                            NextPanel.classList.add('active');


                            // if(!NextPanel.nextElementSibling && (window.getComputedStyle(ContentBox).width > window.getComputedStyle(NextPanel).width))
                            // {
                            //   let   NEW = parseInt( window.getComputedStyle(NextPanel).width ),
                            //         VCW = parseInt( window.innerWidth),
                            //         NCO = NextPanel.offsetLeft,
                            //
                            //   LastPosition = parseInt( (NCO)-(VCW-NEW) );
                            //
                            //   //it's last and small!
                            //   ContentBox.style.transform = 'translate('+(LastPosition*-1)+'px,0)';
                            // }
                            // else
                            // {
                                    ContentBox.style.transform = 'translateX('+NextOffset+'px)';
                            // }


                            // removeSmooth();

                            updateController();
                            updateSteps();
                            updateDots();

                        }

                    }

                    let goPrev = () =>
                    {

                        if(PrevPanel.className.match('lock'))
                        {

                            ContentBox.style.transform = 'translate('+StandardPosition*-1+'px,0)';
                            PanelTarget.removeAttribute('draggable');

                            let Stopleft = document.createElement('DIV');

                            Stopleft.classList.add('stop-left');

                            ViewPortModelApp.appendChild(Stopleft);
                            setTimeout(()=>{
                                ViewPortModelApp.removeChild(Stopleft);
                            },1500)

                        }
                        else
                        {

                            //addSmooth();

                            PanelTarget.removeAttribute('draggable');

                            PanelTarget.classList.remove('active');
                            PrevPanel.classList.add('active');


                            ContentBox.style.transform = 'translateX('+PrevOffset+'px)';

                            // removeSmooth();

                            updateController();
                            updateSteps();
                            updateDots();

                        }

                    }



                }

            }

        }



    //--------------------------------------------------//



        const grid_y = () =>
        {


            for(let grid of [...document.querySelectorAll('.grid-y')])
            {

                if(grid.className.split('col-')[0]) //alse is split in grid-x
                {

                    for(gridbox of [...grid.querySelectorAll('.grid-y>*')])
                    {

                        let rowHeight = parseInt( window.getComputedStyle(grid).getPropertyValue('grid-auto-rows') ),
                            rowGap = parseInt( window.getComputedStyle(grid).getPropertyValue('grid-row-gap') );

                        (rowHeight<=0 || !rowHeight )?rowHeight=0:null;
                        (rowGap<=0 || !rowGap)?rowGap=0:null;

                        let rowSpan = Math.ceil((gridbox.getBoundingClientRect().height+rowGap)/(rowHeight+rowGap));

                        gridbox.style.gridRowEnd = "span "+rowSpan;

                    }

                }
            }


        }



    //--------------------------------------------------//



        const outbox = () =>
        {


            let Viewport     = [document.querySelector('*[class*="mode-"]')][0],
                RelOutbox    = [...document.querySelectorAll('*[target^="outbox#"]')],
                OnLoadActive = [...document.querySelectorAll('.outbox.active')];


            let l = RelOutbox.length;
            for (let i = 0; i < l; i++)
            {


                let checktarget = RelOutbox[i].getAttribute('target').split('#')[1], undefinedtarget;

                if(checktarget=='' || checktarget==null || checktarget==undefined )
                {
                    debug(`:: [⚠ ui alert]: wrong outbox\n   ⮑ outbox target# anchor not defined!`),undefinedtarget=true;
                    RelOutbox[i].classList.add('debug-error');
                }

                else if(!document.getElementById(checktarget))
                {

                    if(undefinedtarget) debug(`:: [⚠ ui alert]: wrong outbox\n   ⮑  an outbox not finded!`);
                    else debug(`:: [⚠ ui alert]: wrong outbox\n   ⮑  outbox `+checktarget+` not exist!`);
                    RelOutbox[i].classList.add('debug-error');

                }

                else
                {

                    //open outbox
                    RelOutbox[i].onclick = event =>
                    {

                        //event.preventDefault();

                        let target = RelOutbox[i].getAttribute('target').split('#')[1],
                            OutBox = [...document.querySelectorAll('#'+target)][0],
                            OutBoxType = OutBox.querySelectorAll('.overlay>div[class^="side-"]')[0].className,
                            Overlay = OutBox.querySelectorAll('.overlay')[0];


                        // do open...

                        OutBox.classList.add('gpuboost','active');

                        if( OutBoxType.match('center') )
                        { addViewTransition('center'); }

                        else if( OutBoxType.match('top') )
                        { addViewTransition('top'); }

                        else if( OutBoxType.match('left') )
                        { addViewTransition('left'); }

                        else if( OutBoxType.match('right') )
                        { addViewTransition('right'); }

                        else if( OutBoxType.match('bottom') )
                        { addViewTransition('bottom'); }


                        //close outbox
                        OutBox.onclick = event =>
                        {

                            if(event.target.className.match('close') || event.target.className.match('accept') || event.target === Overlay)
                            {

                                OutBox.classList.add('off');
                                OutBox.classList.remove('active');

                                setTimeout( () => {
                                    OutBox.classList.remove('off','active','gpuboost');
                                },300)

                                removedViewTransition(OutBox);

                            }

                        }


                    }


                    //auto open
                    let ola = OnLoadActive.length;
                    for (let i = 0; i < ola; i++)
                    {

                        let OutboxOpen = OnLoadActive[i];
                        OutboxOpen.onclick = event =>
                        {

                            if(event.target.className.match('close') || event.target.className.match('accept') || event.target.classList.contains('overlay'))
                            {

                                OutboxOpen.classList.add('off');
                                OutboxOpen.classList.remove('active');

                                setTimeout( () => {
                                    OutboxOpen.classList.remove('off','active','gpuboost');
                                },300)

                                removedViewTransition(OutboxOpen);

                            }

                        }
                    }


                    let addViewTransition  = (side) =>
                    {

                        //Viewport.classList.add('gpuboost','vfxtransition-in','vfx'+side);
                        Viewport.classList.add('gpuboost','vfxtransition-in','vfx'+side);

                    }

                    let removedViewTransition  = (OutBox, side) =>
                    {

                        Viewport.classList.add('vfxtransition-out'),
                        Viewport.classList.remove('vfxtransition-in','vfxtop','vfxleft','vfxbottom','vfxright','vfxcenter');

                        setTimeout( () => {
                            OutBox.classList.remove('off','active','gpuboost'),
                            Viewport.classList.remove('vfxtransition-out','gpuboost');
                        },500)

                    }

                }


            }

        }



    //--------------------------------------------------//



        const absolute = () =>
        {


            let boxeslist = [...document.querySelectorAll('[class*="absolute-"]')];

            for (let box of boxeslist)
            {

                if( !box.parentNode.className.match('outbox') &&
                    !box.parentNode.className.match('side-') &&
                    !box.parentNode.className.match('view') )
                    {
                      box.parentNode.style.position = 'relative';
                    }
            }


        }



    //--------------------------------------------------//



        const standardscroll = () =>
        {


            var ScrolledBox = [...document.querySelectorAll('.scroll-x, .scroll-y')];

            let l = ScrolledBox.length;
            for (let i = 0; i < l; i++)
            {

                let sensibility = ( typeof InstallTrigger !== 'undefined' /*is firefox? */) ? 85 : 2.5;

                var onwhe = -1;
                ScrolledBox[i].onwheel = event =>
                {

                    event.preventDefault();
                    event.stopPropagation();
                    ScrolledBox[i].focus();

                    onwhe++
                    if(onwhe >= 1)
                    {


                            let velocityofscrolling;

                            if(onwhe<5)
                            {
                                velocityofscrolling = (onwhe/2);
                            }
                            else if(onwhe>5 && onwhe<8)
                            {
                                velocityofscrolling = (onwhe/2.5);
                            }
                            else {
                                velocityofscrolling = (onwhe/3.5);
                            }


                            if(ScrolledBox[i].className.match('scroll-x'))
                            {

                                if(event.deltaY>0)          ScrolledBox[i].scrollLeft += velocityofscrolling*(sensibility*event.deltaY);
                                else if(event.deltaY<0)     ScrolledBox[i].scrollLeft -= (velocityofscrolling*(sensibility*event.deltaY))*-1;


                            }

                            else if(ScrolledBox[i].className.match('scroll-y'))
                            {

                                if(event.deltaY>0)          ScrolledBox[i].scrollTop += velocityofscrolling*(sensibility*event.deltaY);
                                else if(event.deltaY<0)     ScrolledBox[i].scrollTop -= (velocityofscrolling*(sensibility*event.deltaY))*-1;

                            }

                          setTimeout(()=>{
                            return onwhe = 0;
                          },150)

                    }

                }

            }


        }



    //--------------------------------------------------//



        const checkscrollersize = () =>
        {


            //'.checksize',
            let oversizes = [...document.querySelectorAll('.checksize, TABLE, CODE, PRE, OUTPUT')];

            for (let sizedbox of oversizes)
            {

                let targetwidth = parseInt(sizedbox.offsetWidth),
                    parentwidth = parseInt(sizedbox.parentNode.offsetWidth),
                    scrollwrap;

                if( !(sizedbox.parentNode.className.match('scroll-x')) )
                {

                    let t = sizedbox.tagName;
                    if(t=='TABLE'||t=='CODE'||t=='PRE'||t=='OUTPUT')
                    {

                        let minw = parseInt(sizedbox.style.minWidth);

                        if(targetwidth > parentwidth)
                        {

                            let ScrollableWrap = document.createElement('div');

                            sizedbox.parentNode.insertBefore(ScrollableWrap, sizedbox);
                            ScrollableWrap.appendChild(sizedbox);
                            sizedbox.parentNode.classList.add('scroll-x');

                        }

                        else if( targetwidth <= parentwidth && sizedbox.parentNode.className.match('checksize') )
                        {
                            sizedbox.parentNode.outerHTML = sizedbox.parentNode.innerHTML;
                        }

                    }

                    else
                    {

                        if( targetwidth > parentwidth )
                        {

                            //wrap it
                            let ScrollableWrap = document.createElement('div');

                            sizedbox.parentNode.insertBefore(ScrollableWrap, SizedBox);
                            ScrollableWrap.appendChild(SizedBox);
                            sizedbox.parentNode.classList.add('scroll-x','checksize');

                        }
                        else if(targetwidth <= parentwidth && sizedbox.parentNode.className.match('checksize') )
                        {
                            sizedbox.parentNode.outerHTML = sizedbox.parentNode.innerHTML;
                        }


                    }

                }

            }


        }



    //--------------------------------------------------//



        const snapscroll = () =>
        {


            //
            // 1 set for start
            //


            (()=>{

                let allsnaps = document.querySelectorAll('.snaps');

                for (let snapgroup of allsnaps)
                {

                    // set active

                    let haveactive,
                        innerboxeslist = snapgroup.querySelectorAll('.snaps>*');


                    for (let innerBox of innerboxeslist)
                    {
                        if(innerBox.className.match('active'))
                        { 

                            //set whidh of snapzone
                            if(snapgroup.closest('.snaptype-wide'))
                            { snapgroup.style.width = innerBox.offsetWidth+"px"; }

                            snapgroup.style.transform = 'translateX(-'+innerBox.offsetLeft+'px)';
                            haveactive=true;

                        }
                    }


                    if(!haveactive) snapgroup.querySelectorAll('*:first-child')[0].classList.add('active');



                    //set dot

                    if(snapgroup.parentNode.querySelectorAll('.dots'))
                    {

                        let groupchilds = snapgroup.querySelectorAll(".snaps>*");

                        for ( let child of groupchilds )
                        {

                            if(child.parentNode.nextElementSibling)
                            {
                                let dotbox,dot,firstdot;

                                dotbox = child.parentNode.nextElementSiblingm
                                dot  = document.createElement('span');

                                dotbox.appendChild(dot);

                                dot.classList.add('dot');

                                firstdot = dotbox.querySelectorAll('.dot')[0];
                                firstdot.classList.add("active");
                            }

                        }

                    }

                }

            })();


            //
            // 2 make dynamic
            //


            let Xsnap = document.querySelectorAll('.snap-x'),
                Ysnap = document.querySelectorAll('.snap-y');


            if(Xsnap)
            {

                (xSnapping = () =>{

                let xl = Xsnap.length;
                for (let i = 0; i < xl; i++)
                {


                    let MainSnap = Xsnap[i],
                        startX, dirX, Active, LatestActive, check_position,
                        Dot, LabelsGroup, Labels, Next, Prev,
                        SnapCenter = [...MainSnap.querySelectorAll('*[class*="snaptype"]')][0],
                        SnapGroup = [...MainSnap.querySelectorAll('.snaps')][0],
                        Boxes = [...SnapGroup.querySelectorAll('.snaps>*')],
                        haveLabels = false,
                        haveDots = false,
                        autosnapping=true,
                        snaptype=false;


                    // check if is wide or blocks
                    if( SnapGroup.closest('.snaptype-wide') ) snaptype=true;
                    else if ( SnapGroup.closest('.snaptype-blocks') ) snaptype=false;
                    else debug(`:: [⚠ ui alert]: wrong snap-x\n   ⮑ deprecated api or snapstype-xxx not found!`);

                    //check initial active 
                    if(SnapGroup.querySelectorAll('.snaps>.active').length <= 0 )
                    { Active = Boxes[0]; debug(`:: [⚠ ui alert]: wrong snap-x\n   ⮑ active class not found!`); }
                    else
                    { Active = findActive(SnapGroup,Active,null,snaptype); }

                    // find labels
                    if(MainSnap.querySelectorAll('.snaplabels')[0] != null)
                    {
                        haveLabels = true;
                        LabelsGroup = [...MainSnap.querySelectorAll('.snaplabels')][0],
                        Labels = [...MainSnap.querySelectorAll('.snaplabels>*')];
                    }

                    // find dots
                    if(MainSnap.querySelectorAll('.dot')[0] != null)
                    {
                        haveDots = true;
                        Dots = [...MainSnap.querySelectorAll('.dot')];
                    }

                    // find arrow
                    if(MainSnap.querySelectorAll('.next')[0] != null)
                    { Next = [...MainSnap.querySelectorAll('.next')][0];}
                    if(MainSnap.querySelectorAll('.prev')[0] != null)
                    { Prev = [...MainSnap.querySelectorAll('.prev')][0]; }


                    // calculate total width
                    let allboxwidth=0;
                    for (let i = 0; i < Boxes.length; i++) { allboxwidth += Boxes[i].offsetWidth; }
                    let rowboxeswidth = allboxwidth-MainSnap.offsetWidth;

                    //start to 0
                    if(Active.offsetLeft!=0){ SnapGroup.style.transform = 'translateX(-'+(SnapCenter.offsetLeft)+'px)';}


                    ////
                    //// manual snap
                    ////


                    // get device type
                    if(is_touch_device())
                    {
                        SnapGroup.ontouchstart = xsnap_dragStart;
                        SnapGroup.ontouchmove = xsnap_dragMove;
                    }
                    else
                    {
                        SnapGroup.onmousedown  = xsnap_dragStart;
                        SnapGroup.onmousedrag = xsnap_dragMove;
                    }


                    // on start drag
                    function xsnap_dragStart (SnapEvent)
                    {

                        if( SnapEvent.target.tagName.toLowerCase() != "a" && !SnapEvent.target.closest('.snagroup a')  )
                        {

                            SnapEvent.preventDefault();
                            SnapEvent.stopPropagation();

                            dirX = null;

                            if(is_touch_device())
                            {
                                startX = SnapEvent.touches[0].clientX;
                                document.ontouchmove = xsnap_dragMove;
                            }
                            else
                            {
                                startX = SnapEvent.clientX;
                                document.onmousemove = xsnap_dragMove;
                            }

                            Active = findActive(SnapGroup,Active,LatestActive,snaptype);

                        }

                    }


                    // on dragging
                    function xsnap_dragMove (SnapEvent)
                    {


                        SnapEvent.preventDefault();
                        SnapEvent.stopPropagation();
                        autosnapping=false;


                        // check device type
                        dirX = (is_touch_device())? (SnapEvent.touches[0].clientX-startX) : (SnapEvent.clientX-startX);


                        // Find runtime the global Active and the scope Actual
                        let Actual; bl = Boxes.length;
                        for (let i = 0; i < bl; i++)
                        {

                            let boxmin = Boxes[i].offsetLeft,
                                boxmax = Boxes[i].offsetLeft+Boxes[i].offsetWidth,
                                centerdist = (Active.offsetLeft-dirX) + (Boxes[i].offsetWidth/2);

                            if( i==0 && centerdist<boxmax )
                            {
                                Boxes[0].classList.add('active');
                                Actual = Boxes[0];
                            }

                            else if( i==bl-1 && centerdist>=boxmin )
                            {
                                Boxes[bl-1].classList.add('active');
                                Actual = Boxes[bl-1];
                            }

                            else if( i>=1 && i<bl && centerdist>=boxmin && centerdist<=boxmax )
                            {
                                Boxes[i].classList.add('active');
                                Actual = Boxes[i];
                                LatestActive = Active;
                            }

                            else
                            {
                                Actual = Active;
                                Boxes[i].classList.remove('active');
                            }

                            if(haveDots){updateDots(Boxes)}

                        }


                        // check if dragging is in the limits
                        let positon,
                            actualposition = parseInt( (Actual.offsetLeft+(Actual.offsetWidth/2))-dirX ),
                            minimum = parseInt( SnapCenter.offsetLeft ),
                            maximum = parseInt( allboxwidth-SnapCenter.offsetLeft );

                        if(snaptype)
                        {

                            if(actualposition<=minimum)
                            {
                                SnapGroup.classList.add('smooth');
                                if(Actual.previousElementSibling)   position = Actual.previousElementSibling.offsetLeft;
                                else                                position = actualposition;
                            }

                            else if(actualposition>=maximum)
                            {
                                SnapGroup.classList.add('smooth');
                                if(Actual.nextElementSibling)       position = Actual.nextElementSibling.offsetLeft;
                                else                                position = Actual.offsetLeft;

                            }
                            else
                            {
                                SnapGroup.classList.remove('smooth');
                                position = (Actual.offsetLeft-dirX);
                            }

                        }

                        else
                        {

                            if(actualposition<=minimum)
                            {
                                SnapGroup.classList.add('smooth'),
                                position = minimum;
                            }

                            else if(actualposition>=maximum)
                            {
                                SnapGroup.classList.add('smooth'),
                                position = maximum;
                            }

                            else
                            {
                                SnapGroup.classList.remove('smooth'),
                                position = actualposition;
                            }

                        }

                        SnapGroup.style.transform = 'translateX(-'+(position)+'px)';

                        document.ontouchend = xsnap_dragEnd;
                        document.onmouseup = xsnap_dragEnd;


                    }


                    // on drag end
                    function xsnap_dragEnd (SnapEvent)
                    {

                        SnapEvent.preventDefault();
                        SnapEvent.stopPropagation();

                        document.onmousedown = true;
                        document.ontouchstart = true;
                        document.onmousemove = null;
                        document.ontouchmove = null;
                        document.onmouseup = true;
                        document.ontouchend = true;

                        Active = findActive(SnapGroup,Active,LatestActive,snaptype);

                        let positon,
                            activeposition = parseInt( Active.offsetLeft+(Active.offsetWidth/2) ),
                            minimum = parseInt( SnapCenter.offsetLeft ),
                            maximum = parseInt( allboxwidth-SnapCenter.offsetLeft );

                        if(snaptype)
                        {
                            position = Active.offsetLeft;
                        }
                        else
                        {
                            if(activeposition<=minimum)         position = minimum;
                            else if(activeposition>=maximum)    position = maximum;
                            else                                position = parseInt( (Active.offsetLeft+(Active.offsetWidth/2)) );
                        }


                        SnapGroup.classList.add('smooth');
                        SnapGroup.style.transform = 'translateX(-'+position+'px)';

                        clearInterval(check_position);
                        check_position = 0;
                    
                        if(haveLabels){ updateLabels(Boxes,Labels); }

                        setTimeout(()=>{
                            SnapGroup.classList.remove('smooth');
                        },200);

                        setTimeout(()=>{
                            autosnapping=true;
                        },1000);

                    }


                    ////
                    //// auto snap
                    ////


                    if(MainSnap.className.match('autosnap') )
                    {

                        MainSnap.onmouseover = (ase) =>{ autosnapping=false; }
                        MainSnap.onmouseleave = (ase) =>{ autosnapping=true; }
                        MainSnap.ontouchstart = (ase) =>{ autosnapping=false; }
                        MainSnap.ontouchend = (ase) =>{ autosnapping=true; }

                        // timer start/pause/clear
                        let timer = parseInt(MainSnap.className.split('autosnap-[')[1].split(']')[0]);
                        let sliding = setInterval(
                        ()=>{

                            let Active = findActive(SnapGroup,null,null,snaptype);

                            if(autosnapping)
                            {

                                if( !Active.nextElementSibling )
                                {

                                    SnapGroup.classList.add('smooth');
                                    Active.classList.remove('active');
                                    Boxes[0].classList.add('active');

                                    SnapGroup.style.transform = 'translateX(-'+SnapCenter.offsetLeft+'px)';

                                    if(haveLabels){ updateLabels(Boxes,Labels); }
                                    if(haveDots){ updateDots(Boxes); }

                                }

                                else
                                {

                                    Active.classList.remove('active');
                                    Active.nextElementSibling.classList.add('active');
                                    Active = findActive(SnapGroup,null,null,snaptype);

                                    let positon,
                                        activeposition = parseInt( Active.offsetLeft+(Active.offsetWidth/2) ),
                                        minimum = parseInt( SnapCenter.offsetLeft ),
                                        maximum = parseInt( allboxwidth-SnapCenter.offsetLeft );

                                    if(snaptype)
                                    {
                                        position = Active.offsetLeft;
                                    }
                                    else
                                    {
                                      if(activeposition<=minimum)       position = minimum;
                                      else if(activeposition>=maximum)  position = maximum;
                                      else                              position = activeposition;
                                    }

                                    SnapGroup.classList.add('smooth');
                                    SnapGroup.style.transform = 'translateX(-'+position+'px)';

                                    if(haveLabels){ updateLabels(Boxes,Labels); }
                                    if(haveDots){ updateDots(Boxes); }

                                    setTimeout(()=>{
                                        SnapGroup.classList.remove('smooth');
                                    },250)

                                }

                            }

                        },timer);

                    }

                    ////
                    //// prev/next
                    ////

                    if(Next)
                    {

                        Next.onclick = () => {

                            Active = findActive(SnapGroup,Active,LatestActive,snaptype);
                            let NextBox = Active.nextElementSibling;

                            if(NextBox)
                            {

                                SnapGroup.classList.add('smooth');

                                let position = NextBox.offsetLeft;


                                SnapGroup.style.transform = 'translateX(-'+(position)+'px)';

                                Active.classList.remove('active');
                                NextBox.classList.add('active');


                                let ll = Boxes.length;
                                for (let i=0; i<ll; i++)
                                {

                                    if(Boxes[i].className.match('active'))
                                    {
                                        if(haveLabels)
                                        {
                                            Labels[i].classList.add('active');
                                            Labels[i].parentNode.style.transform = 'translateX(-'+Labels[i].offsetLeft+'px)';
                                        }
                                        if(haveDots){updateDots(Boxes)}
                                    }

                                    else {
                                        if(haveLabels)
                                        {
                                            Labels[i].classList.remove('active');
                                        }
                                    }

                                }


                            setTimeout(()=>{
                                SnapGroup.classList.remove('smooth');
                            },300)

                        }

                    }

                  }


                    if(Prev)
                    {

                        Prev.onclick = () => {

                        Active = findActive(SnapGroup,Active,LatestActive,snaptype);
                        let PrevBox = Active.previousElementSibling;

                        if(PrevBox)
                        {

                            SnapGroup.classList.add('smooth');

                            let position = PrevBox.offsetLeft;

                            SnapGroup.style.transform = 'translateX(-'+(position)+'px)';

                            Active.classList.remove('active');
                            PrevBox.classList.add('active');

                            let ll = Boxes.length;
                            for (let i=0; i<ll; i++)
                            {

                                if(Boxes[i].className.match('active'))
                                {
                                    if(haveLabels)
                                    {
                                        Labels[i].classList.add('active');
                                        Labels[i].parentNode.style.transform = 'translateX(-'+Labels[i].offsetLeft+'px)';
                                    }
                                    if(haveDots){updateDots(Boxes)}
                                }

                                else
                                {

                                    if(haveLabels)
                                    {
                                        Labels[i].classList.remove('active');
                                    }
                                }

                            }


                            setTimeout(()=>{
                                SnapGroup.classList.remove('smooth');
                            },300)

                        }

                    }

                }

                }

            })();

        }

    // if(Ysnap)
    // {
    // 
    //   (ySnapping = () =>{
    // 
    //     let yl = Ysnap.length;
    //     for (let i = 0; i < yl; i++)
    //     {
    // 
    // 
    //       let startY, dirY, Active, LatestActive, check_position,
    //           Dot, LabelsGroup, Labels, Next, Prev,
    //           SnapGroup = [...Ysnap[i].querySelectorAll('.snapgroup')][0],
    //           Boxes = [...SnapGroup.querySelectorAll('.snapgroup>*')],
    //           haveLabels = false, haveDots = true,
    //           autosnapping=true;
    // 
    //       // find labels
    //       if(Ysnap[i].querySelectorAll('.snaplabels')[0] != null)
    //       {
    //         haveLabels = true;
    //         LabelsGroup = [...Ysnap[i].querySelectorAll('.snaplabels')][0],
    //         Labels = [...Ysnap[i].querySelectorAll('.snaplabels>*')];
    //       }
    // 
    //       // find dots
    //       if(Ysnap[i].querySelectorAll('.dot')[0] != null)
    //       {
    //         haveDots = true;
    //         Dots = [...Ysnap[i].querySelectorAll('.dot')];
    //       }
    // 
    //       // find arrow
    //       if(Ysnap[i].querySelectorAll('.next')[0] != null)
    //       { Next = [...Ysnap[i].querySelectorAll('.next')][0];}
    // 
    //       if(Ysnap[i].querySelectorAll('.prev')[0] != null)
    //       { Prev = [...Ysnap[i].querySelectorAll('.prev')][0]; }
    // 
    //       // manual snap
    // 
    //       if(is_touch_device())
    //       {
    //         SnapGroup.ontouchstart = ysnap_dragStart;
    //         SnapGroup.ontouchmove = ysnap_dragMove;
    //       }
    //       else
    //       {
    //         SnapGroup.onmousedown  = ysnap_dragStart;
    //         SnapGroup.onmousedrag = ysnap_dragMove;
    //       }
    // 
    // 
    //       function ysnap_dragStart (SnapEvent)
    //       {
    // 
    //           SnapEvent.preventDefault();
    //           SnapEvent.stopPropagation();
    // 
    //           dirY = null;
    // 
    //           if(is_touch_device())
    //           {
    //             startY = SnapEvent.touches[0].clientY;
    //             document.ontouchmove = ysnap_dragMove;
    //           }
    //           else
    //           {
    //             startY = SnapEvent.clientY;
    //             document.onmousemove = ysnap_dragMove;
    //           }
    // 
    //           Active = findActive(SnapGroup,Active,LatestActive);
    //           SnapGroup.style.transform = 'translateY(-'+Active.offsetTop+'px)';
    // 
    //       }
    // 
    //       function ysnap_dragMove (SnapEvent)
    //       {
    // 
    //         SnapEvent.preventDefault();
    //         SnapEvent.stopPropagation();
    //         autosnapping=false;
    // 
    //         SnapGroup.classList.remove('smooth');
    // 
    // 
    //         if(is_touch_device())
    //         { dirY = SnapEvent.touches[0].clientY-startY; }
    //         else
    //         { dirY = SnapEvent.clientY-startY; }
    // 
    // 
    //         let position = Active.offsetTop-dirY;
    // 
    //         SnapGroup.style.transform = 'translateY(-'+(position)+'px)';
    // 
    //         let bl = Boxes.length;
    // 
    //         check_position = setTimeout( checkpos , 75);
    //         function checkpos ()
    //         {
    // 
    //           for (let i = 0; i < bl; i++)
    //           {
    // 
    //             let boxmin = Boxes[i].offsetTop,
    //                 boxmax = Boxes[i].offsetTop+Boxes[i].offsetHeight,
    //                 snapPos = position + (Boxes[i].offsetHeight/2);
    // 
    //             if( i<bl && snapPos>=boxmin && snapPos<=boxmax )
    //             {
    //                 Boxes[i].classList.add('active');
    //                 LatestActive = Active;
    //             }
    //             else if( i>=bl-1 && snapPos>=boxmin )
    //             {
    //                 Boxes[bl-1].classList.add('active');
    //             }
    //             else if( i<=0  && snapPos<boxmax )
    //             {
    //                 Boxes[0].classList.add('active');
    //             }
    //             else
    //             {
    //                 Boxes[i].classList.remove('active');
    //             }
    // 
    //             if(haveDots){ updateDots(Boxes); }
    // 
    //           }
    // 
    //         }
    // 
    // 
    //         document.ontouchend = ysnap_dragEnd;
    //         document.onmouseup = ysnap_dragEnd;
    // 
    //       }
    // 
    //       function ysnap_dragEnd (SnapEvent)
    //       {
    // 
    //         SnapGroup.classList.add('smooth');
    // 
    //         SnapEvent.preventDefault();
    //         SnapEvent.stopPropagation();
    // 
    //         document.ontouchmove = null;
    //         document.onmousemove = null;
    //         document.onmousedrag = null;
    //         SnapGroup.ontouchmove = null;
    //         SnapGroup.onmousemove = null;
    // 
    //         Active = findActive(SnapGroup,Active,LatestActive);
    // 
    //         SnapGroup.classList.add('smooth');
    //         Active.classList.add('active');
    // 
    //         SnapGroup.style.transform = 'translateY(-'+Active.offsetTop+'px)';
    // 
    //         clearInterval(check_position);
    //         check_position = 0;
    // 
    //         if(haveLabels){ updateLabels(Boxes,Labels); }
    // 
    //         setTimeout(()=>{
    //           SnapGroup.classList.remove('smooth');
    //           autosnapping=true;
    //         },200);
    // 
    // 
    //       }
    // 
    //       // auto snap
    //       if(Ysnap[i].className.match('autosnap') )
    //       {
    // 
    //         Ysnap[i].onmouseover = (ase) =>{ autosnapping=false; }
    //         Ysnap[i].onmouseleave = (ase) =>{ autosnapping=true; }
    // 
    //         // timer start/pause/clear
    //         let timer = parseInt(Ysnap[i].className.split('autosnap-[')[1].split(']')[0]);
    //         let sliding = setInterval(
    //           ()=>{
    // 
    //               let Actual = findActive(SnapGroup,Active,LatestActive);
    // 
    //               if(autosnapping)
    //               {
    // 
    // 
    //                 let First = Boxes[0],
    //                     activeoffset = Actual.offsetTop,
    //                     snapperOffset = parseInt(getComputedTranslateX(SnapGroup)),
    //                     lastWdt = parseInt( window.getComputedStyle(Actual, null).getPropertyValue('width') ),
    //                     snapWdt = parseInt( window.getComputedStyle(SnapGroup, null).getPropertyValue('width') );
    // 
    //                 if( !Actual.nextElementSibling )
    //                 {
    //                   SnapGroup.classList.add('smooth');
    //                   Actual.classList.remove('active');
    //                   First.classList.add('active');
    // 
    //                   SnapGroup.style.transform = 'translateY(-'+First.offsetTop+'px)';
    // 
    //                   if(haveLabels){ updateLabels(Boxes,Labels); }
    //                   if(haveDots){ updateDots(Boxes); }
    // 
    //                 }
    // 
    //                 else
    //                 {
    // 
    //                   SnapGroup.classList.add('smooth');
    // 
    //                   SnapGroup.style.transform = 'translateY(-'+Actual.nextElementSibling.offsetTop+'px)';
    // 
    //                   Actual.classList.remove('active');
    //                   Actual.nextElementSibling.classList.add('active');
    // 
    //                   if(haveLabels){ updateLabels(Boxes,Labels); }
    //                   if(haveDots){ updateDots(Boxes); }
    // 
    //                   setTimeout(()=>{
    //                     SnapGroup.classList.remove('smooth');
    //                   },400)
    // 
    //                 }
    // 
    // 
    //               }
    // 
    //           }
    //         ,timer);
    // 
    //       }
    // 
    // 
    //       if(Next)
    //       {
    // 
    //         Next.onclick = () => {
    // 
    //             Active = findActive(SnapGroup,Active,LatestActive);
    //             let NextBox = Active.nextElementSibling;
    // 
    //             if(NextBox)
    //             {
    // 
    //                 SnapGroup.classList.add('smooth');
    // 
    //                 let position = NextBox.offsetTop;
    // 
    // 
    //                 SnapGroup.style.transform = 'translateY(-'+(position)+'px)';
    // 
    //                 Active.classList.remove('active');
    //                 NextBox.classList.add('active');
    // 
    // 
    //                 let ll = Boxes.length;
    //                 for (let i=0; i<ll; i++)
    //                 {
    // 
    //                   if(Boxes[i].className.match('active'))
    //                   {
    //                     if(haveLabels)
    //                     {
    //                       Labels[i].classList.add('active');
    //                       Labels[i].parentNode.style.transform = 'translateY(-'+Labels[i].offsetTop+'px)';
    //                     }
    //                     if(haveDots){ updateDots(Boxes); }
    //                   }
    //                   else {
    //                     if(haveLabels)
    //                     {
    //                       Labels[i].classList.remove('active');
    //                     }
    //                   }
    // 
    //                 }
    // 
    // 
    //                 setTimeout(()=>{
    //                   SnapGroup.classList.remove('smooth');
    //                 },300)
    // 
    // 
    //             }
    // 
    //         }
    //       }
    // 
    //       if(Prev)
    //       {
    //         Prev.onclick = () => {
    // 
    //             Active = findActive(SnapGroup,Active,LatestActive);
    //             let PrevBox = Active.previousElementSibling;
    // 
    //             if(PrevBox)
    //             {
    // 
    //                 SnapGroup.classList.add('smooth');
    // 
    //                 let position = PrevBox.offsetTop;
    // 
    //                 SnapGroup.style.transform = 'translateY(-'+(position)+'px)';
    // 
    //                 Active.classList.remove('active');
    //                 PrevBox.classList.add('active');
    // 
    //                 let ll = Boxes.length;
    //                 for (let i=0; i<ll; i++)
    //                 {
    // 
    //                   if(Boxes[i].className.match('active'))
    //                   {
    //                     if(haveLabels)
    //                     {
    //                       Labels[i].classList.add('active');
    //                       Labels[i].parentNode.style.transform = 'translateY(-'+Labels[i].offsetTop+'px)';
    //                     }
    //                     if(haveDots){ updateDots(Boxes); }
    //                   }
    //                   else {
    //                     if(haveLabels)
    //                     {
    //                       Labels[i].classList.remove('active');
    //                     }
    //                   }
    // 
    //                 }
    // 
    // 
    //                 setTimeout(()=>{
    //                   SnapGroup.classList.remove('smooth');
    //                 },300)
    // 
    //             }
    // 
    //           }
    //       }
    // 
    //     }
    // 
    //   })();
    // 
    // }

            function findActive(SnapGroup,Active,LatestActive,snaptype)
            {


                let Boxes        = SnapGroup.querySelectorAll('.snaps>*'),
                    childslength = Boxes.length,
                    haveActive   = false;

                //check if active exist or is lost
                for (let i = 0; i < childslength; i++)
                {

                    //if exist
                    if(Boxes[i].className.match('active'))
                    {

                        haveActive = true;

                        //if is lock
                        if(Boxes[i].className.match("lock"))
                        {
                            Boxes[i].classList.remove("active");
                            Active = LatestActive;
                            LatestActive.classList.add("active");
                        }

                        //else set it
                        else
                        {
                            Active = boxes[i];
                            LatestActive = Active;
                        }

                    }
                }

                //if not exist, is last saved
                if(!haveActive)
                {
                    Active = LatestActive;
                    LatestActiveIndex = Active;
                }

                //set whidh of snapzone
                if( snaptype )       SnapGroup.style.width = SnapGroup.closest('.snap-x').offsetWidth*Boxes.length+"px";
                else if( !snaptype ) SnapGroup.style.width = Active.offsetWidth+"px";

                return(Active,LatestActive);

            }

            function updateDots(Boxes)
            {

                let bl = Boxes.length;
                for (let i=0; i<bl; i++)
                {

                    let D = [...Boxes[i].parentNode.parentNode.querySelectorAll(".dots>.dot")][i];
                    if(D) { (Boxes[i].className.match('active')) ? D.classList.add('active') : D.classList.remove('active'); }

                }

            }

            function updateLabels(Boxes,Labels)
            {

                let bl = Boxes.length;
                for (let i=0; i<bl; i++)
                {

                    if(Boxes[i].className.match('active'))
                    {
                        Labels[i].classList.add('active');
                        if(Labels[i].closest('.snap-x')) Labels[i].parentNode.style.transform = 'translateX(-'+Labels[i].offsetLeft+'px)';
                        else  Labels[i].parentNode.style.transform = 'translateY(-'+Labels[i].offsetTop+'px)';
                    }
                    else
                    {
                        Labels[i].classList.remove('active');
                    }

                }

            }

        }


    //--------------------------------------------------//



        const autocrop = () =>
        {


            let croppeds = [...document.querySelectorAll('*[class*="autocrop"]')]

            for (let cropped of croppeds)
            {

                if(cropped.style.height == undefined || !cropped.style.height)
                {
                    let ph = String(cropped.parentNode.style.height)+"px";
                    cropped.style.height = ph;
                }

            }


        }



    //--------------------------------------------------//



        const flange = () =>
        {


            let Flanges = [...document.querySelectorAll('*[class*="flange"]')]


            let l = Flanges.length;
            for (let i = 0; i < l; i++)
            {

                setTimeout(()=>{

                    let Flange = Flanges[i],
                        Nav = Flange.closest('NAV'),
                        Trigger = Flange.parentNode,

                        flangeoffs,navoffs,position,
                        flangeheight,parentheight,
                        flangewidth,parentWidth,
                        isopen=false;


                    Flange.parentElement.style.position = 'relative';

                    setTimeout(()=>{

                        if(Flange.className.match('flange-left') || Flange.className.match('flange-right'))
                        {


                            if(Flange.tagName == 'DIV') //equalize height
                            {

                                Flange.style.height = Nav.offsetHeight+'px';

                                flangeoffs = (Flange.parentNode.offsetTop),
                                navoffs = (Nav.offsetTop),
                                positon = (navoffs-flangeoffs);

                                Flange.style.top = positon+'px';

                            }
                            else //center it (by height)
                            {

                                Flange.style.top = 0;

                                flangeheight = (Flange.offsetHeight)/2,
                                parentheight = (Flange.parentNode.offsetHeight)/2,
                                position = (flangeheight-parentheight)*-1;

                                Flange.style.marginTop = position+'px';

                            }

                            if(Flange.className.match('flange-left'))
                            {
                                flangewidth = Flange.offsetWidth;
                                Flange.style.marginLeft = (flangewidth*-1)+'px';
                            }

                        }

                        if(Flange.className.match('flange-top') || Flange.className.match('flange-bottom'))
                        {

                            if(Flange.tagName == 'DIV') //equalize width
                            {

                                flangeoffs = parseInt(Flange.parentNode.offsetLeft),
                                navoffs = parseInt(Nav.offsetLeft),
                                position = navoffs-flangeoffs;

                                Flange.style.left = position+'px';
                                Flange.style.width = Nav.offsetWidth+'px';

                            }
                            else //center it (by width)
                            {

                                let flangewidth = parseInt(Flange.offsetWidth)/2,
                                    parentWidth = parseInt(Flange.parentNode.offsetWidth)/2,
                                    position = (flangewidth-parentWidth)*-1;

                                Flange.style.left = position+'px';

                            }


                            if(Flange.className.match('flange-top'))
                            {
                                Flange.style.top = 0;
                                flangeheight = (Flange.offsetHeight)*-1;
                                Flange.style.marginTop = flangeheight+'px';
                            }


                            if(Flange.className.match('flange-bottom'))
                            {
                                Flange.style.top = 0;
                                parentheight = (Flange.parentNode.offsetHeight);
                                Flange.style.marginTop = (parentheight)+'px';
                            }
                        }

                        //if not have animation motor... create a basic.
                        if ( !Trigger.className.match('fx-') && !Flange.className.match('fx-') )
                        {

                            Trigger.addEventListener('click', event => {toggleFlange(event); }, true);
                            Flange.addEventListener('mouseleave', event => {closeFlange(event); }, false);
                            document.body.addEventListener('click', event => {

                                if(!event.target.closest('NAV'))
                                {
                                    closeFlange(event);
                                }

                                document.body.onclick = null;

                            }, true);

                        }

                    },150)


                    let toggleFlange = (event) =>
                    {

                        if( event.target.closest('li') && (event.target.tagName.toLowerCase() == 'a'  || event.target.closest('a')) )
                        {
                            if(!isopen)
                            {

                                for (let i = 0; i < Flanges.length; i++)
                                {
                                    Flanges[i].classList.remove('active','off');
                                    Flanges[i].classList.add('off');
                                }

                                Flange.classList.add('active');
                                Flange.classList.remove('off');
                                Trigger.classList.add('active');
                                Trigger.classList.remove('off');

                                isopen = true;

                            }

                            else if (isopen)
                            {

                                Flange.classList.add('off');
                                Flange.classList.remove('active');

                                Trigger.classList.add('off');
                                Trigger.classList.remove('active');

                                isopen = false;
                            }
                        }

                    }


                    let closeFlange = (event) =>
                    {

                        Flange.classList.add('off');
                        Flange.classList.remove('active');
                        Trigger.classList.add('off');
                        Trigger.classList.remove('active');

                        setTimeout(()=>{
                            Flange.classList.remove('off','active');
                            Flange.previousElementSibling.classList.remove('off','active');
                        },250)

                        return isopen = false;

                    }

                },200);

            }

        };



    //--------------------------------------------------//



        const grabs = () =>
        {


            const draganddrop = {

                    'layers'
                    :[
                        // 'name': layername,
                        // 'elements'
                        // :[
                        //    {
                        //      'slot' : [slot_element_id, slot_element],
                        //      'box'  :[contente_lement_id, content_element]
                        //    },
                        // ]
                    ]
                };


            // layers census to univoque

            let layerlist=[], census = [];
            for ( let box of [...document.querySelectorAll('.grabbox')] ) { let names = String(box.parentNode.classList).split(' '); for (let name of names){ if(name.startsWith('grabslot')){ census.push(name);}}}
            layerlist = census.filter( (i, n) => { return census.indexOf(i) == n; })


            // save layers

            let ln= 0; for ( let layername of layerlist )
            {
                draganddrop.layers.push({
                    'name': layername,
                    'elements': []
                });
            }


            // save start slots and contents

            for ( let layer of draganddrop.layers )
            {

                let slotfinded = [...document.querySelectorAll("[class*='"+layer.name+"']")]
                for ( let slot of slotfinded )
                {

                    layer.elements.push({
                        'slot': slot,
                        'slotid': slot.id,
                        'box': slot.firstElementChild,
                        'boxid':slot.firstElementChild.id
                    });

                }
            }


            //make grab system

            function detectcollision(X,Y,T)
            {

                let xpos,ypos,parentX,parentY,TLeft,TTop;

                parentY = (T.closest('.scroll-y')) ? T.closest('.scroll-y').scrollTop : 0;
                parentX = (T.closest('.scroll-x')) ? T.closest('.scroll-x').scrollLeft : 0;

                xpos =  (document.body.scrollLeft || window.pageXOffset)  + parentX + X,
                ypos =  (document.body.scrollTop  || window.pageYOffset ) + parentY  + Y;

                TTop    = getoffsetTop(T),  TBottom = (TTop+T.offsetHeight),
                TLeft   = getoffsetLeft(T), TRight  = (TLeft+T.offsetWidth);

                if ( ( ypos>TTop && ypos<TBottom ) && ( xpos>TLeft && xpos<TRight )  ) { return true; }; 

            }

            for (let layer of draganddrop.layers)
            {
                for (let element of layer.elements)
                {


                    element.box.onmouseover = ev_start_grab =>  { (ev_start_grab.target.tagName.toLowerCase()!='input') ? makedragable(element.box) : removedragable(element.box);  };
                    element.box.ontouchstart = ev_start_grab => { (ev_start_grab.target.tagName.toLowerCase()!='input') ? makedragable(element.box) : removedragable(element.box);  };

                    function makedragable(b) {b.draggable = true;}
                    function removedragable(b) {b.draggable = false;}

                    element.box.ondragstart = ev_start_grab =>
                    {

                        if(element.box.draggable==true)
                        {


                            ev_start_grab.preventDefault();
                            ev_start_grab.stopPropagation();

                            // save start stratum (active layer) & make evident

                            let stratum = [...document.querySelectorAll('[class*="'+layer.name+'"]')];
                            for(let slot of stratum) slot.classList.add('stratum');


                            // save start slot & box

                            let startslot = element.slot,
                                startbox  = element.box;


                            // lock start size

                            let startWith    = startbox.offsetWidth,
                                startHeight  = startbox.offsetHeight,
                                starsize     = 'width:'+startWith+'px; height:'+startHeight+'px;',
                                startLeft    = startslot.offsetLeft,
                                startTop     = startslot.offsetTop;

                            startbox.style=starsize;
                            startbox.classList.add('active');
                            startbox.classList.remove('off');

                            startslot.style=starsize;
                            startslot.classList.add('active');
                            startslot.classList.remove('off');


                            // storicize edge wrapper limit

                            var scroller, scrolltarget, iswindow, edgetop, edgeleft, edgeright, edgebottom;

                            if( startbox.closest('.scroll-y') )       { iswindow=false; scroller = startbox.closest('.scroll-y').parentNode }
                            else if(startbox.closest('.scroll-x'))    { iswindow=false; scroller = startbox.closest('.scroll-x').parentNode }
                            else                                      { iswindow=true; scroller = document.documentElement || window; }

                            if(scroller)
                            {

                                if(iswindow)
                                {
                                    edgetop    = parseInt(document.body.scrollTop  || window.pageYOffset)+33,
                                    edgeleft   = parseInt(document.body.scrollLeft || window.pageXOffset)+33,
                                    edgeright  = edgeleft+scroller.offsetWidth-33,
                                    edgebottom = edgetop+scroller.offsetHeight-33;
                                }
                                else
                                {
                                    edgetop    = getoffsetTop(scroller)+33,
                                    edgeleft   = getoffsetLeft(scroller)+33,
                                    edgeright  = getoffsetLeft(scroller)+scroller.offsetWidth-33,
                                    edgebottom = getoffsetTop(scroller)+scroller.offsetHeight-33;
                                }
                            }


                            // make moving box

                            document.ontouchmove = ev_move_grab => { moving(ev_move_grab) } 
                            document.onmousemove = ev_move_grab => { moving(ev_move_grab) } 

                            function moving (ev_move_grab) 
                            {

                                ev_move_grab.preventDefault();
                                ev_move_grab.stopPropagation();


                                // calc pointer position

                                let mX,mY,dirX,dirY;

                                if (ev_move_grab.type == "touchmove")
                                {
                                    mX   = ev_move_grab.touches[0].clientX;
                                    mY   = ev_move_grab.touches[0].clientY;
                                }
                                else
                                {
                                    mX   = ev_move_grab.clientX;
                                    mY   = ev_move_grab.clientY;
                                }


                                // move box in position

                                startbox.style.left = parseInt(mX - (startWith/2)) + "px";
                                startbox.style.top  = parseInt(mY - (startHeight/2)) + "px";


                                // scroll container with box

                                let YCoord = parseInt( (document.body.scrollTop  || window.pageYOffset) + mY ), 
                                    XCoord = parseInt( (document.body.scrollLeft || window.pageXOffset) + mX );
                                 
                                let scrolltarget = (iswindow)?scroller:scroller.firstElementChild;
                                 
                                if( YCoord <= edgetop) { scrolltarget.scrollTop -= 50;  }
                                else if( YCoord >= edgebottom) { scrolltarget.scrollTop += 50;  }
                                 
                                if( XCoord < edgeleft) { scrolltarget.scrollLeft -= 50;  }
                                else if( XCoord > edgeright) { scrolltarget.scrollLeft += 50;  }


                                // is it in layer?

                                let endslot=null;

                                for(let slot of stratum)
                                {

                                    slot.classList.remove('active');

                                    if(slot!=startslot)
                                    {
                                        slot.removeAttribute('style');
                                        slot.firstElementChild.removeAttribute('style');
                                    }

                                    if( detectcollision(mX,mY,slot) )
                                    {

                                        endslot = slot;

                                        if(endslot!=startslot)
                                        {

                                            let ew = endslot.offsetWidth,
                                                eh = endslot.offsetHeight,
                                                sw = startslot.offsetWidth,
                                                sh = startslot.offsetHeight;

                                            endslot.classList.add('active');

                                            endslot.style   = 'width:'+sw+'px; height:'+sh+'px;';
                                            endslot.firstElementChild.style = 'position:absolute; z-index:999; width:'+sw+'px; height:'+sw+'px; left:'+startLeft+'px; top:'+startTop+'px;';
                                            startslot.style = 'width:'+ew+'px; height:'+eh+'px;';

                                        }

                                    }

                                }


                                // on release... 
                                if(ev_start_grab)
                                {
                                    document.onmouseup   = ev_end_grab => { ungrab(startslot,endslot,ev_start_grab,ev_move_grab,ev_end_grab) }
                                    document.ontouchend  = ev_end_grab => { ungrab(startslot,endslot,ev_start_grab,ev_move_grab,ev_end_grab) }
                                    document.ondrop      = ev_end_grab => { ungrab(startslot,endslot,ev_start_grab,ev_move_grab,ev_end_grab) }
                                }


                                //ondrag
                                function ungrab(startslot,endslot,ev_start_grab,ev_move_grab,ev_end_grab)
                                {

                                    // reset calls
                                    document.ontouchmove = null;
                                    document.onmousemove = null;

                                    let grabreset = () =>
                                    {

                                        for(let slot of stratum) slot.classList.remove('stratum');

                                        // reset events
                                        ev_start_grab=null;
                                        ev_move_grab=null;
                                        ev_end_grab=null;

                                        grid_y();
                                        grabs();

                                    }

                                    if(!endslot)
                                    {
                                        removedragable(startslot.firstElementChild);

                                        // release grag
                                        startbox.classList.add('off');
                                        startslot.classList.add('off');

                                        // reset box
                                        setTimeout(()=>{

                                            startbox.removeAttribute('style');

                                            startbox.classList.remove('active','off');
                                            startslot.classList.remove('active','off');
                                            startbox.setAttribute('style','');
                                            startslot.setAttribute('style','');

                                            grabreset();

                                        },333)

                                    }

                                    else
                                    {

                                        removedragable(startslot.firstElementChild);
                                        removedragable(endslot.firstElementChild);


                                        let primaryslot = startslot,
                                            primarybox  = startbox;

                                        let secondaryslot = endslot,
                                            secondarybox  = endslot.firstElementChild;

                                        primaryslot.appendChild(secondarybox);
                                        secondaryslot.appendChild(primarybox);

                                        primaryslot.classList.remove('active','off');
                                        primaryslot.firstElementChild.classList.remove('active','off');
                                        primaryslot.removeAttribute('style')
                                        primarybox.removeAttribute('style');

                                        secondaryslot.classList.remove('active','off');
                                        secondaryslot.firstElementChild.classList.remove('active','off');
                                        secondaryslot.removeAttribute('style');
                                        secondarybox.removeAttribute('style');

                                        grabreset();

                                    }


                                }

                            }


                        }
                    }


                }
            }


        }



    //--------------------------------------------------//



        const buttons = () =>
        {


            const passwords = () =>
            {

                let btnpasslist = document.querySelectorAll('*[class*="button-password"]');
              
                for (let btn of btnpasslist)
                {

                    let iconText = btn.getElementsByTagName('img')[0],
                        iconPass = btn.getElementsByTagName('img')[1],
                        _Text = btn.getElementsByTagName('input')[0],
                        _Pass = btn.getElementsByTagName('input')[1];

                    iconText.classList.add('active');
                    iconPass.classList.add('off');
                    _Text.classList.add('off');
                    _Pass.classList.add('active');

                    _Pass.value=_Text.value;

                    iconText.onclick = () =>
                    {
                        iconText.classList.replace('active','off');
                        iconPass.classList.replace('off','active');
                        _Text.classList.replace('off','active');
                        _Pass.classList.replace('active','off');
                    }
                      
                    iconPass.onclick = () =>
                    {
                        iconText.classList.replace('off','active');
                        iconPass.classList.replace('active','off');
                        _Text.classList.replace('active','off');
                        _Pass.classList.replace('off','active');
                    }


                    btn.addEventListener('focus',()=>{

                        let copy = setInterval(()=>{
                            btn.querySelectorAll('input.off')[0].value = btn.querySelectorAll('input.active')[0].value;
                        }, 200);

                        btn.addEventListener('blur',()=>{
                            clearInterval(copy);
                        },true)

                    },true)

                }

            }; passwords();


            const starts = () =>
            {

                let buttonstarsboxlist = document.querySelectorAll('.stars');

                for (let btn of buttonstarsboxlist)
                {

                    let actual = btn.previousElementSibling.value,
                        emotion = ['very bad','not good','normal/good','very good','exellent'],
                        html_output,
                        allstarsbox,
                        alllabelbox;

                    // set to start

                    html_output = `<span class="all-stars"></span><span class="all-labels"></span>`
                    btn.innerHTML = html_output;

                    allstarsbox = btn.querySelectorAll('.all-stars')[0];

                    for (let s = 0; s < 5; s++)
                    {
                        html_output = `<svg class="off" data-rating="`+(s+1)+`"><path d="M12.6504 17.8019L18.8304 21.5319L17.1904 14.5019L22.6504 9.77186L15.4604 9.16186L12.6504 2.53186L9.84039 9.16186L2.65039 9.77186L8.11039 14.5019L6.47039 21.5319L12.6504 17.8019Z"/></svg>`;
                        allstarsbox.innerHTML += html_output;
                    }

                    alllabelbox = btn.querySelectorAll('.all-labels')[0];

                    for (let l = 0; l < 5; l++)
                    {
                        html_output = `<p class="hide">`+emotion[l]+`</p>`;
                        alllabelbox.innerHTML += html_output;
                    }


                    let allstars = allstarsbox.getElementsByTagName('svg'),
                        alllabel = alllabelbox.getElementsByTagName('p');


                    // reset active

                    for (let s = 0; s < 5; s++)
                    {
                        allstars[s].classList.remove('active');
                    }


                    for (let s = 0; s < 5; s++)
                    {
                        let star = allstars[s];
                        if (actual == allstars[s].dataset.rating)
                        {
                            star.classList.add('active')
                            star.classList.remove('off');
                        }
                    }

                    for (let s = 0; s < 5; s++)
                    {

                        let star = allstars[s];

                        // set to hover
                        star.addEventListener('mouseover',()=>{

                            for (let t = 0; t < 5; t++)
                            {
                                (t<=s)
                                    ? allstars[t].classList.add('focus')
                                    : allstars[t].classList.remove('focus');

                                (t==s)
                                    ? alllabel[t].classList.replace('hide','show')
                                    : alllabel[t].classList.replace('show','hide');
                            }

                        },true);


                        // reset on blur
                        star.addEventListener('mouseleave',()=>{
                            for (let t = 0; t < 5; t++){    allstars[t].classList.remove('focus');     alllabel[t].classList.replace('show','hide');}
                            for (let t = 0; t < 5; t++){ if(allstars[t].classList.contains('active')) {alllabel[t].classList.replace('hide','show');} }
                        },true);

                        // set to click
                        star.addEventListener('click',()=>{

                            // reset active
                            for (let t = 0; t < 5; t++){ allstars[t].classList.replace('active','off');  alllabel[t].classList.replace('show','hide');}

                            // make active
                            btn.setAttribute('data-stars', star.dataset.rating);
                            star.classList.replace('off','active');
                            alllabel[s].classList.replace('hide','show');


                            if(btn.previousElementSibling.tagName == 'INPUT')
                            {
                                btn.previousElementSibling.value = star.dataset.rating;
                                btn.previousElementSibling.setAttribute('value',star.dataset.rating)
                            }

                        },true);

                    }

                }


            }; starts();


            const numbers = () =>
            {

                let buttonnumberslist = document.querySelectorAll('*[class*="button-number"]');

                for (let btn of buttonnumberslist)
                {


                    // get input values

                    let taginput = btn.querySelectorAll('input[type="number"]')[0],
                        val      = taginput.getAttribute('value'),
                        min      = taginput.getAttribute('min'),
                        max      = taginput.getAttribute('max');

                    // build the numbers into cage

                    btn.insertAdjacentHTML('beforeEnd','<div class="number-slider"></div>');
                    let slide = btn.querySelectorAll('.number-slider')[0];

                    for (let i = min; i <= max; i++) slide.insertAdjacentHTML('beforeEnd',`<span class="number-[`+i+`]"><small>`+i+`</small></span>`);


                    //set active by input

                    slide.querySelectorAll('[class*="number-['+val+']"]')[0].classList.add('active');

                    //slide to start

                    setTimeout(()=>{
                        let numberactive   = [...slide.querySelectorAll('.number-slider>.active')][0],
                            activeposition = ((numberactive.offsetLeft+(numberactive.offsetWidth/2))-(btn.offsetWidth/2));
                            slide.style.transform = 'translateX('+( activeposition*-1 )+'px)';
                    },200);


                    // on drag it

                    slide.ontouchstart = dragStart;
                    slide.onmousedown = dragStart;
                    slide.ontouchmove = dragMove;
                    slide.ontouchend = dragEnd;

                    let startX, dirX;

                    function dragStart(ev_drag_btn_numbers)
                    {

                        let actualposition = slide.style.transform.replace(/[^\d.]/g, '')*-1;

                        if (is_touch_device())
                        {
                            startX = ev_drag_btn_numbers.touches[0].clientX - actualposition;
                        }
                        else
                        {
                            ev_drag_btn_numbers.preventDefault();
                            startX = event.clientX - actualposition;
                            document.onmousemove = dragMove;
                            document.onmouseup = dragEnd;
                        }

                    }

                    function dragMove(ev_drag_btn_numbers)
                    {

                        ev_drag_btn_numbers.preventDefault();

                        if (is_touch_device())
                        {
                            dirX = ev_drag_btn_numbers.touches[0].clientX - startX;
                        }
                        else
                        {
                            dirX = ev_drag_btn_numbers.clientX - startX;
                        }

                        slide.style.transform = "translateX("+dirX+"px)";

                        checkactive();

                    }

                    function dragEnd(ev_drag_btn_numbers)
                    {

                        startX = dirX*-1;
                        startvalueposition = startX*-1;
                        document.onmouseup = null;
                        document.onmousemove = null;

                        let actualposition = slide.style.transform.replace(/[^\d.]/g, '')*-1,
                            active = slide.querySelectorAll('.number-slider>.active')[0],
                            activepos = (active.offsetLeft+active.offsetWidth/2)-btn.offsetWidth/2;

                        slide.classList.add('smooth');
                        slide.style.transform = 'translateX('+( activepos*-1 )+'px)'; //activepos or correction

                        setTimeout(()=>{
                            slide.classList.remove('smooth');
                        },300);

                        taginput.setAttribute('value', active.getElementsByTagName('small')[0].innerText );

                        ev_drag_btn_numbers=null;

                    }

                    function checkactive()
                    {

                        let actualposition = slide.style.transform.replace(/[^\d.]/g, '');

                        //aclual active position
                        let actualactive   = [...slide.querySelectorAll('.number-slider>.active')][0],
                            activeposition = (actualactive.offsetLeft+actualactive.offsetWidth/2)-btn.offsetWidth/2;

                        if( actualposition > activeposition+actualactive.offsetWidth/2 )
                        {

                            if(actualactive.nextElementSibling)
                            {
                                actualactive.nextElementSibling.classList.add('active');
                                actualactive.classList.remove('active');
                                actualactive = [...slide.querySelectorAll('.number-slider>.active')][0];
                            }

                        }

                        else if( actualposition < activeposition-actualactive.offsetWidth/2 )
                        {

                            if(actualactive.previousElementSibling)
                            {
                                actualactive.previousElementSibling.classList.add('active');
                                actualactive.classList.remove('active');
                                actualactive = [...slide.querySelectorAll('.number-slider>.active')][0];
                            }
                        }

                    }


                    // on click next/prev

                    let minus = btn.getElementsByTagName('span')[0],
                        plus  = btn.getElementsByTagName('span')[1];

                    minus.onclick = ()=>
                    {
                        let exactive  = slide.querySelectorAll('.number-slider>.active')[0],
                            newactive = exactive.previousElementSibling;
                        movefromon(exactive,newactive);
                    }
                    plus.onclick = ()=>
                    {
                        let exactive  = slide.querySelectorAll('.number-slider>.active')[0],
                            newactive = exactive.nextElementSibling;
                        movefromon(exactive,newactive);
                    }

                    function movefromon(exactive,newactive)
                    {
                        newactive.classList.add('active');
                        exactive.classList.remove('active');

                        setTimeout(()=>{

                            taginput.setAttribute('value', newactive.getElementsByTagName('small')[0].innerText );

                            let reposition = (newactive.offsetLeft+newactive.offsetWidth/2)-btn.offsetWidth/2;
                            slide.classList.add('smooth');
                            slide.style.transform = 'translateX('+(reposition*-1)+'px)';

                            setTimeout(()=>{
                                slide.classList.remove('smooth');
                            },250);

                        },250);

                    }

                }


            }; numbers();


            const ranges = () =>
            {

                let buttonrangeslist = document.querySelectorAll('*[class*="button-range"]');

                for (let btn of buttonrangeslist)
                {


                    let slider    = btn.querySelectorAll('.slider')[0],
                        monitor   = btn.querySelectorAll('.monitor')[0],
                        inputtags = btn.querySelectorAll('input'),
                        inputsqnt = inputtags.length;


                    monitor.classList.add("off");

                    for (let i = 0; i < inputsqnt; i++)
                    {


                        let range = inputtags[i];

                        // start inputs values
                        let min            = range.getAttribute('min'),
                            max            = range.getAttribute('max'),
                            val            = range.getAttribute('value'),
                            containerwidth = range.offsetWidth,
                            bullet         = range.nextElementSibling.nextElementSibling,
                            haveline;


                        // is it flaot?

                        let type = range.getAttribute('type'),
                            dot = (type.match('float')) ? 2 : 0 ;

                        //get steps (% and not)

                        let matchpercent = ""+range.step,
                            isPercent,
                            stepper;

                        if(matchpercent.match('%'))
                        {
                            isPercent = 1;
                            let stepstring = ""+range.step,
                            stepsplit = stepstring.split('%')[0];
                            stepper = parseFloat(stepsplit);
                        }
                        else
                        {
                            isPercent = 0;
                            stepper = parseFloat(range.step);
                        }

                        //Dot on start position

                        let presetdot = GetPercentage(min,max,val);

                        bullet.style.left = presetdot+"%";

                        setLine();


                        // on drag elements

                        bullet.ontouchstart = btnrange_dragStart;
                        bullet.onmousedown = btnrange_dragStart;


                        let startX, dirX;

                        function btnrange_dragStart(ev_drag_btn_range)
                        {

                            let actualposition = bullet.offsetLeft;

                            if (ev_drag_btn_range.type === "touchstart")
                            {

                                let touchX = (ev_drag_btn_range.touches[0].clientX);
                                    startX = (touchX - actualposition);

                                bullet.ontouchmove = btnrange_dragMove;
                                bullet.ontouchend = btnrange_dragEnd;

                            }
                            else
                            {

                                ev_drag_btn_range.preventDefault();

                                let mouseX = (event.clientX);
                                    startX =  (mouseX - actualposition);

                                document.onmousemove = btnrange_dragMove;
                                document.onmouseup = btnrange_dragEnd;

                            }
                        }


                        function btnrange_dragMove(ev_drag_btn_range)
                        {


                            let prevBullet = range.closest('.sliders').querySelectorAll('b')[i-1], prevElemPosition, prevPercentage;
                            if(prevBullet)
                            {
                                prevElemPosition = parseInt(prevBullet.offsetLeft),
                                prevPercentage = parseInt(GetPercentage(0,containerwidth,prevElemPosition));
                            }
                            else { prevPercentage=-1 }


                            let nextBullet = range.closest('.sliders').querySelectorAll('b')[i+1],nextElemPosition,nextPercentage;
                            if(nextBullet)
                            {
                                nextElemPosition = parseInt(nextBullet.offsetLeft),
                                nextPercentage = parseInt(GetPercentage(0,containerwidth,nextElemPosition));
                            } else(nextPercentage=101)


                            ev_drag_btn_range.preventDefault();


                            dirX = ( is_touch_device() )
                                ? (ev_drag_btn_range.touches[0].clientX - startX)
                                : (ev_drag_btn_range.clientX - startX);


                            if (dirX > -1 && dirX < containerwidth+1)
                            {

                                let bulletpercent, newval;

                                if(!range.step)
                                {

                                    bulletpercent  = GetPercentage(0,containerwidth,dirX);
                                    newval  = GetVal(min,max,bulletpercent);

                                    if(bulletpercent > prevPercentage && bulletpercent < nextPercentage)
                                    {
                                        setdot(bulletpercent,newval);
                                    }

                                }
                                else
                                {


                                    if(isPercent)
                                    {


                                        let stepcut = Number( (containerwidth*stepper)/100 ).toFixed(dot); //is a step in px of container

                                        let pass = -1;
                                        for (let i = min; i < max; i++)
                                        {

                                            pass++;

                                            let rangemid = (stepcut*pass);
                                                rangemin = (rangemid)-(stepcut/2),
                                                rangemax = (rangemid)+(stepcut/2)


                                            if(dirX > rangemin && dirX < rangemax)
                                            {

                                                let actualstep = rangemin+(stepcut/2),
                                                    bulletpercent = GetPercentage(0,containerwidth,actualstep),
                                                    newval  = GetVal(min,max,bulletpercent);

                                                if(bulletpercent > prevPercentage && bulletpercent < nextPercentage)
                                                {
                                                    setdot(bulletpercent,newval);
                                                }

                                            }

                                        }


                                    }
                                    else
                                    {


                                        bulletpercent  = GetPercentage(0,containerwidth,dirX);
                                        newval  = GetVal(min,max,bulletpercent);


                                        let pass = 0;
                                        for (let i = min; i < max; i++)
                                        {

                                            pass++;
                                            let valuepass = Number( ((min-stepper)+(stepper*pass)) );

                                            if(valuepass > max) { return false; }


                                            let rangemin = (valuepass-(stepper/2))
                                                rangemax = (valuepass+(stepper/2));

                                            if(newval > rangemin && newval < rangemax)
                                            {

                                                range.setAttribute('value', valuepass);
                                                val = range.value;

                                                let newmax = max,
                                                    newmin = min;

                                                bulletpercent = GetPercentage(min,max,val)

                                                if(bulletpercent > prevPercentage && bulletpercent < nextPercentage)
                                                {
                                                    setdot(bulletpercent,val);
                                                }

                                            }

                                        }


                                    }

                                }

                                function setdot(bulletpercent,newval,dot)
                                {

                                    bullet.style.left  = bulletpercent+"%";
                                    monitor.style.left = bulletpercent+"%";

                                    if(dot<=0)
                                    {
                                        let roundval = Math.ceil(newval);
                                            monitor.innerHTML = '<small>'+roundval+'</small>';
                                            range.setAttribute('value', roundval);
                                            val = range.value;
                                    }

                                    else
                                    {
                                        monitor.innerHTML = '<small>'+String(newval)+'</small>';
                                        range.setAttribute('value', newval);
                                        val = range.value;
                                    }

                                    monitor.classList.add("active");
                                    monitor.classList.remove("off");

                                }

                                setLine();

                            }


                        }

                        function btnrange_dragEnd(ev_drag_btn_range)
                        {

                            monitor.classList.add("off");
                            setTimeout(()=>{
                                monitor.classList.remove("active");
                            },500)

                            document.onmouseup = null;
                            document.onmousemove = null;

                        }


                        //sub functions...

                        function GetPercentage(min,max,position)
                        {
                            let percentval = Number( ((position-min)/(min-max)) * -100 ).toFixed(dot);
                            return percentval;
                        }

                        function GetVal(min,max,percent)
                        {
                            let fromPerToVal = Number( ((min-max)*percent/100-min)*-1 ).toFixed(dot);
                            return fromPerToVal;
                        }

                        function setLine()
                        {

                            let Lines = [...range.closest('.sliders').querySelectorAll('input+span')],
                                lineslength = Lines.length;

                            for (let i = 0; i < lineslength; i++)
                            {

                                let prev   = [...range.closest('.sliders').querySelectorAll('B')][i-1], from,
                                    actual = [...range.closest('.sliders').querySelectorAll('B')][i], to;

                                if(prev){ from = GetPercentage(0,containerwidth,prev.offsetLeft); }else { from = 0 }

                                to = GetPercentage(0,containerwidth,actual.offsetLeft);

                                let getStartPx = (GetVal(0,containerwidth,from)) ;
                                    getFinishPx = (GetVal(0,containerwidth,to)) ;
                                    widthDifference = getFinishPx-getStartPx;

                                Lines[i].style.width = widthDifference+"px";
                                Lines[i].style.left  = from+"%";

                            }

                        }

                    }

                }


            }; ranges();


            const selects = () =>
            {


                let btnselectslist = document.querySelectorAll('*[class*="button-select"]');


                for (let btn of btnselectslist)
                {


                    let Select    = btn.getElementsByTagName('select')[0],
                        Searcher  = btn.querySelectorAll('[type=search]')[0],
                        Outlabel  = btn.getElementsByTagName('label')[0],
                        Outfield  = btn.querySelectorAll('input')[0],

                        exvalues   = Outfield.value.split(',') || select.value.split(','),
                        isMultiple = (Outfield.multiple)?1:0,
                      
                        Outbox,
                        Accept,
                        selectorbox;


                    // make and set outbox
                  
                    if(Select!=undefined)
                    {


                        //for all, generate a random id from 0 to 1000
                        let SELECTID = Math.floor(Math.random() * 9999);


                        //set target of off canvas
                        btn.setAttribute('target','outbox#select-'+SELECTID);


                        //generate the empty output

                        let searchbar =  (Searcher)? `<div class=button></div>`:``;


                        let select_empty_outbox =
                        `
                            <div class="outbox" id="select-`+SELECTID+`">
                                <div class="overlay">
                                    <div class="side-center">

                                        <div class="selectorbox">

                                            <div><a class="close"><p>Select your option</p> </a></div>

                                            <div>
                                                `+searchbar+`
                                            </div>

                                            <div>
                                                <div class="hide-bar-y">
                                                    <div class="scroll-y">
                                                        <div class="optiongroup">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="button align-center">
                                                    <a class="accept">Close</a>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        `;


                        //print empty output & get it
                        document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',select_empty_outbox);

                        //get/update elements
                        Outbox = document.getElementById("select-"+SELECTID).querySelectorAll('.optiongroup')[0];
                        selectorbox = document.getElementById("select-"+SELECTID).querySelectorAll('.selectorbox')[0];
                        Accept = [...document.getElementById("select-"+SELECTID).querySelectorAll('.selectorbox .accept')][0];

                        //move searcher
                        if(Searcher)
                        {
                            selectorbox.querySelectorAll('.button')[0].appendChild(Searcher);
                            Searcher = [...selectorbox.querySelectorAll('[type=search]')][0];
                        }


                        //get options groups value...
                        let Groups = [...btn.querySelectorAll('OPTGROUP')];

                        let l = Groups.length;
                        for (let i = 0; i < l; i++)
                        {

                            let Group = Groups[i];

                            let Labels = Group.getAttribute('label'), //get all label
                                Options = [...Group.querySelectorAll('option')];  //get all options

                            if(Labels == null)
                            {
                                Labels = '<p></p>';
                            }
                            else
                            {
                                Labels = '<p>'+Group.getAttribute('label')+'</p>';
                            }



                            // create a options list
                            let optslist = [];
                            let l = Options.length;
                          
                            for (let i = 0; i < l; i++)
                            {

                                if(isMultiple)
                                {
                                    let included = exvalues.includes( String(Options[i].value) ),
                                        ischeck = (included) ? 'checked="true"' : '',
                                        istrue  = (included) ? 1 : 0;

                                    let check_html =
                                    `
                                        <div class="button-checkbox" data-option="`+Options[i].value+`">
                                            <input type="checkbox" value="`+istrue+`" `+ischeck+` />
                                            <label>`+Options[i].text+`</label>
                                        </div>
                                    `;
                                    optslist.push(check_html);

                                }

                                else
                                {
                                    optslist.push('<a data-option="'+Options[i].value+'">'+Options[i].text+'</a>')
                                }

                            }


                            //from array list to list of strings
                            let optionslist = String(optslist.join(' '));


                            // print new output contents
                            let output;
                            if(Labels=="<p></p>")
                            {
                                output =
                                `
                                    <div class="nolabel hide"></div>
                                    <div class="options">
                                    `+optionslist+`
                                    </div>
                                `;
                            }
                            else
                            {
                                output =
                                `
                                    <div class="label">
                                        `+Labels+`
                                    </div>
                                    <div class="options">
                                        `+optionslist+`
                                    </div>
                                `;
                            }

                            Outbox.insertAdjacentHTML('beforeEnd',output);

                        }

                        Select.parentNode.removeChild(Select);

                    }



                    Accept.innerHTML = "wainting a choose";

                    let AllVoice  = [...selectorbox.querySelectorAll('.options>*')],
                        vlength   = AllVoice.length,
                        valuelist = [],
                        textslist = [],
                        active    = null;   

                    for (let v = 0; v < vlength; v++)
                    {

                        let voice = AllVoice[v];

                        if(isMultiple)
                        {

                            if( voice.firstElementChild.value==1 || voice.firstElementChild.checked==true )
                            {
                                valuelist.push(voice.getAttribute('data-option'));
                                textslist.push(voice.getElementsByTagName('label')[0].innerText);
                            }

                            else if(v>=vlength-1)
                            {
                                Outfield.value     = valuelist.join();
                                Outlabel.innerHTML = textslist.join();
                            }

                        }

                        else
                        {
                            if(voice.innerText == Outlabel.innerText) voice.classList.add('active');
                        }

                    }


                    for (let v = 0; v < vlength; v++)
                    {
                        AllVoice[v].addEventListener('click', () =>{

                            (valuelist.length<=0) ? Accept.innerHTML = "Accept" :  "Close";
                            let clicked = AllVoice[v];
                            settingValues(AllVoice,clicked,valuelist,textslist,isMultiple);

                        },false);
                    }


                    function settingValues (AllVoice,clicked,valuelist,textslist,isMultiple)
                    {

                        Accept.innerHTML = "OK - SAVE";


                        if(isMultiple)
                        {

                            let valuedata  = clicked.getAttribute('data-option'),
                                valuelabel = clicked.getElementsByTagName('label')[0].innerText,
                                indexdata  = valuelist.indexOf(valuedata),
                                indexlabel = textslist.indexOf(valuelabel);

                            if(clicked.classList.contains('active') || clicked.firstElementChild.value==0 || clicked.firstElementChild.checked==false)
                            {
                                clicked.classList.remove("active");
                                valuelist.push(valuedata);
                                textslist.push(valuelabel)
                            }
                            else if(!clicked.classList.contains('active') || clicked.firstElementChild.value==1 || clicked.firstElementChild.checked==true)
                            {
                                clicked.classList.add("active");
                                valuelist.splice(indexdata, 1);
                                textslist.splice(indexlabel, 1);
                            }

                        }

                        else
                        {

                            for (let t = 0; t < AllVoice.length; t++) AllVoice[t].classList.remove("active");

                            clicked.classList.add("active");
                            active = clicked;
                        }

                    }


                    Accept.onclick = () =>{ printValues(Outfield,Outlabel,valuelist,textslist,isMultiple,active) };

                    function printValues (Outfield,Outlabel,valuelist,textslist,isMultiple,active)
                    {

                        if(isMultiple)
                        {
                            Outfield.value     = valuelist.join();
                            Outlabel.innerHTML = textslist.join();
                        }
                        else
                        {
                            Outlabel.innerText = active.innerText; 
                            Outfield.value     = active.value; 
                        }

                        setTimeout(()=>{ Accept.innerHTML = "CLOSE" },300);

                    }


                    //if have a search

                    if(Searcher)
                    {

                        Searcher.addEventListener('input', () => {

                            let searched = Searcher.value.toLowerCase();

                            for (let v = 0; v < vlength; v++)
                            {
                                let voice = AllVoice[v]; (!voice.innerText.toLowerCase().startsWith(searched))?voice.classList.add('hide'):voice.classList.remove('hide');
                            }

                            for (let v = 0; v < vlength; v++)
                            {
                                let voice       = AllVoice[v],
                                    voiceparent = voice.parentNode,
                                    parentLabel = voiceparent.previousElementSibling;

                                if(parentLabel.classList.contains('label'))
                                {
                                    (voiceparent.childElementCount == voiceparent.querySelectorAll(".hide").length )?parentLabel.classList.add('hide'):parentLabel.classList.remove('hide');
                                } 

                            } 

                        },false);
                 
                    }


                }


            }; selects();


            const dropsdown = () =>
            {

                let buttondropdownlist = [...document.querySelectorAll('*[class*="button-dropdown"]')];

                for (let Btn of buttondropdownlist)
                {
               
                    let Outlabel   = [...Btn.querySelectorAll('label')][0],
                        Searcher   = [...Btn.querySelectorAll('[type=search]')][0],
                        Outfield   = [...Btn.querySelectorAll('input')][0],
                        exvalues   = Outfield.value.split(',') || select.value.split(','),
                        isMultiple = (Outfield.multiple)?1:0,
                        selectorbox;


                    // make and set outbox

                    if(Btn.getElementsByTagName('select'))
                    {

                        let select = Outlabel.nextElementSibling;
               
                        //for all, generate a random id from 0 to 1000
                        let SELECTID = Math.floor(Math.random() * 9999);
               
                        //generate the empty output
                        let select_empty_outbox;
               
                        if(Searcher)
                        {
                          select_empty_outbox =`
                            <div class="selectorbox off">
               
                              <div>
                                <div class=button></div>
                              </div>
               
                              <div class="hide-bar-y">
                                <div class="scroll-y">
                                  <div class="optiongroup">
                                  </div>
                                </div>
                              </div>
               
                            </div>`;
                        }
               
                        else
                        {
                          select_empty_outbox =`
                            <div class="selectorbox off">
                              <div class="hide-bar-y">
                                <div class="scroll-y">
                                  <div class="optiongroup">
                                  </div>
                                </div>
                              </div>
                            </div>`;
                        }
                  
                        //print empty output & get it
                        Btn.insertAdjacentHTML('beforeEnd',select_empty_outbox);
               
                        //get/update elements
                        selectorbox = [...Btn.querySelectorAll('.selectorbox')][0];
               
                        //move searcher
                        if(Searcher)
                        {
                          [...selectorbox.querySelectorAll('.button')][0].appendChild(Searcher);
                          Searcher = [...selectorbox.querySelectorAll('[type=search]')][0];
                        }
               
                  
                        //get options groups value...
                        let Groups = [...Btn.querySelectorAll('OPTGROUP')];
                  
                        let l = Groups.length;
                        for (let i = 0; i < l; i++)
                        {
                  
                          let Group = Groups[i];
                  
                          let Labels = Group.getAttribute('label'), //get all label
                              Options = [...Group.querySelectorAll('option')];  //get all options
                  
                          if(Labels == null)
                          {
                            Labels = '<p></p>';
                          }
                          else {
                            Labels = '<p>'+Group.getAttribute('label')+'</p>';
                          }
                  
                  
                          // create a options list
                          let optslist = [],
                              l = Options.length;
               
                          for (let i = 0; i < l; i++)
                          {
               
                            if(isMultiple)
                            {
                              let included = exvalues.includes( String(Options[i].value) ),
                                  ischeck = (included) ? 'checked="true"' : '',
                                  istrue  = (included) ? 1 : 0;
               
                              let check_html =
                              `
                                <div class="button-checkbox" data-option="`+Options[i].value+`">
                                    <input type="checkbox" value="`+istrue+`" `+ischeck+` />
                                    <label>`+Options[i].text+`</label>
                                </div>
                              `;
                              optslist.push(check_html);
                            }
                            else {
                              optslist.push('<a data-option="'+Options[i].value+'">'+Options[i].text+'</a>')
                            }
                          }
                  
                          //from array list to list of strings
                          let optionslist = String(optslist.join(' '));
                  
                          // print new output contents
                          let output;
                          if(Labels=="<p></p>")
                          {
                            output =
                            `
                            <div class="nolabel hide"></div>
                            <div class="options">
                              `+optionslist+`
                            </div>`;
                          }
                          else
                          {
                            output =
                            `<div class="label">
                             `+Labels+`
                            </div>
                            <div class="options">
                              `+optionslist+`
                            </div>`;
                          }

                          selectorbox.querySelectorAll('.optiongroup')[0].insertAdjacentHTML('beforeEnd',output);

                        }

                        if(isMultiple)
                        {
                            selectorbox.classList.add('multiple');
                        }

                        select.remove();
               
                    }


                    setTimeout(()=>{
                        selectorbox.style.width = Btn.offsetWidth+'px';
                    },500)


                    let clickprevent = false;
                    document.addEventListener('click', event_dropdownclick => {
               
                      if(!clickprevent)
                      {
               
                        clickprevent=true;
               
                        if (!Btn.contains(event_dropdownclick.target))
                        {
                          selectorbox.classList.add('off');
                          setTimeout(()=>{
                            selectorbox.classList.remove('active');
                            setTimeout(()=>{
                              selectorbox.classList.remove('off');
                            },350)
                          },200)
                        }
                        else if(!event_dropdownclick.target.closest('[type=search]') && !event_dropdownclick.target.closest('.button-checkbox'))
                        {
               
                          if(selectorbox.classList.contains('active'))
                          {
                            selectorbox.classList.add('off');
                            selectorbox.classList.remove('active');
                            setTimeout(()=>{
                              setTimeout(()=>{
                                selectorbox.classList.remove('off');
                              },350)
                            },200)
                            
                          }
                          else
                          {
                            selectorbox.classList.add('active');
                            setTimeout(()=>{
                              selectorbox.classList.remove('off');
                            },200)
                          }
                        }
                        
                        setTimeout(()=>{
                          clickprevent=false;
                        },600)
               
                      }
                      
                    });


                    //on click into voice of relative select popup or searcher change


                    let AllVoice  = [...selectorbox.querySelectorAll('.options>*')],
                        vlength   = AllVoice.length,
                        valuelist = [],
                        textslist = [];                


                    for (let v = 0; v < vlength; v++)
                    {

                        let voice = AllVoice[v];

                        if(isMultiple)
                        {

                            if( voice.firstElementChild.value==1 || voice.firstElementChild.checked==true )
                            {
                                valuelist.push(voice.getAttribute('data-option'));
                                textslist.push(voice.getElementsByTagName('label')[0].innerText);
                            }

                            else if(v>=vlength-1)
                            {
                                Outfield.value     = valuelist.join();
                                Outlabel.innerHTML = textslist.join();
                            }

                        }

                        else
                        {
                            if(voice.innerText == Outlabel.innerText)
                            {
                                voice.classList.add('active');
                            }
                        }

                    }


                    for (let v = 0; v < vlength; v++)
                    {

                        AllVoice[v].addEventListener('click', () =>{

                            let clicked = AllVoice[v];
                            printValues(AllVoice,clicked,valuelist,textslist,isMultiple);

                        },false);

                    }


                    function printValues (AllVoice,clicked,valuelist,textslist,isMultiple)
                    {

                        if(isMultiple)
                        {

                            let valuedata  = clicked.getAttribute('data-option'),
                                valuelabel = clicked.getElementsByTagName('label')[0].innerText,
                                indexdata  = valuelist.indexOf(valuedata),
                                indexlabel = textslist.indexOf(valuelabel);

                            if(clicked.classList.contains('active') || clicked.firstElementChild.value==0 || clicked.firstElementChild.checked==false)
                            {
                                clicked.classList.remove("active");
                                valuelist.push(valuedata);
                                textslist.push(valuelabel)
                            }
                            else if(!clicked.classList.contains('active') || clicked.firstElementChild.value==1 || clicked.firstElementChild.checked==true)
                            {
                                clicked.classList.add("active");
                                valuelist.splice(indexdata, 1);
                                textslist.splice(indexlabel, 1);
                            }

                            Outfield.value     = valuelist.join();
                            Outlabel.innerHTML = textslist.join();

                        }

                        else
                        {

                            for (let t = 0; t < AllVoice.length; t++) AllVoice[t].classList.remove("active");

                            clicked.classList.add("active");
                            Outlabel.innerText = clicked.innerText; 
                            Outfield.value = clicked.value; 
                        }

                    }


                    //if have a search

                    if(Searcher)
                    {

                        Searcher.addEventListener('input', () => {

                            let searched = Searcher.value.toLowerCase();

                            for (let v = 0; v < vlength; v++)
                            {
                                let voice = AllVoice[v]; (!voice.innerText.toLowerCase().startsWith(searched))?voice.classList.add('hide'):voice.classList.remove('hide');
                            }

                            for (let v = 0; v < vlength; v++)
                            {
                                let voice       = AllVoice[v],
                                    voiceparent = voice.parentNode,
                                    parentLabel = voiceparent.previousElementSibling;

                                if(parentLabel.classList.contains('label'))
                                {
                                    (voiceparent.childElementCount == voiceparent.querySelectorAll(".hide").length )?parentLabel.classList.add('hide'):parentLabel.classList.remove('hide');
                                } 

                            } 

                        },false);

                    }

                    //on resize...

                    window.onresize = () =>{ selectorbox.style.width = Btn.offsetWidth+'px'; }

                }


            }; dropsdown();


            const clocks = () =>
            {

                let buttonclocklist = document.querySelectorAll('*[class*="button-clock"]');
              
                for (let Btn of buttonclocklist)
                {


                    //for all, generate a random id from 0 to 1000
                    let TIMEPICKERID = Math.floor(Math.random() * 999);

                    //set target of off canvas
                    Btn.setAttribute('target','outbox#times-'+TIMEPICKERID);


                    //generate the empty output
                    let select_empty_outbox =
                    `
                        <div class="outbox" id="times-`+TIMEPICKERID+`">
                            <div class="overlay">
                                <div class="side-center">

                                    <div class="clockbox">

                                        <div>
                                            <a class="close">
                                                <p>Select a time</p>
                                            </a>
                                        </div>

                                        <div>

                                            <span>

                                                <div class="clock">

                                                    <div class="rayline-hours">
                                                    </div>

                                                    <div class="rayline-minutes">
                                                    </div>

                                                    <div class="pivot"></div>

                                                </div>

                                            </span>

                                        </div>

                                        <div>

                                            <div class="display">
                                                <span>
                                                    <span class="button hours"><input type="number" pattern="[0-9]{2}" value="12"/></span>
                                                    <span class="doubledot"><small>:</small></span>
                                                    <span class="button minutes"><input type="number" pattern="[0-9]{2}" value="20"/></span>
                                                </span>
                                                <span>
                                                    <small class="am active">AM</small>
                                                    <small class="pm off">PM</small>
                                                </span>
                                            </div>

                                        </div>

                                        <div>
                                            <p class="warning border-error hide"></p>
                                            <div class="button align-center">
                                                <a class="accept">OK - SAVE</a>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    `;


                    //print empty output & get it

                    document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',select_empty_outbox);
                    let Outbox = document.getElementById("times-"+TIMEPICKERID);


                    let Am = [...Outbox.querySelectorAll('.am')][0],
                        Pm = [...Outbox.querySelectorAll('.pm')][0],

                        Hours = [...Outbox.querySelectorAll('.hours>input')][0],
                        Minutes = [...Outbox.querySelectorAll('.minutes>input')][0],

                        Clock = [...Outbox.querySelectorAll('.clock')][0],
          				RayHours   = [...Outbox.querySelectorAll('.rayline-hours')][0],
          				RayMinutes   = [...Outbox.querySelectorAll('.rayline-minutes')][0],
                        ClockPivot = [...Outbox.querySelectorAll('.pivot')][0],

                        Accept = [...Outbox.querySelectorAll('a.accept')][0];


                    Hours.onmousedown = () =>{ selectfullstring(Hours)  }
                    Hours.ontouchstart = () =>{  selectfullstring(Hours) }
                    Minutes.onmousedown = () =>{  selectfullstring(Minutes) }
                    Minutes.ontouchstart = () =>{  selectfullstring(Minutes) }
                    function selectfullstring (I){ I.select() }


                    //set to start
                    if(Btn.getElementsByTagName('input')[0].value!='')
                    {

                        let start = Btn.getElementsByTagName('input')[0].value,
                            startH = parseInt(start.split(':')[0]),
                            startM = parseInt(start.split(':')[1]);

                        setTimeout(()=>{
                          RayHours.style.transform   = 'rotate('+((360/12*startH)-90)+'deg)' ;
                          RayMinutes.style.transform = 'rotate('+((360/60*startM)-90)+'deg)' ;
                        },500)

                        if(startH>=1 && startH<=9) {startH='0'+startH}; Hours.value = startH;
                        if(startM>=1 && startM<=9) {startM='0'+startM}; Minutes.value = startM;

                    }


                    // set via buttons

                    Hours.onkeyup = () => { if(String(Hours.value).length>=2){ checkhours();  } }
                    Hours.onblur = () => { checkhours(); }


                    function checkhours()
                    {

                        let nH = parseInt(Hours.value);

                        if(Am.classList.contains('active'))
                        { if(nH>12) {nH='01'} else if(nH<1) {nH='12'} else if(nH>=1 && nH<=9) {nH='0'+nH }; }

                        else
                        { if(nH>23) {nH='00'} else if(nH<=-1) {nH='23'} else if(nH<=9) {nH='0'+nH }; }

                        if(nH.length>=3) nH='01';


                        RayHours.classList.add('smooth');
                        RayHours.style.transform = 'rotate('+((360/12*parseInt(nH))-90)+'deg)' ;
                        setTimeout(()=>{ RayHours.classList.remove('smooth'); },300)

                        Hours.value = nH;

                    }  

                    Minutes.onkeyup = () => { if(String(Minutes.value).length>=2){ checkMinutes(); } }
                    Minutes.onblur = () => { checkMinutes(); }

                    function checkMinutes()
                    {

                        let nM = Minutes.value;

                        if(nM>59) {nM='00'} else if(nM<0) {nM='59'} else { if(nM>=0 && nM<=9) {nM='0'+nM } }; 
                      
                        if(nM.length>2) nM='01';

                        RayMinutes.classList.add('smooth');
                        RayMinutes.style.transform = 'rotate('+((360/60*parseInt(nM))-90)+'deg)' ;
                        setTimeout(()=>{ RayMinutes.classList.remove('smooth'); },300)

                        Minutes.value = nM;

                    }

                    // set Am or Pm

                    Am.onclick = () =>
                    {

                        if(!Am.className.match('active'))
                        {

                            Am.classList.add('active'),
                            Am.classList.remove('off'),
                            Pm.classList.add('off'),
                            Pm.classList.remove('active');

                            let hours = parseInt(Hours.value);

                            if(hours == 00)       { hours = 12}
                            if(hours>12)
                            {
                                if(hours <= 22)     { hours = "0"+(hours-12)}
                                else if(hours > 22) { hours = (hours-12)}
                            }

                            Hours.value = hours;
                            checkvalue(Btn,Hours,Minutes,Outbox,Accept)
                        }

                    }

                    Pm.onclick = () =>
                    {

                        if(!Pm.className.match('active'))
                        {

                            Am.classList.add('off'),
                            Am.classList.remove('active'),
                            Pm.classList.add('active'),
                            Pm.classList.remove('off');

                            let hours = parseInt(Hours.value);

                            if(hours == 12) { hours = "00"}
                            else            { hours = hours+12; }

                            Hours.value = hours;
                            checkvalue(Btn,Hours,Minutes,Outbox,Accept)
                        }

                    }


                    // set start angle

                    let startHoursangle = Math.atan2(-90,0) * 180 / Math.PI;
                    RayHours.style.transform = 'rotate('+startHoursangle+'deg)' ;
                    
                    let startMinutesangle = Math.atan2(0,15) * 180 / Math.PI;
                    RayMinutes.style.transform = 'rotate('+startMinutesangle+'deg)' ;


                    //start moving

                    if(is_touch_device())
                    {
                        RayHours.ontouchstart = clockStart;
                        RayMinutes.ontouchstart = clockStart;
                    }
                    else
                    {
                        RayHours.onmousedown = clockStart;
                        RayMinutes.onmousedown = clockStart;
                    }


                    let center,isHours,isMinutes;


                    function clockStart(event_clockdrag)
                    {


                        event_clockdrag.preventDefault();
                        event_clockdrag.stopPropagation();

                        let rect = ClockPivot.getBoundingClientRect();
                        center = {
                            x: window.scrollX + rect.left,
                            y: window.scrollY + rect.top
                        };

                        if(event.target == RayHours)
                        {
                            isHours = true;
                            isMinutes = false;
                        }
                        else if(event.target == RayMinutes)
                        {
                            isHours = false;
                            isMinutes = true;
                        }

                        (is_touch_device())
                            ? document.ontouchmove = clockMove 
                            : document.onmousemove = clockMove;
                    }

			        function clockMove(event)
                    {

                        let deltaX, deltaY, angle;

                        if(is_touch_device())
                        {
                            deltaX = event.touches[0].clientX - center.x,
                            deltaY = event.touches[0].clientY - center.y,
                            angle = (Math.atan2(deltaY, deltaX) * 180 / Math.PI);
                        }
                        else
                        {
                            deltaX = event.pageX - center.x,
                            deltaY = event.pageY - center.y,
                            angle = (Math.atan2(deltaY, deltaX) * 180 / Math.PI) ;
                        }

                        if(isHours)
                        {

                            //calc percent of angle

                            let min = -180, max = 180,
                                anglepercent = parseInt( ((angle-min)/(min-max)) * -100 );

                            //calc percent steps

                            let steppercent = [];
                            for (let i = 0; i < 14; i++)
                            {
                                let step = parseInt( (i*100)/12 );
                                steppercent.push(step)
                            }

                            //loop step on percent

                            let sl = steppercent.length;
                            for (let i = 0; i < sl; i++)
                            {

                                if(anglepercent > steppercent[i-1] && anglepercent < steppercent[i+1])
                                {

                                    let fromPertoDeg = Math.round( (min-max)*steppercent[i]/100-min )*-1; //from % to degree

                                    RayHours.style.transform = 'rotate('+fromPertoDeg+'deg)' ;

                                    let hours = parseInt(i-3);

                                    if(Am.className.match('active'))
                                    {
                                        if(hours == 0)              { hours = "12"}
                                        else if(hours<0 && hours<10){ hours = i+9; }
                                        else if(hours <= 9)         { hours = "0"+hours}
                                    }
                                    else
                                    {
                                        if(hours == 0)              { hours = "00"}
                                        else if(hours<0 && hours<10){ hours = i+(9+12); }
                                        else if(hours <= 9)         { hours = (hours+12)}
                                    }

                                    Hours.value = hours;

                                }
                            }

                        }

                        else if(isMinutes)
                        {

                            //calc percent of angle

                            let min = -180,
                                max = 180,
                                anglepercent = parseInt( ((angle-min)/(min-max)) * -100 );


                            //calc percent steps

                            let steppercent = [];
                            for (let i = 0; i < 62; i++)
                            {
                                let step = parseInt( (i*100)/60 );
                                steppercent.push(step)
                            }

                            //loop step on percent
                            let sl = steppercent.length;
                            for (let i = 0; i < sl; i++)
                            {

                                if(anglepercent > steppercent[i-1] && anglepercent < steppercent[i+1])
                                {

                                    let fromPertoDeg = Math.round( (min-max)*steppercent[i]/100-min )*-1 ; //from % to degree

                                    RayMinutes.style.transform = 'rotate('+fromPertoDeg+'deg)';

                                    let minuts = i-15;

                                    if(minuts<0)        { minuts = i+45; }

                                    if(minuts == 60)    { minuts = "00"}
                                    else if(minuts <= 9){ minuts = "0"+minuts}

                                    Minutes.value = minuts;

                                }

                            }

                        }

                        RayHours.ontouchend   = clockStop;
                        RayMinutes.ontouchend = clockStop;
                        document.onmouseup    = clockStop;
                    }


      				function clockStop(event)
                    {

                        event_clockdrag = null;
                        document.ontouchstart = null;
                        document.onmousedown = null;
                        document.ontouchmove = null;
                        document.onmousemove = null;
                        document.onmouseup = null; 


                        checkvalue(Btn,Hours,Minutes,Outbox,Accept)

      				}
                  

                    function checkvalue(Btn,Hours,Minutes,Outbox,Accept)
                    {

                        let selectedHours   = Hours.value,
                            selectedMinutes = Minutes.value;

                        let btnImp = Btn.getElementsByTagName('input')[0];


                        if(btnImp.min&&btnImp.max)
                        {

                            if(btnImp.min&&!btnImp.max || !btnImp.min&&btnImp.max)
                            {
                                debug(`:: [⚠ ui alert]: wrong clock, no min/max valid\n   ⮑ If you use one, it is mandatory to enter both values`);
                            }
                            else
                            {

                                let Warning     = [...Outbox.querySelectorAll('.warning')][0],
                                    minHours    = btnImp.min.split(':')[0],
                                    minMintes   = btnImp.min.split(':')[1],
                                    maxHours    = btnImp.max.split(':')[0],
                                    maxMinutes  = btnImp.max.split(':')[0];

                                if(selectedHours<minHours || selectedHours>maxHours)
                                {

                                    Warning.innerHTML = 'This Time is not available';
                                    Warning.classList.remove('hide');
                                    Accept.classList.add('disabled');
                                    Accept.innerText= 'OUT OF RANGE'

                                }
                                else
                                {

                                    Warning.classList.replace('active','off');
                                    Warning.classList.add('hide');
                                    Accept.classList.remove('disabled');
                                    Accept.innerText= 'OK - SAVE';

                                    Accept.addEventListener('click', event_acceptClockTime => {
                                        Btn.querySelectorAll('.button-clock>label')[0].innerText = selectedHours+":"+selectedMinutes;
                                        Btn.querySelectorAll('.button-clock>input')[0].value = selectedHours+":"+selectedMinutes;
                                    },false)

                                }

                            }

                        }
                        else
                        {
                            Accept.innerText= 'OK - SAVE';
                            Accept.addEventListener('click', event_acceptClockTime => {
                                Btn.querySelectorAll('.button-clock>label')[0].innerText = selectedHours+":"+selectedMinutes;
                                Btn.querySelectorAll('.button-clock>input')[0].value = selectedHours+":"+selectedMinutes;
                            },false)

                        }

                    }

                }
              
            }; clocks();


            const checks = () =>
            {

                let btncheckboxlist = document.querySelectorAll('*[class*="button-checkbox"]');

                for (let btn of btncheckboxlist)
                {

                    let inputtag = btn.firstElementChild;

                    btn.onclick = ev_click_checkboxbutton =>
                    {

                        if(!inputtag.checked)
                        {  
                            inputtag.setAttribute('checked',true);
                            inputtag.checked = true;
                            inputtag.value = 1;
                        }
                        else
                        {  
                            inputtag.setAttribute('checked',false);
                            inputtag.checked = false;
                            inputtag.value = 0;
                        }

                    }

                }

            }; checks();


            const radios = () =>
            {

                let buttonradiolist = document.querySelectorAll('*[class*="button-radio"]');
                      
                for (let btn of buttonradiolist)
                {

                    let inputtag = btn.firstElementChild;

                    btn.onclick = ev_click_radiobutton =>
                    {

                        let inpgroup = document.querySelectorAll('[name="'+inputtag.getAttribute('name')+'"]'),
                            btnsqnt  = inpgroup.length;

                            for (let i = 0; i < btnsqnt; i++)
                            {
                                inpgroup[i].setAttribute("checked", false);
                                inpgroup[i].checked = false;
                                inpgroup[i].value = 0;
                            }

                            inputtag.setAttribute("checked", true);
                            inputtag.checked = true;
                            inputtag.value = 1;

                    } 

                }


            }; radios();


            const datepikers = () =>
            {


                let buttondatepickerslist = [...document.querySelectorAll('*[class*=button-date]')];

                for (let Btn of buttondatepickerslist)
                {

                    let Outlabel  = [...Btn.getElementsByTagName('label')][0],
                        OutFields = [...Btn.getElementsByTagName('input')],
                        FieldsQnt = OutFields.length,
                        onfocus   = 1,
                        datelist  = [];

                    if(FieldsQnt>2)
                    {
                        debug(`:: [🛈 viƨor info]: button-date oversized\n   ⮑ The maximum amount of inputs is two: "start date", "end date".`);
                        Btn.classList.add('debug-error');
                    }
                    else if(FieldsQnt<1)
                    {
                        debug(`:: [🛈 viƨor info]: button-date subsized\n   ⮑ The minumum amount of inputs is one: are you kidding me?`);
                        Btn.classList.add('debug-error');
                    }

                    else
                    {


                        //
                        //  1: get type and format of dates
                        //


                        let isUTC, isEUR, Yi,Mi,Di;


                        // is it UTC or EUR? // not EUR.. then UTC

                        (Btn.classList.contains("EUR")) ? (isUTC=!1,isEUR=!0) : (isUTC=!0,isEUR=!1) ;


                        // check date format

                        let dateformat,
                            datepickerclasses = [...String(Btn.className).split(' ')],
                            formatkey = ["DMY","DYM","MYD","MDY","YDM","YMD"],
                            fkl = formatkey.length;

                        for (let i=0;i<fkl;i++)
                            if(!(datepickerclasses.indexOf(formatkey[i]) === -1))
                                dateformat = String(formatkey[i]);

                        // get order of format
                        Yi =  dateformat.indexOf('Y');
                        Mi =  dateformat.indexOf('M');
                        Di =  dateformat.indexOf('D');


                        //
                        //  2: get basic params
                        //


                        // set unselected start / end

                        for (let i = 0; i < FieldsQnt; i++)
                          datelist.push({ 'year':null, 'month':null, 'day':null });


                        //        
                        //  3: get actual/start selected date via input or UTC
                        //


                        if(OutFields[0].value=='')
                        {

                            let todaydate  = new Date(),
                                format     = todaydate.toUTCString(),
                                utc_year   = parseInt(todaydate.getUTCFullYear()),
                                utc_month  = parseInt(todaydate.getUTCMonth()),
                                utc_day    = parseInt(todaydate.getUTCDate());
                            // this_week = date.getUTCDay();

                            datelist[0].year  = utc_year;
                            datelist[0].month = utc_month;
                            datelist[0].day   = utc_day;

                            if(FieldsQnt==2)
                            {
                                datelist[1].year = utc_year;
                                datelist[1].month= utc_month;
                                datelist[1].day  = utc_day+1;
                            }

                        }

                        else
                        {

                            let datestart = OutFields[0].value,
                                format;

                            if(datestart.match('-'))
                            {
                                datelist[0].year  = parseInt(datestart.split('-')[Yi]); 
                                datelist[0].month = parseInt(datestart.split('-')[Mi])-1;
                                datelist[0].day   = parseInt(datestart.split('-')[Di]);
                            }
                            else
                            {
                                datestart         = new Date(parseInt(datestart));
                                format            = datestart.toUTCString();
                                datelist[0].year  = parseInt(datestart.getUTCFullYear()); 
                                datelist[0].month = parseInt(datestart.getUTCMonth());
                                datelist[0].day   = parseInt(datestart.getUTCDate());
                            }


                            if(FieldsQnt==2)
                            {

                                let dateend   = OutFields[1].value;

                                if(dateend.match('-'))
                                {
                                    datelist[1].year  = parseInt(dateend.split('-')[Yi]); 
                                    datelist[1].month = parseInt(dateend.split('-')[Mi])-1;
                                    datelist[1].day   = parseInt(dateend.split('-')[Di]);
                                }
                                else
                                {
                                    dateend           = new Date( parseInt(dateend) );
                                    format            = dateend.toUTCString();
                                    datelist[1].year  = parseInt(dateend.getUTCFullYear()); 
                                    datelist[1].month = parseInt(dateend.getUTCMonth());
                                    datelist[1].day   = parseInt(dateend.getUTCDate());
                                }

                            }

                        }


                        //
                        //  3: create, connect empty datepicker outbox / get from it
                        //

                        // for all, generate a random id from 0 to 1000

                        let DATEID = Math.floor(Math.random() * 999);

                        // set target of off canvas

                        Btn.setAttribute("target","outbox#datepicker-"+DATEID);

                        // generate the empty output

                        let fromto = (FieldsQnt==2) ? `<div class="grid-x fromto"><small class="box-[50-50-50] active"> FRIST DATE </small><small class="box-[50-50-50] off"> END DATE </small></div>` : `<!--singledate-->` ;

                        let empty_output_datepicker =
                        `
                            <div class="outbox gpuboost" id="datepicker-`+DATEID+`">
                                <div class="overlay">
                                    <div class="side-center">

                                        <div class="datepicker">

                                            <div>
                                                <a class="close"><p>Select a date</p></a>
                                            </div>

                                            <div>
                                                `+fromto+`
                                            </div>

                                            <div>

                                                <div>

                                                    <div class="years">
                                                        <span class="prev">&nbsp;</span>
                                                        <span class="year_list"></span>
                                                        <span class="next">&nbsp;</span>
                                                    </div>

                                                </div>

                                                <div>

                                                    <div class="months">
                                                        <span class="prev">&nbsp;</span>
                                                        <span class="month_list"></span>
                                                        <span class="next">&nbsp;</span>
                                                    </div>

                                                </div>

                                            </div>

                                            <div>

                                                <div class="weekday_list">
                                                    <div class="grid-x align-center">
                                                    </div>
                                                </div>

                                            </div>

                                            <div>

                                                <div class="day_list">
                                                    <div class="grid-x">
                                                    </div>
                                                </div>

                                            </div>

                                            <div>

                                                <div class="button align-center">
                                                    <a class="accept">OK - SAVE</a>
                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        `;

                        // print output in page

                        document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',empty_output_datepicker);

                        // get output in page

                        let Datepicker = [...document.querySelectorAll("#datepicker-"+DATEID)][0];

                        // get datepiker elements

                        let Accept = [...Datepicker.querySelectorAll(".accept")][0],
                            year_list     = [...Datepicker.querySelectorAll(".year_list")][0],
                            month_list    = [...Datepicker.querySelectorAll(".month_list")][0],
                            weekday_list  = [...Datepicker.querySelectorAll(".weekday_list>div")][0],
                            day_list      = [...Datepicker.querySelectorAll(".day_list>div")][0];


                        //
                        // 4.1: populate years for a start
                        //

                        // create year list

                        let y_htmlcontents = [],
                            yearmin,
                            yearmax;

                        let ininputmin = parseInt(Btn.firstElementChild.min),
                            ininputmax = parseInt(Btn.firstElementChild.max);


                        if(!ininputmin || ininputmin=='' && !ininputmax || ininputmax=='')
                        {

                            yearmin = 1950;
                            yearmax = 2050;

                        }

                        else
                        {

                            if(!ininputmax || ininputmin>ininputmax)
                            {
                                debug(`:: [🛈 viƨor info]: button-date strange min/max\n   ⮑ The max value is undefined or min is over to max.\n      Will be applied standard max "2050"`);
                                yearmin = ininputmin;
                                yearmax = 2050;
                            }

                            else if(!ininputmin)
                            {
                                debug(`:: [🛈 viƨor info]: button-date strange min/max\n   ⮑ The min value is undefined.\n      Will be applied standard min "1950"`);
                                yearmin = 1950;
                                yearmax = ininputmax;
                            }

                            else
                            {
                                yearmin = ininputmin;
                                yearmax = ininputmax;
                            }

                        }

                        for (let i = yearmin; i <= yearmax; i++)
                            y_htmlcontents.push('<p class="off hide">'+ i +'</p>');


                        y_htmlcontents =  String( y_htmlcontents.join(' ') );
                        year_list.innerHTML =  y_htmlcontents;


                        // set for start

                        let Years    = [...year_list.querySelectorAll("p")],
                            yearsQnt = Years.length;

                        if(ininputmin == ininputmax)
                        {

                            for (let i = 0; i < yearsQnt; i++)
                            {
                                Years[i].classList.remove("off","hide");
                                Years[i].classList.add("active");
                            }

                        }

                        else
                        {
                            for (let i = 0; i < yearsQnt; i++)
                            {
                                if(parseInt(Years[i].textContent) == datelist[0].year )
                                {
                                    Years[i].classList.remove("off","hide");
                                    Years[i].classList.add("active");
                                }
                            }
                        }


                        //
                        // 4.2: populate months for a start
                        //


                        // create month list

                        let m_htmlcontents = [],
                            monthArray = ['January','February','March','April','May','June','July','August','September','October','November','December'];

                        for (let i = 0; i <= 11; i++)
                            m_htmlcontents.push('<p class="off hide">'+ monthArray[i] +'</p>');

                        m_htmlcontents =  String( m_htmlcontents.join(' ') );
                        month_list.innerHTML =  m_htmlcontents;


                        // set for start

                        let Months = [...month_list.querySelectorAll("p")],
                            monthsQnt = Months.length;

                        for (let i = 0; i < monthsQnt; i++)
                        {
                            if(i == datelist[0].month)
                            {
                                Months[i].classList.remove("off","hide");
                                Months[i].classList.add("active");
                            }
                        }


                        //
                        // 4.3: populate weekdays
                        //

                        // create weekday list

                        let dw_htmlcontents = [], dayweeks;

                        if(isEUR) { dayweeks = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]; }
                        else      { dayweeks = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]; }

                        // if(isEUR) { dayweeks = ["Lun","Mar","Mer","Gio","Ven","Sab","Dom"]; }
                        // else      { dayweeks = ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"]; }


                        for (let i = 0; i < dayweeks.length; i++)
                            dw_htmlcontents.push( '<div class="box-[14-14-14]"><small>'+ dayweeks[i] +'</small></div>' );

                        //print dayweek
                        dw_htmlcontents = String( dw_htmlcontents.join(' ') );
                        weekday_list.innerHTML =  dw_htmlcontents;



                        //
                        // 4.4: populate days...
                        //


                        // ::: daylist not have a start print. It's auto created by utc data
                        // ::: after selected, or have in start, an year and month sys can "get days list of that date"
                        // ::: ex: get days quantity of "May" "2001" -> get the days qnt of that date
                        // ::: attention get days qnt start to 0 and need +1 (8+1 = sept) ...


                        let get_DaysQntOfMounth = (YY,MM) =>
                        {
                            // get day list of year/month
                            let getDate = new Date( Date.UTC(YY,MM+1,null) );
                            return parseInt(  getDate.getUTCDate() );
                        }

                        // ::: Since calendars start with different weeks
                        // ::: (for example in EU start from Monday, not Sunday),
                        // ::: it will be necessary to understand what day 1 is
                        // ::: compared to the first day of the week
                        // ::: attention get weekday start to 1 (8 is sept) and return 0 Sunday, 1 Monday, 2 Tuesday, ...


                        let get_FirstDayOfweek = (YY,MM) =>
                        {
                            // get first dayweek of year/month
                            let getDate = new Date( Date.UTC(YY,MM,1) );
                            return parseInt( getDate.getUTCDay() );
                        }


                        // ::: having the methods created above, we can
                        // ::: get a daylist of specific date (in this case, the start).

                        let make_days_table = (YY,MM,DD) =>
                        {


                            day_list.innerHTML = '';


                            let firstdayweek     = get_FirstDayOfweek(YY,MM),
                                dayinactualmonth = get_DaysQntOfMounth(YY,MM),
                                calendarcell     = 44, // remember: start to 0
                                d_htmlcontents   = [],
                                daytabulator     = parseInt(  (calendarcell-(firstdayweek+1)) );

                            for (let i = (isEUR)?(firstdayweek+5)*-1:(firstdayweek-1)*-1; i <= daytabulator; i++)
                            {

                                let day = i, status = "off", style="";

                                if(day>=1 && day<=9) { day="0"+i }
                                if(day<=0 || i>dayinactualmonth){ day = "░", style='style="opacity:0.5"', status = "off disabled" }
                                else if(day == DD) { status = "active", style='' }

                                d_htmlcontents.push('<div class="box-[14-14-14]" '+style+'><p class="day '+status+'">'+ day +'</p></div>'); //dayout

                            }


                            d_htmlcontents = String(d_htmlcontents.join(' '));
                            day_list.innerHTML =  d_htmlcontents;


                            // in case of line of day is empty (compact mode)

                            if(Btn.className.match('-compact'))
                            {

                                (() =>{

                                    let FirsLineDays = [...Datepicker.querySelectorAll('.day_list .day')].slice(0,7),
                                        firstline = 0;

                                    for (let i = 0; i <= 6; i++)
                                        if(FirsLineDays[i].textContent === "░") { firstline++; };

                                    if(firstline===7)
                                        for (let i = 0; i <= 6; i++)
                                            FirsLineDays[i].parentNode.innerHTML = "";

                                })();


                                (() =>{

                                    //let LastLineDays = [...Datepicker.querySelectorAll('.day_list .day')].slice(35,42);
                                    let LastLineDays = [...Datepicker.querySelectorAll('.day_list .day')].slice(-7),
                                        lastline = 0;

                                    for (let i = 0; i <= 6; i++)
                                        if(LastLineDays[i].textContent === "░") { lastline++; };

                                    if(lastline===7)
                                        for (let i = 0; i <= 6; i++)
                                            LastLineDays[i].parentNode.innerHTML = "";

                                })();

                            }


                            if(FieldsQnt==2){ printDate(); }

                        }


                        make_days_table(datelist[0].year,datelist[0].month,datelist[0].day); //<== create start


                        // 
                        //  5: set contents via actions
                        // 

                        // find actual static values on call

                        let getActualMonth = () =>
                        {

                            for (let i = 0; i < monthsQnt; i++)
                                if(Months[i].classList.contains("active"))
                                    return i+1;

                        }

                        let getActualYear = () =>
                        {

                            for (let i = 0; i < yearsQnt; i++)
                                if(Years[i].classList.contains("active"))
                                    return parseInt(Years[i].innerText);

                        }

                        let getActualDay = () =>
                        {

                            let days = [...Datepicker.querySelectorAll('.day_list .day')],
                                daysQnt = days.length;

                            for (let i = 0; i < daysQnt; i++)
                                if(days[i].classList.contains("active"))
                                    return parseInt(days[i].innerText);

                        }

                        // A) switch years

                        let YearPrev = Datepicker.querySelector('.years>.prev'),
                            YearNext = Datepicker.querySelector('.years>.next');

                        YearPrev.onclick = () => { goToPrevYear() };
                        YearNext.onclick = () => { goToNextYear() };

                        if(is_touch_device())
                        {

                            year_list.ontouchstart = event_datepiking =>
                            {

                                let dir    = event_datepiking.touches[0].clientX;

                                year_list.ontouchmove = event_datepiking =>
                                {

                                    if (event_datepiking.target != year_list){event_datepiking.preventDefault();}//prevent body scroll
                                    if(dir > event_datepiking.changedTouches[0].clientX+75){dir = event_datepiking.touches[0].clientX; goToPrevYear()}
                                    if(dir < event_datepiking.changedTouches[0].clientX-75){dir = event_datepiking.touches[0].clientX; goToNextYear()}

                                }

                                year_list.ontouchend = event_datepiking =>
                                {

                                    dir = null;
                                    event_datepiking = null;
                                    window.ontouchmove = null;

                                }

                            }

                        }

                        else
                        {

                            year_list.onmousedown = event_datepiking =>
                            {

                                let dir = event_datepiking.clientX;

                                window.onmousemove = event_datepiking =>
                                {
                                    if(dir > event_datepiking.clientX+5){dir = event_datepiking.clientX; goToPrevYear()}
                                    if(dir < event_datepiking.clientX-5){dir = event_datepiking.clientX; goToNextYear()}
                                }

                                window.onmouseup = event_datepiking =>
                                {
                                    dir = null;
                                    event_datepiking = null;
                                    window.onmousemove = null;
                                }

                            }

                        }

                        function goToPrevYear()
                        {

                            for (let i = 0; i < yearsQnt; i++)
                            {

                                if(Years[i].classList.contains("active") && Years[i-1])
                                {

                                    Years[i].classList.add("off","hide");
                                    Years[i].classList.remove("active");

                                    Years[i-1].classList.add("active");
                                    Years[i-1].classList.remove("off","hide");

                                    let f = (onfocus==2 && onfocus==2)?1:0;

                                    datelist[f].year = Years[i-1].innerText;
                                    datelist[f].month = getActualMonth();
                                    datelist[f].day = getActualDay();
                                    make_days_table(datelist[f].year, datelist[f].month, datelist[f].day);

                                    return false;
                                }

                            }

                        }

                        function goToNextYear()
                        {

                            for (let i = 0; i < yearsQnt; i++)
                            {

                                if(Years[i].classList.contains("active") && Years[i+1])
                                {
                                    Years[i].classList.add("off","hide");
                                    Years[i].classList.remove("active");

                                    Years[i+1].classList.add("active");
                                    Years[i+1].classList.remove("off","hide");

                                    let f = (onfocus==2 && onfocus==2)?1:0;

                                    datelist[f].year = Years[i+1].innerText;
                                    datelist[f].month = getActualMonth();
                                    datelist[f].day = getActualDay();
                                    make_days_table(datelist[f].year, datelist[f].month, datelist[f].day);

                                    return false;
                                }

                            }

                        }


                        // B) switch month

                        let MonthPrev = Datepicker.querySelector('.months>.prev'),
                            MonthNext = Datepicker.querySelector('.months>.next');

                        MonthPrev.onclick = () => { goToPrevMonth() };
                        MonthNext.onclick = () => { goToNextMonth() };


                        if(is_touch_device())
                        {
                            month_list.ontouchstart = event_datepiking =>
                            {

                                let dir = event_datepiking.touches[0].clientX;
                                month_list.ontouchmove = event_datepiking =>
                                {
                                    if (event_datepiking.target != month_list){ event_datepiking.preventDefault(); }//prevent body scroll
                                    if(dir > event_datepiking.changedTouches[0].clientX+175){dir = event_datepiking.touches[0].clientX; goToPrevMonth()}
                                    if(dir < event_datepiking.changedTouches[0].clientX-175){dir = event_datepiking.touches[0].clientX; goToNextMonth()}
                                }

                                window.ontouchend = event_datepiking =>
                                {
                                    dir = null;
                                    event_datepiking = null;
                                    window.ontouchmove = null;
                                }
                            }
                        }

                        else
                        {
                            month_list.onmousedown = event_datepiking =>
                            {
                                let dir = event_datepiking.clientX;
                                window.onmousemove = event_datepiking =>
                                {
                                    if(dir > event_datepiking.clientX+35){dir = event_datepiking.clientX; goToPrevMonth()}
                                    if(dir < event_datepiking.clientX-35){dir = event_datepiking.clientX; goToNextMonth()}
                                }
                                window.onmouseup = event_datepiking =>
                                {
                                    dir = null;
                                    event_datepiking = null;
                                    window.onmousemove = null;
                                }
                            }
                        }

                        function goToPrevMonth()
                        {

                            for (let i = 0; i < monthsQnt; i++)
                            {

                                if(Months[i].classList.contains("active") && Months[i-1])
                                {

                                    Months[i].classList.replace("active","off");
                                    Months[i].classList.add("hide");

                                    Months[i-1].classList.add("active");
                                    Months[i-1].classList.remove("off","hide");

                                    let f = (onfocus==2 && onfocus==2)?1:0;

                                    datelist[f].year = getActualYear();
                                    datelist[f].month = i-1;
                                    datelist[f].day = getActualDay();
                                    make_days_table(datelist[f].year, datelist[f].month, datelist[f].day);

                                    return false;

                                }

                            }

                        }

                        function goToNextMonth()
                        {

                            for (let i = 0; i < monthsQnt; i++)
                            {

                                if(Months[i].classList.contains("active") && Months[i+1])
                                {

                                    Months[i].classList.replace("active","off");
                                    Months[i].classList.add("hide");

                                    Months[i+1].classList.add("active");
                                    Months[i+1].classList.remove("off","hide");

                                    let f = (onfocus==2 && onfocus==2)?1:0;

                                    datelist[f].year = getActualYear();
                                    datelist[f].month = i+1;
                                    datelist[f].day = getActualDay();
                                    make_days_table(datelist[f].year, datelist[f].month, datelist[f].day);

                                    return false;

                                }

                            }

                        }
                      
                      
                      
                        // C) switch/make days

                        Datepicker.addEventListener('click', event_dayselection => //update date on every click
                        {

                            let dateselected ={},
                                Days = [...Datepicker.querySelectorAll('.day_list .day')],
                                daysQnt = Days.length;

                            for (let i = 0; i < daysQnt; i++)
                            {

                                Days[i].onclick = () => {

                                    for (let i = 0; i < daysQnt; i++)
                                    {
                                        Days[i].classList.remove("active");
                                        Days[i].classList.add("off");
                                    }

                                    event_dayselection.target.classList.remove("off","hide");
                                    event_dayselection.target.classList.add("active");

                                    let f = (onfocus==2 && onfocus==2)?1:0;

                                    datelist[f].year = getActualYear();
                                    datelist[f].month = getActualMonth();
                                    datelist[f].day = parseInt(event_dayselection.target.innerText);

                                    printDate();
                                }

                            }

                        },true);

                        // D) switch selector from-to

                        if(FieldsQnt==2)
                        {

                            let dateOne = [...Datepicker.querySelectorAll('.fromto>small')][0],
                                dateTwo = [...Datepicker.querySelectorAll('.fromto>small')][1];

                            dateOne.onclick = event_dateSelector =>
                            {

                                //update focus
                                onfocus  = 1; dateOne.classList.replace('off','active'), dateTwo.classList.replace('active','off');

                                //update yeara label
                                for (let i = 0; i < yearsQnt; i++) 
                                {

                                    if(datelist[0].year == Years[i].innerText){ Years[i].classList.remove('off','hide'), Years[i].classList.add('active') }
                                    else { Years[i].classList.remove('active'), Years[i].classList.add('off','hide')}
                                }

                                //update month label
                                for (let i = 0; i < monthsQnt; i++) 
                                {
                                    if(datelist[0].month == i){ Months[i].classList.remove('off','hide'), Months[i].classList.add('active') }
                                    else { Months[i].classList.remove('active'), Months[i].classList.add('off','hide')}
                                }

                                //update daytable
                                make_days_table(datelist[0].year, datelist[0].month, datelist[0].day);

                                event_dateSelector=null;

                            }

                            dateTwo.onclick = event_dateSelector =>
                            {

                                //update focus
                                onfocus  = 2; dateTwo.classList.replace('off','active'), dateOne.classList.replace('active','off');

                                //update yeara label
                                for (let i = 0; i < yearsQnt; i++) 
                                {
                                    if(datelist[1].year == Years[i].innerText){ Years[i].classList.remove('off','hide'), Years[i].classList.add('active') }
                                    else { Years[i].classList.remove('active'), Years[i].classList.add('off','hide')}
                                }

                                //update month label
                                for (let i = 0; i < monthsQnt; i++) 
                                {
                                    if(datelist[1].month == i){ Months[i].classList.remove('off','hide'), Months[i].classList.add('active') }
                                    else { Months[i].classList.remove('active'), Months[i].classList.add('off','hide')}
                                }

                                //update daytable
                                make_days_table(datelist[1].year, datelist[1].month, datelist[1].day);

                                event_dateSelector=null;

                            }

                        }


                        //
                        // 7: update the datepiker and input values
                        //

                        // check date switcher

                        function printDate()
                        {

                            if(FieldsQnt==2)
                            {

                                let datetime1 = new Date(datelist[0].year,datelist[0].month,datelist[0].day+1).getTime(),
                                    datetime2 = new Date(datelist[1].year,datelist[1].month,datelist[1].day+1).getTime(); //sys subtract 1 to refresh D:

                                if(datetime1>=datetime2)
                                {
                                    Accept.parentNode.classList.add('disabled');
                                    Accept.innerText = 'NO VALID DATES!';
                                }

                                else
                                {

                                    let days = [...Datepicker.querySelectorAll('.day_list .day')],
                                        daysQnt = days.length;

                                    //reset
                                    for (let i = 0; i < daysQnt; i++)
                                        days[i].classList.remove('off','date-range','date-range-first','date-range-last');

                                    //setit

                                    let daystart    = datelist[0].day,
                                        dayend      = datelist[1].day,

                                        actualMonth = (onfocus==2)?datelist[1].month:datelist[0].month,
                                        minMonth    = datelist[0].month,
                                        maxMonth    = datelist[1].month,
                                        
                                        actualYear  = (onfocus==2)?datelist[1].year:datelist[0].year,
                                        minYear     = datelist[0].year,
                                        maxYear     = datelist[1].year;

                                    for (let i = 0; i < daysQnt; i++)
                                    {

                                        let dayclass    = days[i].classList,
                                            daynumber   = parseInt(days[i].innerText);

                                        if(Number.isInteger(daynumber))
                                        {

                                            if( actualYear >= minYear && actualYear <= maxYear )
                                            {

                                                if(actualYear==minYear && actualMonth == minMonth && daynumber==daystart) 
                                                {
                                                    dayclass.remove('date-range');
                                                    dayclass.add('date-range-first');
                                                }

                                                else if(actualYear==maxYear && actualMonth == maxMonth && daynumber==dayend) 
                                                {
                                                    dayclass.remove('date-range');
                                                    dayclass.add('date-range-last');
                                                }

                                                else
                                                {

                                                    if(actualMonth == minMonth && actualMonth == maxMonth && daynumber>daystart && daynumber<dayend)
                                                    {
                                                        dayclass.add('date-range');
                                                    }

                                                    else if(actualMonth != minMonth || actualMonth != maxMonth)
                                                    {

                                                        if(actualMonth == minMonth && daynumber>daystart)
                                                        {
                                                            dayclass.add('date-range');
                                                        }
                                                        else if(actualMonth == maxMonth && daynumber<dayend)
                                                        {
                                                            dayclass.add('date-range');
                                                        }
                                                        else if(actualMonth > minMonth && actualMonth < maxMonth)
                                                        {
                                                            dayclass.add('date-range');
                                                        }
                                                        else
                                                        {
                                                            dayclass.remove('date-range');
                                                            dayclass.add('off');
                                                        }

                                                    }

                                                    else
                                                    {
                                                        dayclass.remove('date-range');
                                                        dayclass.add('off');
                                                    }

                                                }

                                            }

                                            else
                                            {
                                                dayclass.remove('date-range');
                                                dayclass.add('off');
                                            }

                                        }


                                    }

                                    Accept.parentNode.classList.remove('disabled');
                                    Accept.innerText = 'OK - SAVE';
                                }

                            }

                            else
                            {
                              OutFields[0].value = new Date(datelist[0].year,datelist[0].month,datelist[0].day).getTime();
                              Outlabel.innerText = datelist[0].day+'-'+(datelist[0].month+1)+'-'+datelist[0].year
                            }

                        }


                        Accept.onclick = () => { 

                            if(FieldsQnt==2)
                            {
                                let datetime1 = new Date(datelist[0].year,datelist[0].month,datelist[0].day+1).getTime(); //sys subtract 1 to refresh D:
                                let datetime2 = new Date(datelist[1].year,datelist[1].month,datelist[1].day+1).getTime();

                                if(datetime1!=OutFields[0].value) OutFields[0].value = datetime1;
                                if(datetime2!=OutFields[1].value) OutFields[1].value = datetime2;
                                Outlabel.innerText = datelist[0].day+'-'+(datelist[0].month+1)+'-'+datelist[0].year+' // '+datelist[1].day+'-'+(datelist[1].month+1)+'-'+datelist[1].year

                            }
                            else
                            {
                              OutFields[0].value = new Date(datelist[0].year,datelist[0].month,datelist[0].day).getTime();
                              Outlabel.innerText = datelist[0].day+'-'+(datelist[0].month+1)+'-'+datelist[0].year
                            }

                        }

                        // //active/off week
                        // let weekinbox = [...weekday_list.querySelectorAll("p")];
                        // for (let i = 0; i < weekinbox.length; i++)
                        // {
                        //
                        //     weekinbox[i].classList.add("off","disabled");
                        //
                        //     if( i == this_week-1 )
                        //     {
                        //       weekinbox[i].classList.remove("off","disabled");
                        //       weekinbox[i].classList.add("active");
                        //     }
                        //
                        // }

                    }

                }


            }; datepikers();


            const filereaders = () =>
            {


                for (let Btn of [...document.querySelectorAll('*[class*="button-file"]')])
                {

                    /* button file : */

                    if ( Btn.querySelectorAll('.actions').length<=0 ) 
                    {
                        Btn.insertAdjacentHTML('beforeEnd','<span class="actions hide"><a class="viewlist">list &#x2630</a>&nbsp;<a class="clearlist">&#10006</a></span>')
                    }


                    let inputfield       = [...Btn.querySelectorAll('input[type="file"]')][0],
                        textfield        = [...Btn.getElementsByTagName('label')][0],
                        startlabeltext   = textfield.innerText;


                        // made primary object for fileloader (if it exsist)
                       
                        let fileloader =    ( !Btn.closest('.fileloader') )
                                            ? 'not fileloader detected'
                                            : {

                                                'container'           : 'not defined',
                                                'input'               : 'not defined',
                                                'resetter'            : 'not defined',
                                                'display'
                                                :{
                                                    'element'         :'not defined',
                                                    'container'       :'not defined'
                                                },

                                                'settings'          
                                                :{
                                                    'type'            : 'not defined',
                                                    'autoconversion'  : 'not defined',
                                                    'preview'         : 'not defined',
                                                    'deleter'         : 'not defined',
                                                    'grabber'         : 'not defined',
                                                    'filters'         : 'not defined',
                                                    'minilabels'      : 'not defined'
                                                },

                                                'compressor'
                                                :{
                                                    'imageMaxWidth'   : 'not defined',
                                                    'imageMaxHeight'  : 'not defined',
                                                    'imageQuality'    : 'not defined'
                                                },

                                                'datalist'
                                                :[
                                                    /*databoxmodel added via file upload => search:"madeNewData"*/
                                                ]

                                            }


                    inputfield.oninput = event_fileloaderinputfieldchange =>
                    {
                        updatebuttonfile(Btn,inputfield,textfield,startlabeltext,fileloader,true);
                        return event_fileloaderinputfieldchange=null;
                    }

                    function updatebuttonfile(Btn,inputfield,textfield,startlabeltext,fileloader,reset)
                    {


                        checkfilelimits( (status,message) => {

                            let actionsbox    = [...Btn.querySelectorAll('.actions')][0],
                                viewlist      = actionsbox.firstElementChild,
                                clearlist     = actionsbox.lastElementChild,
                                filesquantity = inputfield.files.length;


                            actionsbox.classList.add('hide');


                            if(!status)
                            {
                                textfield.closest("[class*='button-file']").classList.add('border-error');
                                textfield.innerHTML = message;
                            }


                            else
                            {

                                textfield.closest("[class*='button-file']").classList.remove('border-error');
                                actionsbox.classList.add('hide');
                                viewlist.classList.add('hide');


                                if(!reset)
                                {

                                    actionsbox.classList.remove('hide');

                                    selected = String( inputfield.value.split('\\')[inputfield.value.split('\\').length - 1] );

                                    textfield.classList.add('active'),
                                    textfield.innerHTML = '&#x2714 '+selected,
                                    // inputfield.setAttribute('value', inputfield.value);

                                    setTimeout( () =>{
                                      textfield.classList.remove('active');
                                    },150);

                                    let ID = viewlist.target.split('outbox#')[1];

                                    listupadate(inputfield,textfield,viewlist,actionsbox,ID)

                                }
                                else
                                {

                                    let ID = `filelist-`+String( Math.floor(Math.random() * 999) );

                                    let fileviewer_empty_outbox =`
                                      <div class="outbox" id="`+ID+`">
                                        <div class="overlay">
                                          <div class="side-center">

                                              <div class="filelistbox">

                                                <div>
                                                  <a class="close">
                                                    <p>File selected</p>
                                                  </a>
                                                </div>

                                                <div>
                                                  <div class="hide-bar-y">
                                                    <div class="scroll-y">

                                                        <div class="filegroup grid-x">
                                                        </div>

                                                    </div>
                                                  </div>
                                                </div>

                                              </div>

                                          </div>
                                        </div>
                                      </div>`;

                                    //print empty output & get it
                                    document.getElementsByTagName('BODY')[0].insertAdjacentHTML('beforeEnd',fileviewer_empty_outbox);

                                    listupadate(inputfield,textfield,viewlist,actionsbox,ID)

                                }


                                function listupadate(inputfield,textfield,viewlist,actionsbox,target)
                                {

                                    let Filegroup = document.getElementById(target).querySelectorAll('.filegroup')[0];

                                    let filenames = [];
                                    for (let i=0; i<inputfield.files.length; i++)
                                    {

                                        let fdt = inputfield.files[i],
                                            FIN = String( fdt.name.split('.')[0] ),
                                            FXT = String( fdt.name.match(/\.([^\.]+)$/)[1]),
                                            FSZ = String( (~~((fdt.size/1000))/1024).toFixed(3) );

                                        if(FSZ=='0.000'){FSZ = '≅.001'}

                                        filenames.push('<div class="box-[50-50-50] align-left"><p class="ellipsis">'+FIN+'</p></div> <div class="box-[20-20-20] align-center"><p>'+FXT+'</p></div> <div class="box-[30-30-30] align-right"><p>'+FSZ+'mb</p></div>')

                                    }
                                    
                                    //from array list to list of strings
                                    let fileslist = String(filenames.join(' '));
                                    Filegroup.innerHTML = fileslist;

                                    //update input & p & put inside
                                    textfield.innerHTML = ('&#x2714 '+inputfield.files.length+' files selected');

                                    viewlist.setAttribute('target','outbox#'+target);
                                    viewlist.classList.remove('hide');
                                    actionsbox.classList.remove('hide');

                                    // inputfield.setAttribute('value', inputfield.value);
                                    textfield.classList.add('active');

                                }


                                // make fileloader
                                if(Btn.closest('.fileloader') && reset==true)
                                {
                                    setfileloader(Btn,fileloader)
                                }

                                // reset btn and fileloader
                                clearlist.addEventListener ('click',() =>
                                {

                                    inputfield.setAttribute('value','');
                                    textfield.innerText = startlabeltext;
                                    actionsbox.classList.add('hide');

                                },true);

                            }


                        })


                        function checkfilelimits (result)
                        {
                            
                            let status      = false,
                                message     = '',
                                checking    = [],
                                minqnt      = parseInt(inputfield.getAttribute("minlength")) || 0,
                                maxqnt      = parseInt(inputfield.getAttribute("maxlength")),
                                filelimit   = inputfield.getAttribute("size"),
                                totallimit  = inputfield.getAttribute("maxsize"),
                                accepted    = inputfield.getAttribute("accept"),
                                fileslength = inputfield.files.length;


                            if(minqnt)
                            {

                                if(fileslength < minqnt)
                                {
                                    textfield.closest("[class*='button-file']").classList.add('border-error');
                                    checking.push(false); message = ('quantity wrong: '+fileslength+' of min: '+minqnt+'');
                                }

                            }

                            if(maxqnt)
                            {

                                if(fileslength > maxqnt)
                                {
                                    textfield.closest("[class*='button-file']").classList.add('border-error');
                                    checking.push(false); message = ('quantity wrong: '+fileslength+' of max: '+maxqnt+'');
                                }

                            }


                            if(totallimit)
                            {

                                let total=0;
                                for (let i = 0; i < fileslength; i++)
                                {
                                    let filesize = parseFloat( (Math.floor((inputfield.files[i].size/1000))/1024).toFixed(2) );
                                    total += filesize;
                                }

                                if(total>totallimit)
                                {
                                    textfield.closest("[class*='button-file']").classList.add('border-error');
                                    checking.push(false); message = ('out of space: '+total+'mb - max: '+totallimit+'mb');
                                }

                            }

                            if(!Btn.closest('.fileloader'))
                            {

                                if(filelimit)
                                {

                                    for (let i = 0; i < fileslength; i++)
                                    {
                                        let megabyte = (Math.floor((inputfield.files[i].size/1000))/1024).toFixed(2);
                                        if(megabyte>filelimit)
                                        {
                                            textfield.closest("[class*='button-file']").classList.add('border-error');
                                            checking.push(false); message = ('file overload: '+megabyte+'mb - max: '+filelimit+'mb');
                                        }

                                    }

                                }

                                if(fileslength!=0 && accepted)
                                {
                                    for (let i = 0; i < fileslength; i++)
                                    {

                                        let file_extension = String( inputfield.files[i].name.match(/\.([^\.]+)$/)[1] ).toLowerCase();

                                        let arrayofkeys = [...accepted.split(", ")].join(' '),
                                            keys = arrayofkeys.split(' ');

                                        for (let i = 0; i < file_extension.length; i++)
                                        {

                                            let key = String(keys[i]);

                                            if(keys.indexOf(file_extension) === -1)
                                            {
                                                textfield.closest("[class*='button-file']").classList.add('border-error');
                                                checking.push(false); message = ('error: <i>'+file_extension+'</i> files is not supported');
                                            }

                                        }

                                    }
                                }
                            }

                            status = (checking.includes(false)) ? false : true;

                            result(status,message);

                        }


                    }


                    /* file loader: */

                    if( Btn.closest('.fileloader') )
                    {

                        // set basic fileloader params

                        fileloader.input              = inputfield;
                        fileloader.container          = Btn.closest('.fileloader');
                        fileloader.resetter           = fileloader.container.querySelectorAll('.clearlist')[0] || null;
                        fileloader.btnsend            = fileloader.container.querySelectorAll('.button-sendnow')[0] || null;
                        fileloader.display.element    = fileloader.container.querySelectorAll('[class*=display]')[0];


                        // is it supported?


                        let fileloadercompatibility = (window.File && window.FileReader && window.FileList && window.Blob)?true:readersnotsupported();
                        function readersnotsupported()
                        {
                            fileloader.classList.add('disabled');
                            fileloader.input.classList.add('disabled');
                            fileloader.btnsend.classList.add('disabled');
                            fileloader.display.element.innerHTML= '<div class="absolute-center"><p>YOUR SYSTEM NOT SUPPORTED FILE READERS</p></div>';
                            debug(`:: [⚠ ui alert]: fileloader error\n   ⮑ No modern file reader are supported.\n      reader message:`+loading.target.error)
                            fileloadercompatibility = false;
                        }

                        if(!fileloader.display.element || fileloader.display.element=='not defined')
                        {
                            debug(`:: [⚠ ui alert]: fileloader error\n   ⮑ display not found.`);
                            fileloadercompatibility = false;
                            fileloader.container.classList.add('disabled');
                        }


                        if(fileloadercompatibility===true)
                        {

                            // inner methods for reprint the list
                            // after drag or display actions

                            function FromArrayToInputFileList(...items)
                            {
                                items = [].concat(...items); 
                                let dataevent = new ClipboardEvent('').clipboardData || new DataTransfer();  
                                for (let data of items) { dataevent.items.add(data) }  return dataevent.files;
                            }

                            // set file drops actions

                            fileloader.container.addEventListener('dragover', (event_filedropover) => {

                                // event_filedropover.dataTransfer.effectAllowed = "move";
                                event_filedropover.preventDefault();
                                event_filedropover.stopPropagation();

                                let DT = event_filedropover.dataTransfer || event_filedropover.clipboardData;  
                                if (DT.items[0].kind.toLowerCase()=='file')
                                {
                                    fileloader.container.classList.add('draghere');

                                    fileloader.container.ondragleave = event_filedropover => {
                                        event_filedropover.preventDefault();
                                        event_filedropover.stopPropagation();
                                        fileloader.container.classList.remove('draghere');
                                    }

                                }

                            },true);


                            fileloader.container.addEventListener('drop', (event_filedropped) => {

                                event_filedropped.preventDefault();
                                event_filedropped.stopPropagation();

                                let DT = event_filedropped.dataTransfer || event_filedropped.clipboardData;
                                if (DT.items[0].kind.toLowerCase()=='file')
                                {
                                    let filelisted = [];
                                    for (let F=0; F < DT.files.length; F++)
                                    {
                                        let fileorigin  = DT.files[F];
                                        filelisted.push( new File( [fileorigin], fileorigin.name ) );
                                    }

                                    fileloader.container.classList.remove('draghere');

                                    inputfield.files = FromArrayToInputFileList(filelisted);

                                    inputfield       = [...Btn.querySelectorAll('input[type="file"]')][0];
                                    textfield        = [...Btn.getElementsByTagName('label')][0];


                                    setTimeout(()=>{
                                        updatebuttonfile(Btn,inputfield,textfield,startlabeltext,fileloader,true);
                                    },300)
                                }

                            },true);


                            // made the uploader mechs

                            function setfileloader(Btn,fileloader)
                            {
                                
                                
                                // get fileloader settings

                                let uploderSets = String(fileloader.container.dataset.settings).replace(/\s/g,'').replace(/\[/g,'').replace(/\]/g,'');


                                if(!uploderSets.includes('type')){ fileloader.settings.type = 'single'; }
                                else{ fileloader.settings.type = uploderSets.split('type:')[1].split(',')[0] };

                                if(!uploderSets.includes('chunksize')){ fileloader.settings.chunksize = parseInt( 64*1024 ) }
                                else{ fileloader.settings.chunksize = parseInt(uploderSets.split('chunksize:')[1].split(',')[0]) } 

                                if(!uploderSets.includes('converter')){ fileloader.settings.autoconversion = true ;}
                                else{ fileloader.settings.autoconversion = (uploderSets.split('converter:')[1].split(',')[0]=='false')?false:true; } 
                                
                                if(!uploderSets.includes('preview')){ fileloader.settings.preview = true ;}
                                else{ fileloader.settings.preview = (uploderSets.split('preview:')[1].split(',')[0]=='false')?false:true; } 

                                if(!uploderSets.includes('linked')){ fileloader.settings.linked = true; }
                                else{ fileloader.settings.linked = (uploderSets.split('linked:')[1].split(',')[0]=='false')?false:true; } 

                                if(!uploderSets.includes('icons')){ fileloader.settings.previewicons = true ;}
                                else{ fileloader.settings.previewicons = (uploderSets.split('icons:')[1].split(',')[0]=='false')?false:true; } 

                                if(!uploderSets.includes('deleter')){ fileloader.settings.deleter = true ;}
                                else{ fileloader.settings.deleter = (uploderSets.split('deleter:')[1].split(',')[0]=='false')?false:true; } 

                                if(!uploderSets.includes('sortable')){ fileloader.settings.sortable = false ;}
                                else{ fileloader.settings.sortable = (uploderSets.split('sortable:')[1].split(',')[0]=='false')?false:true; } 

                                if(!uploderSets.includes('grabber')){ fileloader.settings.grabber = true ;}
                                else{ fileloader.settings.grabber = (uploderSets.split('grabber:')[1].split(',')[0]=='false')?false:true; } 

                                if(!uploderSets.includes('filters')){ fileloader.settings.filters = false ;}
                                else{ fileloader.settings.filters = (uploderSets.split('filters:')[1].split(',')[0]=='false')?false:true; } 

                                if(!uploderSets.includes('metalabel')){ fileloader.settings.metalabel = true ;}
                                else{ fileloader.settings.metalabel = (uploderSets.split('metalabel:')[1].split(',')[0]=='false')?false:true; } 

                                if(!uploderSets.includes('titlelabel')){ fileloader.settings.filetitlelabel = true ;}
                                else{ fileloader.settings.filetitlelabel = (uploderSets.split('titlelabel:')[1].split(',')[0]=='false')?false:true; } 

                                if(!uploderSets.includes('customized')){ fileloader.settings.customized = false ;}
                                else{ fileloader.settings.customized = (uploderSets.split('customized:')[1].split(',')[0]=='false')?false:true; } 


                                iscustomdock= (fileloader.container.querySelectorAll('.customdock').length>0)?true:false;


                                let fileloaderid;
                                if(!fileloader.id) fileloaderid = ~~(Math.random()*100);
                                else fileloaderid = fileloader.id

                                let grablot       = (fileloader.settings.sortable==true) ? ' class="grabslot-['+fileloaderid+']"':'';
                                let grabboxstart  = (fileloader.settings.sortable==true) ? '<div class="grabbox">' : '';
                                let grabboxend    = (fileloader.settings.sortable==true) ? '</div>' : '';


                                // get compression settings

                                let compressorSets = String(fileloader.container.dataset.compressor);

                                if(fileloader.container.dataset.compressor)
                                {
                                    let resolution = (compressorSets.includes('resolution')) ? compressorSets.split('image-resolution:')[1].split(',')[0] : null;

                                    if(!compressorSets.includes('resize-type')){ fileloader.compressor.resizingtype = 'proportional' ;}
                                    else{ fileloader.compressor.resizingtype = (compressorSets.split('resize-type:')[1].split(',')[0]=='proportional')?'proportional':'linear'; } 


                                    fileloader.compressor.imageMaxWidth  = parseInt( resolution.split('x')[0] ) || 1920;
                                    fileloader.compressor.imageMaxHeight = parseInt( resolution.split('x')[1] ) || 1920;
                                    fileloader.compressor.imageQuality   = parseFloat( compressorSets.split('image-quality:')[1].split(',')[0]/100 ) || .75;
                                }
                                else
                                {
                                    fileloader.settings.preview = false;
                                    fileloader.settings.linked = false;
                                    fileloader.compressor=false;
                                }

                                if(fileloader.settings.autoconversion==false)
                                {
                                    fileloader.settings.preview = false;
                                    fileloader.settings.linked = false;
                                    fileloader.compressor=false;
                                }




                                // set display type

                                function makedisplay(fileloader)
                                {

                                   // let targetname = String(fileloader.container.classList.join('')).split('preview-[')[1].split(']')[0]; console.log('targetname:',targetname);
                                   // if(!targetname || targetname==null || targetname==undefined || targetname=='')
                                   // { debug(`:: [⚠ ui alert]: Error on fileloader\n   ⮑ settings work, preview target name not finded!\n      see more: shorturl.at/esSUY\n\n`); }
                                   // else
                                   // {
                                   //     fileloader.display.element = document.getElementById(targetname).parentNode;
                                   // }


                                    if(fileloader.settings.type == 'single')
                                    {

                                        if(fileloader.settings.sortable==true)
                                        {
                                            fileloader.settings.sortable = false;
                                            debug(':: [⚠ ui alert]: Info on fileloader\n   ⮑ settings work, displaytype single connot have a sortable!\n\n');
                                        }


                                        fileloader.input.setAttribute('maxlength','1');
                                        fileloader.display.element.classList.add('type-single');
                                        fileloader.display.container = fileloader.display.element;

                                    }
                                    else if(fileloader.settings.type == 'listed')
                                    {

                                        fileloader.display.element.classList.add('type-list');
                                        fileloader.display.element.innerHTML = (`<div class="hide-bar-y"><div class="scroll-y"><div></div></div></div>`);
                                        fileloader.display.container = fileloader.display.element.querySelectorAll('.scroll-y')[0].firstElementChild;

                                    }
                                    else if(fileloader.settings.type == 'grid')
                                    {

                                        let gridgap = (!uploderSets.includes('boxgap')) ? '' : 'gap-'+uploderSets.split('boxgap:')[1].split(',')[0];

                                        fileloader.display.element.classList.add('type-grid');
                                        fileloader.display.element.innerHTML = (`<div class="hide-bar-y"><div class="scroll-y"><div class="grid-x `+gridgap+`"></div></div></div>`);
                                        fileloader.display.container = fileloader.display.element.querySelectorAll('.scroll-y')[0].firstElementChild;

                                    }
                                    else if(fileloader.settings.type == 'wall')
                                    {


                                        let wallcols = (!uploderSets.includes('wallcols')) ? '04-03-01' : uploderSets.split('wallcols:')[1].split(',')[0];
                                        let boxgap = (!uploderSets.includes('boxgap')) ? '' : 'gap-'+uploderSets.split('boxgap:')[1].split(',')[0];

                                        fileloader.display.element.classList.add('type-wall');
                                        fileloader.display.element.innerHTML = (`<div class="hide-bar-y"><div class="scroll-y"><div class="grid-y col-[`+wallcols+`] `+boxgap+` autoset"></div></div></div>`);
                                        fileloader.display.container = fileloader.display.element.querySelectorAll('.scroll-y')[0].firstElementChild;

                                    }
                                    else
                                    {
                                        debug(`:: [⚠ ui alert]: Error on fileloader\n   ⮑ settings work, displaytype not finded!\n      see more: shorturl.at/esSUY\n\n`);
                                    }

                                }


                                // autostart or... on change restart...

                                loopfiles(fileloader);
                                fileloader.input.oninput = ()=>{ loopfiles(fileloader) }


                                // loop the files

                                function loopfiles(fileloader)
                                {

                                    // reset fileloader

                                    fileloader.display.container.innerHTML = '';
                                    fileloader.datalist = [];
                                    makedisplay(fileloader)


                                    // analize file and get all data from all boxes

                                    let step = 0; ( init_filesanalyzer = ( fileloader, step, () => {


                                        if( step >= fileloader.input.files.length )
                                        {

                                            // unlock input if end
                                            fileloader.input.style['pointer-events']=null;
                                            if(fileloader.btnsend){fileloader.btnsend.style['pointer-events']=null};

                                            // remove & recreate addone button
                                            if(fileloader.settings.type != 'single')
                                            {

                                                (fileloader.display.container.parentNode.querySelectorAll('.button-file-addone').length>0)?fileloader.display.element.querySelectorAll('.button-file-addone')[0].parentNode.remove():null;
                                                fileloader.display.container.parentNode.insertAdjacentHTML('beforeEnd',`<div class="addone"><div class="button-file-addone"><label>ADD ONE MORE</label><input type="file"/></div></div>`);

                                                //add a file via addone button
                                                let inputaddone = fileloader.display.container.parentNode.querySelectorAll('.button-file-addone>input')[0];
                                                inputaddone.oninput = () =>
                                                {

                                                    // lock main input if not end
                                                   
                                                    fileloader.input.style['pointer-events']='none';
                                                    if(fileloader.btnsend){fileloader.btnsend.style['pointer-events']='none'};
                                                   
                                                    // lock addone if not end
                                                   
                                                    inputaddone.parentNode.querySelectorAll('label')[0].innerHTML = 'wait a moment...';
                                                    inputaddone.parentNode.disabled=true;;
                                                    inputaddone.style.visibility='collapse';
                                                    inputaddone.disabled=true;

                                                    if(inputaddone.files.length==1)
                                                    {

                                                        let newfile = inputaddone.files[0],
                                                            newstep = fileloader.input.files.length;

                                                        madeNewData(fileloader,newstep);

                                                        analyzeStepData( fileloader, newstep, newfile, ()=>
                                                        {

                                                            // unlock inputs

                                                            fileloader.input.style['pointer-events'] = null;
                                                            if(fileloader.btnsend) fileloader.btnsend.style['pointer-events'] = null;

                                                            inputaddone.parentNode.querySelectorAll('label')[0].innerHTML = 'ADD ONE MORE';
                                                            inputaddone.parentNode.removeAttribute('disabled');
                                                            inputaddone.removeAttribute('style');
                                                            inputaddone.removeAttribute('disabled');

                                                            // update the real file list

                                                            updateButtonFileList(fileloader);

                                                        })

                                                        eventfilesAddOne=null;

                                                    }

                                                }

                                            }

                                            //update main input list
                                            // updateButtonFileList(fileloader);
                                            onclickresetter(fileloader);
                                            console.log(fileloader);

                                            grabs();

                                        }

                                        else
                                        {

                                            // lock input if not end
                                            fileloader.input.style['pointer-events']='none';
                                            if(fileloader.btnsend){fileloader.btnsend.style['pointer-events']='none'};
                                           
                                            // add new step on object
                                            madeNewData(fileloader,step);
                                           
                                            // analysys of object steps
                                            analyzeStepData(
                                            fileloader, step, fileloader.input.files[step],
                                            ()=>{
                                                init_filesanalyzer(fileloader,step++);
                                            });

                                        }


                                        function madeNewData (fileloader,steptarget)
                                        {

                                            // made new file data

                                            fileloader.datalist.push({

                                                    'filedata'
                                                    :{
                                                        'name'     : 'not-defined' ,
                                                        'blob'     : 'not-defined' ,
                                                        'size'     : 'not-defined' ,                            
                                                        'typed'    : 'not-defined' ,
                                                        'mime'     : 'not-defined' ,
                                                        'chunks'   : 'not-defined'
                                                    },

                                                    'container'    : 'not-defined' ,
                                                    'origins'      : 'not-defined' ,
                                                    'buttons'
                                                    :{
                                                        'title'     : 'not-defined' ,
                                                        'deleter'   : 'not-defined' ,
                                                        'grabber'   : 'not-defined' ,
                                                        'view'      : 'not-defined' ,
                                                        'filters'   : 'not-defined' 
                                                    }

                                            });


                                            // select a type for display the file 

                                            let btn_option_panel    = (!fileloader.settings.filters) ?'':(`<span class="action-filters" data-index="`+((steptarget>=0)?steptarget:fileloader.contents.length)+`" title="edit this file"></span>&nbsp;`);
                                            let btn_linked_icon     = (!fileloader.settings.linked)  ?'':(`<span class="action-view" title="view this file"></span>&nbsp;`);
                                            let btn_delete_icon     = (!fileloader.settings.deleter) ?'':(`<span class="action-delete" title="remove this file"></span>&nbsp;`);
                                            let btn_grab_icon       = (!fileloader.settings.grabber) ?'':(`<span class="action-grab" title="move on other place"></span>`);


                                            if(fileloader.settings.type == 'listed')
                                            {

                                                let print_previewbox  = (!fileloader.settings.preview && !fileloader.settings.linked) ? (`<div class="box-[00-00-00]"></div>`) : (`<div class="box-[15-15-15]"><div class="autocrop ratio-square preview"><img alt="" src=""></div></div>`);
                                                let print_optionsbox='';  if(fileloader.settings.filters || fileloader.settings.linked || fileloader.settings.deleter || fileloader.settings.grabber) { print_optionsbox=`<div class="box-[auto-auto-auto]"><div>`+btn_option_panel+``+btn_linked_icon+``+btn_delete_icon+``+btn_grab_icon+`</div></div>`}
                                                let print_minilabels = ''; if(fileloader.settings.metalabel){  print_minilabels = `<div class="box-[10-10-00]"><div><p class="filetype"></p></div></div><div class="box-[15-15-25]"><div><p class="filesize"></p></div></div>` }
                                                let print_nameinput = ''; if(fileloader.settings.filetitlelabel){  print_nameinput = `<div class="box-[auto-auto-35]"><div><div class="button-text action-rename clearized"><input type="text" class="ellipsis" value="" /></div></div></div>` }
                                                let html_output =
                                                `
                                                    <div class="databox">

                                                        <div `+grablot+`>

                                                           `+grabboxstart+`

                                                              <div id="" class="contents">

                                                                 <div class="grid-x">

                                                                     `+print_previewbox+`
                                                                     `+print_nameinput+`
                                                                     `+print_minilabels+`
                                                                     `+print_optionsbox+`

                                                                 </div>

                                                                 <div class="status-[on]"></div>
                                                                 <div class="progress-[00]"></div>

                                                              </div>

                                                           `+grabboxend+`

                                                        </div>

                                                  </div>
                                                `;

                                                fileloader.display.container.insertAdjacentHTML('beforeEnd',html_output);

                                            }

                                            else if(fileloader.settings.type == 'grid')
                                            {

                                                let gridcut             =  (!uploderSets.includes('boxcut')) ? '25-25-100' : uploderSets.split('boxcut:')[1].split(',')[0];

                                                let optionsbox          =''; if(fileloader.settings.filters || fileloader.settings.linked || fileloader.settings.deleter || fileloader.settings.grabber)
                                                                            {
                                                                                if(!fileloader.settings.previewicons)
                                                                                {
                                                                                    optionsbox=
                                                                                        `<div>
                                                                                            <span class="actions">
                                                                                                `+btn_option_panel+`
                                                                                                `+btn_linked_icon+`
                                                                                                `+btn_delete_icon+`
                                                                                                `+btn_grab_icon+`
                                                                                            </span>
                                                                                        </div>`
                                                                                }
                                                                            }

                                                let previewbox          = (!fileloader.settings.preview && !fileloader.settings.linked) ? (`<div class="box-[100-100-100]">`+optionsbox+`</div>`) : (`<div class="box-[100-100-100] autocrop ratio-square preview"><img alt="" src="">`+optionsbox+`</div>`);

                                                let html_output =
                                                `
                                                  <div class="databox box-[`+gridcut+`]">
                                                     <div>
                                                        <div `+grablot+`>

                                                           `+grabboxstart+`

                                                              <div id="" class="contents">

                                                                 <div class="grid-x">

                                                                    <div class="box-[100-100-100]">
                                                                       <div>
                                                                          <div class="button-text action-rename clearized align-center">
                                                                             <input type="text" class="ellipsis" value="" />
                                                                          </div>
                                                                       </div>
                                                                    </div>

                                                                    `+previewbox+`

                                                                    <div class="box-[50-50-50]">
                                                                       <div>
                                                                          <p class="filetype"></p>
                                                                       </div>
                                                                    </div>

                                                                    <div class="box-[50-50-50]">
                                                                       <div>
                                                                          <p class="filesize"></p>
                                                                       </div>
                                                                    </div>

                                                                 </div>

                                                                 <div class="status-[on]"></div>
                                                                 <div class="progress-[00]"></div>

                                                              </div>

                                                           `+grabboxend+`

                                                        </div>
                                                     </div>
                                                  </div>
                                                `;

                                                fileloader.display.container.insertAdjacentHTML('beforeEnd',html_output);

                                            }

                                            else if(fileloader.settings.type == 'wall')
                                            {


                                                let optionsbox  ='';   if(fileloader.settings.filters || fileloader.settings.linked || fileloader.settings.deleter || fileloader.settings.grabber)
                                                                       {
                                                                          if(!fileloader.settings.previewicons)
                                                                          {
                                                                              optionsbox=
                                                                                  `<div class="absolute-center">
                                                                                      <span class="actions">
                                                                                          `+btn_option_panel+`
                                                                                          `+btn_linked_icon+`
                                                                                          `+btn_delete_icon+`
                                                                                          `+btn_grab_icon+`
                                                                                      </span>
                                                                                  </div>`
                                                                          }
                                                                       }

                                                let previewbox = (!fileloader.settings.preview && !fileloader.settings.linked) ? (`<div class="box-[100-100-100]">`+optionsbox+`</div>`) : (`<div class="box-[100-100-100]"><div class="preview"><img alt="" src="">`+optionsbox+`</div></div>`);

                                                let html_output =
                                                `
                                                  <div class="box databox">

                                                     <div>

                                                        <div `+grablot+`>

                                                           `+grabboxstart+`

                                                              <div id="" class="contents">

                                                                 <div class="grid-x">

                                                                    <div class="box-[100-100-100]">

                                                                       <div>
                                                                          <div class="button-text action-rename clearized align-center">
                                                                             <input type="text" class="ellipsis" value="" />
                                                                          </div>
                                                                       </div>

                                                                    </div>

                                                                    `+previewbox+`

                                                                    <div class="box-[50-50-50]">
                                                                       <div>
                                                                          <p class="filetype"></p>
                                                                       </div>
                                                                    </div>

                                                                    <div class="box-[50-50-50]">
                                                                       <div>
                                                                          <p class="filesize"></p>
                                                                       </div>
                                                                    </div>

                                                                 </div>

                                                                 <div class="status-[on]"></div>
                                                                 <div class="progress-[00]"></div>

                                                              </div>

                                                           </div>

                                                        `+grabboxend+`

                                                     </div>

                                                  </div>
                                                `;

                                                fileloader.display.container.insertAdjacentHTML('beforeEnd',html_output);

                                                grid_y();

                                            }

                                            else if(fileloader.settings.type == 'single')
                                            {

                                                let print_optionsbox =''; if( !iscustomdock && (fileloader.settings.filters || fileloader.settings.linked || fileloader.settings.deleter || fileloader.settings.grabber)) { if(!fileloader.settings.previewicons) { print_optionsbox= `<div><span class="actions"> `+btn_option_panel+` `+btn_linked_icon+` `+btn_delete_icon+` `+btn_grab_icon+`</span></div>`}}
                                                let print_previewbox = (!fileloader.settings.preview && !fileloader.settings.linked) ? (`<div class="box-[100-100-100]">`+print_optionsbox+`</div>`) : (`<div class="box-[100-100-100] autocrop ratio-square preview"><img alt="" src="">`+print_optionsbox+`</div>`);
                                                let print_minilabels = ''; if(fileloader.settings.metalabel){  print_minilabels = `<div class="box-[50-50-50]"><div><p class="filetype"></p></div></div><div class="box-[50-50-50]"><div><p class="filesize"></p></div></div>` }
                                                let print_nameinput  = ''; if(fileloader.settings.filetitlelabel){  print_nameinput = `<div class="box-[100-100-100]"><div><div class="button-text action-rename clearized align-center"><input type="text" class="ellipsis" value="" /></div></div></div>` }

                                                let html_output =
                                                `
                                                    <div class="databox">

                                                        <div>

                                                            <div class="grid-x">
                                                            
                                                                `+print_nameinput+`
                                                                `+print_previewbox+`
                                                                `+print_minilabels+`

                                                            </div>

                                                            <div class="status-[on]"></div>
                                                            <div class="progress-[00]"></div>

                                                        </div>

                                                    </div>
                                                `;

                                                fileloader.display.container.insertAdjacentHTML('beforeEnd',html_output);
                                            }


                                            //select and set a specific stepped data in the data list object

                                            let dataStepSelected = fileloader.datalist[steptarget];

                                            dataStepSelected.container = fileloader.display.container.querySelectorAll('.databox')[steptarget];

                                            //is custom dock?
                                            if(iscustomdock)
                                            {
                                                dataStepSelected.buttons.deleter = fileloader.container.querySelectorAll('.action-delete')[0];
                                                dataStepSelected.buttons.grabber = fileloader.container.querySelectorAll('.action-grab')[0];
                                                dataStepSelected.buttons.title   = fileloader.container.querySelectorAll('.action-rename')[0];
                                                dataStepSelected.buttons.view    = fileloader.container.querySelectorAll('.action-view')[0];
                                                if(fileloader.settings.filters == true)
                                                { dataStepSelected.buttons.filters = fileloader.container.querySelectorAll('.action-filters')[0]; }
                                            }

                                            else
                                            {
                                                dataStepSelected.buttons.deleter = dataStepSelected.container.querySelectorAll('.action-delete')[0];
                                                dataStepSelected.buttons.grabber = dataStepSelected.container.querySelectorAll('.action-grab')[0];
                                                dataStepSelected.buttons.title   = dataStepSelected.container.querySelectorAll('.action-rename')[0];
                                                dataStepSelected.buttons.view    = dataStepSelected.container.querySelectorAll('.action-view')[0];

                                                if(fileloader.settings.filters == true)
                                                { dataStepSelected.buttons.filters = dataStepSelected.container.querySelectorAll('.action-filters')[0]; }

                                            }

                                        }


                                        function analyzeStepData(fileloader,steptarget,steppedfile,nextstep)
                                        {

                                            // active data deleter
                                            if(steptarget>=fileloader.datalist.length-1)
                                            {
                                                if(iscustomdock)
                                                {
                                                    if(fileloader.settings.deleter && fileloader.datalist[steptarget].buttons.deleter!='not-defined') { deleteAData(fileloader); }
                                                }
                                                else
                                                {
                                                    if(fileloader.settings.deleter) { deleteAData(fileloader); }
                                                }
                                            }


                                            let stepdata       = fileloader.datalist[steptarget];

                                            let lazy           = stepdata.container.querySelectorAll('[class*=lazy-]')[0],
                                                bar            = stepdata.container.querySelectorAll('[class*=progress-]')[0];

                                            let browserurl     = window.URL || window.webkitURL;

                                            let readFiles      = new FileReader(),
                                                chunksize      = parseInt(fileloader.settings.chunksize),
                                                filechunks     = [],
                                                chunkstep      = 0;


                                            // save for update orginal file list
                                            stepdata.origins = steppedfile;


                                            // loop binary in chunks
                                            ( loadchunks = () => {


                                                // set a binary chunks readeder
                                                let nextcut    = chunksize+chunkstep,
                                                    filecut    = steppedfile.slice(chunkstep, nextcut);

                                                readFiles.readAsBinaryString(filecut);

                                                // now read
                                                readFiles.onload = fileloading =>
                                                {


                                                    // get/write percent of readed
                                                    let percentLoaded = parseInt( ((chunkstep / steppedfile.size) * 100), 10 ),
                                                        percentString = String( (parseInt(percentLoaded)<10)? ('0'+percentLoaded) : percentLoaded );

                                                        bar.className = 'progress-['+percentString+']';


                                                    // if bit remained is 0
                                                    if (fileloading.target.result.length==0)
                                                    {

                                                        bar.className = 'progress-[100]';

                                                        // lounch final analysys 
                                                        setReadedDatas();

                                                    }

                                                    else
                                                    {

                                                        if (fileloading.target.error == null)
                                                        {

                                                            // relounch loadchunks with new chunks 
                                                            filechunks.push(fileloading.target.result)
                                                            chunkstep += fileloading.target.result.length;
                                                            loadchunks(chunkstep,chunksize,steppedfile);

                                                        }
                                                        else
                                                        {
                                                            // wtf is going wrong? 
                                                            readFiles.oncrash(fileloading.target.error);

                                                        }

                                                    }


                                                    function setReadedDatas()
                                                    {

                                                        
                                                        let maxw                = fileloader.compressor.imageMaxWidth,
                                                            maxh                = fileloader.compressor.imageMaxHeight;

                                                        let fileweightlimit     = inputfield.getAttribute("size");  // let substringlength = words.map(function(word) { return word + ' = ' + word.length; });

                                                        let typed               = 'not-defined',
                                                            fileextension       = (steppedfile.name.slice(steppedfile.name.lastIndexOf('.') + 1)).toLowerCase();

                                                        let issvg               = ['svg'].includes(fileextension),
                                                            isgif               = ['gif'].includes(fileextension),
                                                            isimage             = ['mjpeg','bmp','jpg','jpeg','png','ico','webp','cur','jpe','jps','jfif'].includes(fileextension),
                                                            issound             = ['amb','aac','flac','m4a','m4r','mp3','oga','ogg','opus','wav'].includes(fileextension),
                                                            isvideo             = ['mp4','f4v','mpeg','m4v','mov','webm','ogv'].includes(fileextension),
                                                            isunsound           = ['8svx','ac3','aiff','au','avr','caf','cdda','cvs','cvsd','cvu','dts','dvms','fap','fssd','gsrt','hcom','htk','ima','ircam','maud','mp2','nist','paf','prc','pvf','ra','sd2','sln','smp','snd','sndr','sndt','sou','sph','spx','tta','txw','vms','voc','vox','w64','wma','wv','wve'].includes(fileextension),
                                                            isunimage           = ['ai','dds','eps','exr','fts','hdr','mng','pam','pbm','pcd','pcx','pfm','pgm','picon','pict','pnm','ppm','psd','ras','sfw','sgi','tga','tiff','tif','wbmp','wpg','x3f','xbm','xdf','xwd','xcf','xpm','cr2','dng','erf','heic','heif','jp2','nef','nrw','orf','pef','pes','raf','rw2'].includes(fileextension),
                                                            isunvideo           = ['3gp','asf','avi','flv','hevc','m2ts','m2v','mkv','mpg','mts','mxf','swf','ts','vob','wmv','wtv'].includes(fileextension);

                                                        if (issvg)              { typed = 'web-xmlsvg';    mime = 'image/svg+xml'; }
                                                        else if (isgif)         { typed = 'web-gif';       mime = 'image/gif'; }
                                                        else if (isimage)       { typed = 'web-image';     mime = (fileextension=='image/ico') ? 'x-icon' : 'image/png'; }
                                                        else if (issound)       { typed = 'web-audio';     mime = 'audio/mpeg'; }
                                                        else if (isvideo)       { typed = 'web-video';     mime = 'video/mp4'; }
                                                        else if (isunimage)     { typed = 'not-web-image'; mime = 'not-web-compatible'; } 
                                                        else if (isunsound)     { typed = 'not-web-audio'; mime = 'not-web-compatible'; }
                                                        else if (isunvideo)     { typed = 'not-web-video'; mime = 'not-web-compatible'; }
                                                        else  /*(isfiles)*/     { typed = 'binary-file';   mime = 'not-web-compatible'; }


                                                        // save all basic data...

                                                        stepdata.filedata.name   = steppedfile.name.split('.'+fileextension)[0];
                                                        stepdata.filedata.blob   = browserurl.createObjectURL(steppedfile);
                                                        stepdata.filedata.size   = parseFloat( (Math.floor((steppedfile.size/1000))/1024).toFixed(2) );
                                                        stepdata.filedata.chunks = filechunks;
                                                        stepdata.filedata.mime   = mime;
                                                        stepdata.filedata.typed  = typed;

                                                        let idstring = String(stepdata.filedata.blob), idcontent = String(idstring.substr(idstring.length - 5));
                                                        stepdata.container.querySelectorAll('.contents')[0].setAttribute('id', idcontent );
                                                        stepdata.id = idcontent;


                                                        // types: binary big data / base64 optimized;
                                                        (!fileloader.settings.autoconversion) ? unmime() : convertion();

                                                        function convertion()
                                                        {

                                                            // make a data previews

                                                            if(isimage)
                                                            {

                                                                let previewbox = stepdata.container.querySelectorAll('.preview')[0];
                                                                previewbox.classList.add( 'bkg-'+stepdata.filedata.typed, 'bkg-'+fileextension );

                                                                imagecompressor(
                                                                filechunks,mime,maxw,maxh,
                                                                optimized => {

                                                                    if(!optimized)                      { printerror('ERROR ON IMAGE COMPRESSION. THIS FILE CANNOT BE SENT.'); }
                                                                    else if(optimized=='unprintable')   { printerror('ERROR ON IMAGE PREVIEW CREATION. THIS FILE CANNOT BE SENT.'); }
                                                                    else if(optimized=='toosmall')      { printerror('THIS IMAGE IS TOO SMALL!! MIN PX IS '+maxw+' x '+maxh); }

                                                                    else
                                                                    {

                                                                        let newdata = optimized.replace(/=/g,"").replace('data:'+mime+';base64,',"");
                                                                        let newsize = ( ~~(newdata.length * 0.75/1000)/1024 ).toFixed(3);

                                                                        if(newsize>fileweightlimit)
                                                                        {
                                                                            printerror('FILE IS TOO BIG!! USED '+newsize+' OF '+inputfield+' Mb');
                                                                        }

                                                                        else
                                                                        {

                                                                            if(fileextension!='image/ico')
                                                                            {

                                                                                stepdata.filedata.size   = newsize;
                                                                                stepdata.filedata.chunks = [ newdata ];

                                                                                if(fileloader.settings.metalabel)
                                                                                {
                                                                                    stepdata.container.querySelectorAll('.filesize')[0].innerText = (newsize=='0.000')? '≅ 001 Mb' : newsize +' Mb';
                                                                                    stepdata.container.querySelectorAll('.filetype')[0].innerText = fileextension;
                                                                                }

                                                                            }

                                                                            if(fileloader.settings.filetitlelabel)
                                                                            {
                                                                                let startitle = stepdata.filedata.name;
                                                                                stepdata.buttons.title.firstElementChild.setAttribute('value',startitle);
                                                                                updatefiledataname(stepdata,startitle)
                                                                            }


                                                                            if(fileloader.settings.preview)
                                                                            {

                                                                                let previewbox = stepdata.container.querySelectorAll('.preview')[0];
                                                                                previewbox.classList.add( 'bkg-'+stepdata.filedata.typed, 'bkg-'+fileextension );

                                                                                previewbox.firstElementChild.src = optimized;

                                                                                if(!optimized || previewbox.firstElementChild.src == undefined)
                                                                                {
                                                                                    previewbox.firstElementChild.classList.add('hide');
                                                                                }

                                                                                if(fileloader.settings.previewicons==true)
                                                                                {
                                                                                    previewbox.insertAdjacentHTML('beforeEnd',`<span class="ico-`+stepdata.filedata.typed+` ico-`+fileextension+`"></span>`);
                                                                                }

                                                                            }


                                                                            if(fileloader.settings.linked)
                                                                            {

                                                                                fileloader.datalist[steptarget].buttons.view.onclick = () =>
                                                                                {

                                                                                    if(fileextension=='image/ico')
                                                                                    {
                                                                                        let blobber = new Blob(
                                                                                        [`
                                                                                            <head>
                                                                                              <title>FILE PREVIEWS</title><meta http-equiv="Content-type" content="text/html; charset=UTF-8">
                                                                                            </head>
                                                                                            <body>
                                                                                                <main>
                                                                                                    <div>
                                                                                                        <small>
                                                                                                            WHAT YOU ARE SEEING IS THE REPRESENTATION OF ICON DATA (from .ico to web/png).<br>
                                                                                                            THE DATA THAT WILL BE SENT WILL RELATE TO THE REAL ICON.
                                                                                                        </small>
                                                                                                    </div>
                                                                                                    <image src="`+optimized+`"/>
                                                                                                </main>
                                                                                            </body>
                                                                                            <style>
                                                                                                html,body{background:#131313;display:flex;height:100%;width:100%;align-self:center;margin:0;padding:0;align-items:center;}
                                                                                                main{max-width:50%;margin: 0 auto;display:flex;flex-direction:column;align-items:center;}
                                                                                                main>div{display: flex;flex-direction: column;align-items:center;}
                                                                                                main>div>small{text-align:center;color:white;font-style;font-family:verdana,helvetica;margin-bottom: 20px;font-size: 9px;padding:15px;max-width:100%;}
                                                                                                image{position:relative;display:block;}
                                                                                            </style>

                                                                                        `], {type: "text/html"});

                                                                                        window.open( browserurl.createObjectURL(blobber) , '_blank');
                                                                                    }
                                                                                    else
                                                                                    {

                                                                                        let mex = (!fileloader.compressor) ? `THIS IS THE IMAGE ROW DATA THAT WILL BE SENT` : `THIS IS THE OPTIMIZED IMAGE DATA THAT WILL BE SENT`;

                                                                                        let blobber = new Blob(
                                                                                        [`
                                                                                            <head>
                                                                                              <title>FILE PREVIEWS</title><meta http-equiv="Content-type" content="text/html; charset=UTF-8">
                                                                                            </head>
                                                                                            <body>
                                                                                                <main>
                                                                                                    <div>
                                                                                                        <small>
                                                                                                            `+mex+`
                                                                                                        </small>
                                                                                                    </div>
                                                                                                    <image src="`+optimized+`"/>
                                                                                                </main>
                                                                                            </body>
                                                                                            <style>
                                                                                                html,body{background:#131313;display:flex;height:100%;width:100%;align-self:center;margin:0;padding:0;align-items:center;}
                                                                                                main{max-width:50%;margin: 0 auto;display:flex;flex-direction:column;align-items:center;}
                                                                                                main>div{display: flex;flex-direction: column;align-items:center;}
                                                                                                main>div>small{text-align:center;color:white;font-style;font-family:verdana,helvetica;margin-bottom: 20px;font-size: 9px;padding:15px;max-width:100%;}
                                                                                                image{position:relative;display:block;}
                                                                                            </style>

                                                                                        `], {type: "text/html"});

                                                                                        window.open( browserurl.createObjectURL(blobber) , '_blank');

                                                                                    }


                                                                                }
                                                                            }

                                                                        }

                                                                        clearmemory();
                                                                        removelazy(bar,lazy);

                                                                    }

                                                                });

                                                            }

                                                            else if(issvg || isgif)
                                                            {

                                                                if(stepdata.filedata.size>fileweightlimit)
                                                                {
                                                                    printerror('FILE IS TOO BIG!! USED '+stepdata.filedata.size+' OF '+fileweightlimit+' Mb');
                                                                }
                                                                else
                                                                {

                                                                    if(fileloader.settings.filetitlelabel)
                                                                    {
                                                                        let startitle = stepdata.filedata.name;
                                                                        stepdata.buttons.title.firstElementChild.setAttribute('value',startitle);
                                                                        updatefiledataname(stepdata,startitle)
                                                                    }

                                                                    if(fileloader.settings.metalabel)
                                                                    {
                                                                        stepdata.container.querySelectorAll('.filetype')[0].innerText = fileextension;
                                                                        stepdata.container.querySelectorAll('.filesize')[0].innerText = (stepdata.filedata.size=='0.000')? '≅.001 mB' : stepdata.filedata.size +' Mb';
                                                                    }

                                                                    imagecompressor(
                                                                    filechunks,mime,maxw,maxh,
                                                                    optimized => {


                                                                        if(!optimized)                      { printerror('ERROR ON VECTOR READING. THIS FILE CANNOT BE SENT.'); }
                                                                        else if(optimized=='unprintable')   { printerror('ERROR ON VECTOR PREVIEW CREATION. THIS FILE CANNOT BE SENT.'); }
                                                                        else if(optimized=='toosmall')      { printerror('THIS IMAGE IS TOO SMALL!! MIN PX IS '+maxw+' x '+maxh); }
                                                                        else
                                                                        {


                                                                            if(fileloader.settings.preview)
                                                                            {

                                                                                let previewbox = stepdata.container.querySelectorAll('.preview')[0];
                                                                                previewbox.classList.add( 'bkg-'+stepdata.filedata.typed, 'bkg-'+fileextension );

                                                                                previewbox.firstElementChild.src = optimized;

                                                                                if(!optimized || previewbox.firstElementChild.src == undefined)
                                                                                {
                                                                                    previewbox.firstElementChild.classList.add('hide');
                                                                                }

                                                                                if(fileloader.settings.previewicons==true)
                                                                                {
                                                                                    previewbox.insertAdjacentHTML('beforeEnd',`<span class="ico-`+stepdata.filedata.typed+` ico-`+fileextension+`"></span>`);
                                                                                }

                                                                            }

                                                                            if(fileloader.settings.linked)
                                                                            {

                                                                                fileloader.datalist[steptarget].buttons.view.onclick = () =>
                                                                                {

                                                                                    let blobber;
                                                                                    if(issvg)
                                                                                    {

                                                                                        blobber = new Blob(
                                                                                        [`
                                                                                            <head>
                                                                                              <title>FILE PREVIEWS</title><meta http-equiv="Content-type" content="text/html; charset=UTF-8">
                                                                                            </head>
                                                                                            <body>
                                                                                                <main>
                                                                                                    <div>
                                                                                                        <small>
                                                                                                            WHAT YOU ARE SEEING IS THE IMAGE REPRESENTATION OF THE VECTOR SVG DATA.<br>ORIGINAL DATA ARE SAVED IN BINARY.
                                                                                                        </small>
                                                                                                    </div>
                                                                                                    <image src="`+optimized+`"/>
                                                                                                </main>
                                                                                            </body>
                                                                                            <style>
                                                                                                html,body{background:#131313;display:flex;height:100%;width:100%;align-self:center;margin:0;padding:0;align-items:center;}
                                                                                                main{max-width:50%;margin: 0 auto;display:flex;flex-direction:column;align-items:center;}
                                                                                                main>div{display: flex;flex-direction: column;align-items:center;}
                                                                                                main>div>small{text-align:center;color:white;font-style;font-family:verdana,helvetica;margin-bottom: 20px;font-size: 9px;padding:15px;max-width:100%;}
                                                                                                image{position:relative;display:block;}
                                                                                            </style>

                                                                                        `], {type: "text/html"});

                                                                                        window.open( browserurl.createObjectURL(blobber) , '_blank');

                                                                                    }
                                                                                    else if(isgif)
                                                                                    {

                                                                                        let margegifchunks; 
                                                                                        try{ margegifchunks = 'data:'+mime+';base64,'+btoa(stepdata.filedata.chunks.join('')) }
                                                                                        catch
                                                                                        {
                                                                                            blobber = new Blob(
                                                                                            [`
                                                                                                <head>
                                                                                                  <title>FILE PREVIEWS</title><meta http-equiv="Content-type" content="text/html; charset=UTF-8">
                                                                                                </head>
                                                                                                <body>
                                                                                                    <main>
                                                                                                        <div>
                                                                                                            <small>GIFs ARE NOT OPTIMIZABLE, WHAT YOU ARE SEEING IS THE DATA REPRESENTATION.<br>ORIGINAL DATA ARE SAVED IN BINARY OR B64.</small>
                                                                                                        </div>
                                                                                                        <image src="`+optimized+`"/>
                                                                                                    </main>
                                                                                                </body>
                                                                                                <style>
                                                                                                    html,body{background:#131313;display:flex;height:100%;width:100%;align-self:center;margin:0;padding:0;align-items:center;}
                                                                                                    main{max-width:50%;margin: 0 auto;display:flex;flex-direction:column;align-items:center;}
                                                                                                    main>div{display: flex;flex-direction: column;align-items:center;}
                                                                                                </style>

                                                                                            `], {type: "text/html"});

                                                                                            window.open( browserurl.createObjectURL(blobber) , '_blank');

                                                                                        }
                                                                                        finally
                                                                                        {
                                                                                            blobber = new Blob(
                                                                                            [`
                                                                                                <head>
                                                                                                  <title>FILE PREVIEWS</title><meta http-equiv="Content-type" content="text/html; charset=UTF-8">
                                                                                                </head>
                                                                                                <body>
                                                                                                    <main>
                                                                                                        <div>
                                                                                                            <small>GIFs ARE NOT OPTIMIZABLE, WHAT YOU ARE SEEING IS THE DATA REPRESENTATION.<br>ORIGINAL DATA ARE SAVED IN BINARY OR B64.</small>
                                                                                                            <image src="`+margegifchunks+`"/>
                                                                                                        </div>
                                                                                                    </main>
                                                                                                </body>
                                                                                                <style>
                                                                                                    html,body{background:#131313;display:flex;height:100%;width:100%;align-self:center;margin:0;padding:0;align-items:center;}
                                                                                                    main{max-width:50%;margin: 0 auto;display:flex;flex-direction:column;align-items:center;}
                                                                                                    main>div>small{text-align:center;color:white;font-style;font-family:verdana,helvetica;margin-bottom: 20px;font-size: 9px;padding:15px;max-width:100%;}
                                                                                                    main>div{display: flex;flex-direction: column;align-items:center;}
                                                                                                    image{position:relative;display:block;}
                                                                                                </style>

                                                                                            `], {type: "text/html"});

                                                                                            window.open( browserurl.createObjectURL(blobber) , '_blank');

                                                                                        }

                                                                                    }

                                                                                }

                                                                            }

                                                                            clearmemory();
                                                                            removelazy(bar,lazy);
                                                                        }


                                                                    });

                                                                }


                                                            }

                                                            else if(isvideo)
                                                            {

                                                                if(fileloader.settings.filetitlelabel)
                                                                {
                                                                    let startitle = stepdata.filedata.name;
                                                                    stepdata.buttons.title.firstElementChild.setAttribute('value',startitle);
                                                                    updatefiledataname(stepdata,startitle)
                                                                }

                                                                if(fileloader.settings.metalabel)
                                                                {                                                
                                                                    stepdata.container.querySelectorAll('.filetype')[0].innerText = fileextension;
                                                                    stepdata.container.querySelectorAll('.filesize')[0].innerText = (stepdata.filedata.size=='0.000')? '≅.001 mB' : stepdata.filedata.size +' Mb';
                                                                }

                                                                let projector = document.createElement("VIDEO");
                                                                projector.src = stepdata.filedata.blob;
                                                                projector.load();
                                                                projector.onloadeddata = event_encodedloaded =>
                                                                {

                                                                    projector.currentTime = parseInt(projector.duration/2);

                                                                    if(projector.videoWidth<maxw || projector.videoHeight<maxh) { printerror('THIS VIDEO IS TOO SMALL!! MIN PX IS '+maxw+' x '+maxh); }
                                                                    else
                                                                    {

                                                                        if(fileloader.settings.preview)
                                                                        {

                                                                            let canvas = document.createElement('canvas'),
                                                                                cw = projector.videoWidth,
                                                                                ch = projector.videoHeight;

                                                                            if(fileloader.compressor.resizingtype=='proportional')
                                                                            {
                                                                                if (cw >= ch) { cw = ~~(cw *= maxh / ch); ch = maxh;  }
                                                                                if (cw < ch) { ch = ~~(ch *= maxw / cw); cw = maxw;   }
                                                                            }
                                                                            else
                                                                            {
                                                                                if (cw >= ch) { ch = ~~(ch *= maxw / cw); cw = maxw; }
                                                                                if (cw < ch) { cw = ~~(cw *= maxh / ch); ch = maxh; }
                                                                            }

                                                                            canvas.width = cw; canvas.height = ch;

                                                                            canvas.getContext("2d").drawImage(projector, 0, 0, cw, ch);

                                                                            let videobanner = canvas.toDataURL( mime, fileloader.compressor.imageQuality );


                                                                            let previewbox = stepdata.container.querySelectorAll('.preview')[0];
                                                                            previewbox.classList.add( 'bkg-'+stepdata.filedata.typed, 'bkg-'+fileextension );

                                                                            previewbox.firstElementChild.src = videobanner;

                                                                            if(!videobanner || previewbox.firstElementChild.src == undefined)
                                                                            {
                                                                                previewbox.firstElementChild.classList.add('hide');
                                                                            }

                                                                            if(fileloader.settings.previewicons==true)
                                                                            {
                                                                                previewbox.insertAdjacentHTML('beforeEnd',`<span class="ico-`+stepdata.filedata.typed+` ico-`+fileextension+`"></span>`);
                                                                            }

                                                                        }

                                                                        if(fileloader.settings.linked)
                                                                        {
                                                                            fileloader.datalist[steptarget].buttons.view.onclick = () =>
                                                                            {
                                                                                let blobber = new Blob(
                                                                                [`
                                                                                    <head>
                                                                                      <title>FILE PREVIEWS</title><meta http-equiv="Content-type" content="text/html; charset=UTF-8">
                                                                                    </head>
                                                                                    <body>
                                                                                        <main>
                                                                                            <div>
                                                                                                <small>
                                                                                                    WHAT YOU ARE SEEING IS THE STREAMING REPRESENTATION OF THE VIDEO DATA.<br>ORIGINAL DATA ARE SAVED IN BINARY OR B64.
                                                                                                </small>
                                                                                            </div>
                                                                                            <video controls src="`+stepdata.filedata.blob+`"></video>
                                                                                        </main>
                                                                                    </body>
                                                                                    <style>
                                                                                        html,body{background:#131313;display:flex;height:100%;width:100%;align-self:center;margin:0;padding:0;align-items:center;}
                                                                                        main{max-width:50%;margin: 0 auto;display:flex;flex-direction:column;align-items:center;}
                                                                                        main>div{display: flex;flex-direction: column;align-items:center;}
                                                                                        main>div>small{text-align:center;color:white;font-style;font-family:verdana,helvetica;margin-bottom: 20px;font-size: 9px;padding:15px;max-width:100%;}
                                                                                        image{position:relative;display:block;}
                                                                                    </style>
                                                                                
                                                                                `], {type: "text/html"});
                                                                                
                                                                                window.open( browserurl.createObjectURL(blobber) , '_blank');
                                                                            }
                                                                        }

                                                                        clearmemory();
                                                                        removelazy(bar,lazy);

                                                                    }


                                                                }

                                                            }
                                                            
                                                            else if(issound)
                                                            {

                                                                if(fileloader.settings.filetitlelabel)
                                                                {
                                                                    let startitle = stepdata.filedata.name;
                                                                    stepdata.buttons.title.firstElementChild.setAttribute('value',startitle);
                                                                    updatefiledataname(stepdata,startitle)
                                                                }

                                                                if(fileloader.settings.metalabel)
                                                                {
                                                                    stepdata.container.querySelectorAll('.filetype')[0].innerText = fileextension;
                                                                    stepdata.container.querySelectorAll('.filesize')[0].innerText = (stepdata.filedata.size=='0.000')? '≅.001 mB' : stepdata.filedata.size +' Mb';
                                                                }

                                                                let sound = new Audio();
                                                                sound.src = stepdata.filedata.blob;
                                                                sound.load();
                                                                sound.oncanplay = event_encodedloaded =>
                                                                {

                                                                    if(stepdata.filedata.size>fileweightlimit)
                                                                    {
                                                                        printerror('SIZE OF THIS FILE IS TOO BIG!! MAX SIZE IS '+fileweightlimit+' Mb');
                                                                    }
                                                                    else
                                                                    {

                                                                        if(fileloader.settings.preview)
                                                                        {

                                                                            let previewbox = stepdata.container.querySelectorAll('.preview')[0];
                                                                            previewbox.classList.add( 'bkg-'+stepdata.filedata.typed, 'bkg-'+fileextension );

                                                                            if(previewbox.getElementsByTagName('img')[0].getAttribute('src').value == undefined)
                                                                            {
                                                                                previewbox.firstElementChild.classList.add('hide');
                                                                            }

                                                                            if(fileloader.settings.previewicons==true)
                                                                            {
                                                                                previewbox.insertAdjacentHTML('beforeEnd',`<span class="ico-`+stepdata.filedata.typed+` ico-`+fileextension+`"></span>`);
                                                                            }

                                                                        }

                                                                        if(fileloader.settings.linked)
                                                                        {
                                                                            fileloader.datalist[steptarget].buttons.view.onclick = () =>
                                                                            {

                                                                                blobber = new Blob(
                                                                                [`
                                                                                    <head>
                                                                                      <title>FILE PREVIEWS</title><meta http-equiv="Content-type" content="text/html; charset=UTF-8">
                                                                                    </head>
                                                                                    <body>
                                                                                        <main>
                                                                                            <div>
                                                                                                <small>AUDIO FILES ARE NOT OPTIMIZABLE, WHAT YOU ARE SEEING IS THE STREAMING REPRESENTATION.<br>ORIGINAL DATA ARE SAVED IN BINARY OR B64.</small>
                                                                                                <audio controls="true" src="`+stepdata.filedata.blob+`"></audio>
                                                                                            </div>
                                                                                        </main>
                                                                                    </body>
                                                                                    <style>
                                                                                        html,body{background:#131313;display:flex;height:100%;width:100%;align-self:center;margin:0;padding:0;align-items:center;}
                                                                                        main{max-width:50%;margin: 0 auto;display:flex;flex-direction:column;align-items:center;}
                                                                                        main>div>small{text-align:center;color:white;font-style;font-family:verdana,helvetica;margin-bottom: 20px;font-size: 9px;padding:15px;max-width:100%;}
                                                                                        main>div{display: flex;flex-direction: column;align-items:center;}
                                                                                        image{position:relative;display:block;}
                                                                                    </style>
                                                                               
                                                                                `], {type: "text/html"});
                                                                               
                                                                                window.open( browserurl.createObjectURL(blobber) , '_blank');

                                                                            }
                                                                        }

                                                                        clearmemory();
                                                                        removelazy(bar,lazy);

                                                                    }

                                                                }

                                                            }

                                                            else { unmime(); }

                                                        }

                                                        function unmime()
                                                        {

                                                            if(fileloader.settings.filetitlelabel)
                                                            {
                                                                let startitle = stepdata.filedata.name;
                                                                stepdata.buttons.title.firstElementChild.setAttribute('value',startitle);
                                                                updatefiledataname(stepdata,startitle)
                                                            }

                                                            if(fileloader.settings.metalabel)
                                                            {
                                                                stepdata.container.querySelectorAll('.filetype')[0].innerText = fileextension;
                                                                stepdata.container.querySelectorAll('.filesize')[0].innerText = (stepdata.filedata.size=='0.000')? '≅.001 mB' : stepdata.filedata.size +' Mb';
                                                            }

                                                            if(stepdata.filedata.size>fileweightlimit)
                                                            {
                                                                printerror('SIZE OF THIS FILE IS TOO BIG!! MAX SIZE IS '+fileweightlimit+' Mb');
                                                            }
                                                            else
                                                            {

                                                                if ( fileloader.settings.preview )
                                                                {

                                                                    let previewbox = stepdata.container.querySelectorAll('.preview')[0];
                                                                    previewbox.classList.add( 'bkg-'+stepdata.filedata.typed, 'bkg-'+fileextension );

                                                                    if(previewbox.getElementsByTagName('img')[0].getAttribute('src').value == undefined)//if user not change a src
                                                                    {
                                                                        previewbox.firstElementChild.classList.add('hide');
                                                                    }

                                                                    if(fileloader.settings.previewicons==true)
                                                                    {
                                                                        previewbox.insertAdjacentHTML('beforeEnd',`<span class="ico-`+stepdata.filedata.typed+` ico-`+fileextension+`"></span>`);
                                                                    }

                                                                }
                                                                
                                                                
                                                                if(fileloader.settings.linked)
                                                                {
                                                                    fileloader.datalist[steptarget].buttons.view.onclick = () =>
                                                                    {
                                                                        blobber = new Blob(
                                                                        [`
                                                                            <head>
                                                                              <title>FILE PREVIEWS</title><meta http-equiv="Content-type" content="text/html; charset=UTF-8">
                                                                            </head>
                                                                            <body>
                                                                                <main>
                                                                                    <div>
                                                                                        <small>"NON WEB FILES" ARE CONVERTED AND SAVED IN BINARY OR B64. IT IS NOT POSSIBLE TO READ THEM FROM HERE.</small>
                                                                                    </div>
                                                                                </main>
                                                                            </body>
                                                                            <style>
                                                                                html,body{background:#131313;display:flex;height:100%;width:100%;align-self:center;margin:0;padding:0;align-items:center;}
                                                                                main{max-width:50%;margin: 0 auto;display:flex;flex-direction:column;align-items:center;}
                                                                                main>div>small{text-align:center;color:white;font-style;font-family:verdana,helvetica;margin-bottom: 20px;font-size: 9px;padding:15px;max-width:100%;}
                                                                                main>div{display: flex;flex-direction: column;align-items:center;}
                                                                                image{position:relative;display:block;}
                                                                            </style>
                                                                       
                                                                        `], {type: "text/html"});
                                                                       
                                                                        window.open( browserurl.createObjectURL(blobber) , '_blank');

                                                                    }
                                                                }

                                                                clearmemory();
                                                                removelazy(bar,lazy); //browserurl.revokeObjectURL(steppedfile);

                                                            }

                                                        }


                                                        function imagecompressor(imagechunks, mime, maxw, maxh, optimized)
                                                        {
                                                            
                                                            let b64data = 'no-base64-data';

                                                            try
                                                            {
                                                                b64data = btoa( imagechunks.join('') );
                                                            }
                                                            catch (error)
                                                            {
                                                                printerror('File is oversized for make a preview');
                                                                return optimized('unprintable');
                                                            }
                                                            finally
                                                            {

                                                                if(fileloader.compressor)
                                                                {

                                                                    let image = new Image();
                                                                    image.src = 'data:'+mime+';base64,'+b64data;
                                                                    image.onload = event_encodedloaded =>
                                                                    {

                                                                        let canvas = document.createElement('canvas'),
                                                                            cw = image.width,
                                                                            ch = image.height;

                                                                        // if( cw < minresolution || ch < minresolution ) {  return optimized('toosmall'); }
                                                                        // else
                                                                        // {

                                                                            if(fileloader.compressor.resizingtype=='proportional')
                                                                            {
                                                                                if (cw >= ch) { cw = ~~(cw *= maxh / ch); ch = maxh;  }
                                                                                if (cw < ch) { ch = ~~(ch *= maxw / cw); cw = maxw;   }
                                                                            }
                                                                            else
                                                                            {
                                                                                if (cw >= ch) { ch = ~~(ch *= maxw / cw); cw = maxw; }
                                                                                if (cw < ch) { cw = ~~(cw *= maxh / ch); ch = maxh; }
                                                                            }

                                                                            canvas.width = cw; canvas.height = ch;

                                                                            canvas.getContext("2d").drawImage(image, 0, 0, cw, ch);

                                                                            return optimized( canvas.toDataURL( mime, fileloader.compressor.imageQuality ) );

                                                                        // }
                                                                    }

                                                                }

                                                                else
                                                                {
                                                                    return optimized( b64data );
                                                                }
                                                            }

                                                        }

                                                        function updatefiledataname(stepData,startitle)
                                                        {
                                                           let btninput = stepData.buttons.title.querySelectorAll('input')[0];
                                                            btninput.onfocus = () =>
                                                            {
                                                                console.log('updatet title run...');

                                                                let changename = setInterval( () =>{

                                                                    
                                                                    (!btninput.value)?btninput.value=startitle:null;

                                                                    btninput.setAttribute('value', btninput.value );

                                                                    (document.activeElement == btninput) ? stepData.filedata.name = btninput.value : clearInterval(changename);

                                                                }, 250);

                                                            };
                                                        }


                                                    }


                                                }


                                                // clear data mems if request

                                                function clearmemory()
                                                {
                                                    filechunks=[]; event_encodedloaded=null; reader=null; canvas=null; projector=null; sound=null; image = null; URL.revokeObjectURL(browserurl);
                                                }


                                                // show file in display if request
                                                function removelazy(bar,lazy)
                                                {
                                                    setTimeout(()=>{
                                                        bar.classList.add('hide');
                                                        lazy.classList.add('status-[off]');
                                                        lazy.classList.remove('status-[on]');
                                                    },500)

                                                    return nextstep();
                                                }


                                            })()


                                            // print all "oh fuck!"

                                            readFiles.onabort = (errors) => { debug(`:: [⚠ ui alert]: fileloader error\n   ⮑ critical error/abort: reader crash on loading.\n      reader message:`+errors.error); printerror(errors); }
                                            readFiles.onerror = (errors) => { debug(`:: [⚠ ui alert]: fileloader error\n   ⮑ critical error/abort: reader crash on loading.\n      reader message:`+errors.error); printerror(errors); }
                                            readFiles.oncrash = (errors) => { debug(`:: [⚠ ui alert]: fileloader error\n   ⮑ critical error/abort: reader crash on loading.\n      reader message:`+errors.error); printerror(errors); }

                                            function printerror(errors)
                                            {

                                                let errorstring= (steppedfile.name.substr(steppedfile.name.length - 15)+'  :  '+errors.toUpperCase());

                                                let previewbox = stepdata.container.querySelectorAll('.preview')[0];
                                                if(previewbox)
                                                {
                                                    previewbox.innerHTML = '';
                                                    previewbox.classList.remove('autocrop');
                                                    previewbox.insertAdjacentHTML('beforeEnd','<span class="error-or-not-defined" title="this file have an error. You cannot save/sent data if you not delete it.\n'+errorstring+'"><p>&#10060;</p></span>');
                                                }

                                                let btntitle = stepdata.container.querySelectorAll('.action-rename')[0];
                                                if(btntitle)
                                                {
                                                    btntitle.title="this file have an error. You cannot save/sent data if you not delete it.\n"+errorstring;
                                                    btntitle.firstElementChild.setAttribute('value', errorstring);
                                                    btntitle.firstElementChild.setAttribute('readonly',true);
                                                    btntitle.firstElementChild.setAttribute('disabled',true);
                                                }

                                                if(stepdata.container.querySelectorAll('.action-grab').length>0)
                                                {
                                                    stepdata.container.querySelectorAll('.action-grab')[0].classList.add('disabled');
                                                }

                                                if( fileloader.settings.filters ) { [...stepdata.container.querySelectorAll('.action-options')][0].classList.add('disabled'); }

                                                removelazy(bar,lazy);

                                            }

                                        }

                                    }))()


                                }


                                function updateButtonFileList(fileloader)
                                {

                                    let filestored = [];
                                    setTimeout(()=>{

                                        for (let filebox of fileloader.datalist)
                                        {
                                            let filedata = filebox.origins,
                                                filename = String( filebox.origins.name );

                                            filestored.push( new File( [filedata], filename ) );
                                        }
                                        
                                        setTimeout(()=>{

                                            fileloader.input.files =  FromArrayToInputFileList(filestored);

                                            inputfield       = [...Btn.querySelectorAll('input[type="file"]')][0];
                                            textfield        = [...Btn.getElementsByTagName('label')][0];
                                            
                                            updatebuttonfile(Btn,inputfield,textfield,startlabeltext,fileloader,false);

                                        },200)

                                    },200)

                                }


                                function onclickresetter(fileloader)
                                {
                                    fileloader.resetter.onclick = () =>
                                    {
                                        // reset fileloader

                                        fileloader.display.container.innerHTML = '';
                                        fileloader.datalist = [];
                                        makedisplay(fileloader)

                                        updateButtonFileList(fileloader);
                                    }
                                }


                                function deleteAData(fileloader)
                                {

                                    if(fileloader.settings.deleter)
                                    {

                                        let e_fileloader_del = null;

                                        for (let box of fileloader.datalist)
                                        {

                                            box.buttons.deleter.onclick = e_fileloader_del =>
                                            {
                                                //get steptarget of box via click
                                                let steptarget = [...fileloader.container.querySelectorAll('.action-delete')].indexOf(e_fileloader_del.target);

                                                //prevent other click
                                                for (let contentbox of fileloader.datalist) contentbox.container.classList.add('disabled');

                                                setTimeout(()=>{

                                                    //clean objects and structure
                                                    fileloader.datalist[steptarget].container.remove();
                                                    fileloader.datalist.splice(steptarget,1);

                                                    //re active click
                                                    for (let contentbox of fileloader.datalist) contentbox.container.classList.remove('disabled');


                                                    updateButtonFileList(fileloader)

                                                },100)

                                            }

                                        }

                                    }

                                }


                                fileloader.display.container.ontouchend = ev =>{  ev=null; setTimeout(()=>{reorderdata(fileloader)},250) }
                                fileloader.display.container.onmouseup = ev =>{ ev=null; setTimeout(()=>{reorderdata(fileloader)},250) }
                                
                                function reorderdata(fileloader)
                                {

                                    let neworder = [];
                                   
                                    let databoxes =  fileloader.display.element.querySelectorAll('.databox');

                                    for (let box of databoxes)
                                    {

                                        let boxcontentsid = box.querySelectorAll('.contents')[0].id;

                                        for (let datainmemory of fileloader.datalist)
                                        {
                                            if(boxcontentsid === datainmemory.id)
                                            {
                                                datainmemory.container = box;
                                                neworder.push(datainmemory);
                                            }

                                        }

                                    }

                                }

                            }


                        }

                    }

               }


            }; filereaders();


        }



    //--------------------------------------------------//



        const anchors = () =>
        {


            let Anchors = [...document.querySelectorAll('a[href^="#"]')];

            let l = Anchors.length;
            for (let i = 0; i < l; i++)
            {

                let ALink = Anchors[i],
                    target = ALink.getAttribute('target');


                if(!target)
                {


                    ALink.addEventListener('click', event => {

                        let href = Link.getAttribute("href").split("#")[1];


                        if(href && !target)
                        {

                            event.preventDefault();
                            event.stopPropagation();

                            let targetAncorName = [document.querySelector('*[name="'+href+'"]')][0];

                            if(targetAncorName)
                            {

                                let htpt = targetAncorName.offsetTop,
                                    htpl = targetAncorName.offsetLeft;

                                if(htpt>htpl)
                                {

                                    setTimeout(()=>{
                                        targetAncorName.closest('HTML, BODY, .view, .scroll-y, .scroll-x').scrollTop = htpt;
                                    },100);
                                }
                                else
                                {

                                    setTimeout(()=>{
                                        targetAncorName.closest('HTML, BODY, .view, .scroll-y, .scroll-x').scrollLeft = htpl;
                                    },100);
                                }

                            }

                        }

                    },true);

                }

            }


        }



    //--------------------------------------------------//



        const expansivecard = () =>
        {


            let cards = [...document.querySelectorAll('[class*="card"]')];

            for (let card of cards)
            {


                if(card.firstElementChild.className.match('expansive'))
                {


                        // get box and start values

                        let Box = card.firstElementChild,
                            Close = [...Box.querySelectorAll('.close')][0];

                        // storize the start values of box

                        let OriginalOffsetLeft= Box.getBoundingClientRect().left+'px',
                            OriginalOffsetTop= ( Box.getBoundingClientRect().top-document.body.getBoundingClientRect().top )+'px',
                            OrginalWidth = Box.offsetWidth+'px',
                            OriginalHeight = Box.offsetHeight+'px',
                            DocW = document.body.clientWidth+'px',
                            DocH = document.body.clientHeight+'px';


                        // set the start values on the box and container

                        Box.parentNode.style.width = OrginalWidth;
                        Box.parentNode.style.height= OriginalHeight;
                        Box.style.width = OrginalWidth;
                        Box.style.height = OriginalHeight;


                        // Open and Close box
                        let canclose = false; Close.addEventListener('click', event => { canclose = true; },true);

                        card.addEventListener('click', event => {


                            let HSBox = [...Box.querySelectorAll('.auto-hide-show>.hidden , .auto-hide-show>.show')];


                            if(!Box.classList.contains('active'))
                            {


                                Box.classList.add('activation');

                                Box.style.width = DocW;
                                Box.style.height = DocH;
                                Box.style.marginLeft = -Box.getBoundingClientRect().left+'px';
                                Box.style.marginTop = -Box.getBoundingClientRect().top+'px';

                                if(Box.className.match('auto-hide-show'))
                                {

                                    for (let hsb of HSBox)
                                    {
                                        setTimeout(()=> {

                                              if(hsb.classList.contains('hidden'))
                                              {
                                                hsb.classList.add('show');
                                                hsb.classList.remove('hidden');
                                              }
                                              else if(hsb.classList.contains('show'))
                                              {
                                                hsb.classList.add('hidden');
                                                hsb.classList.remove('show');
                                              }

                                        },250);
                                    }

                                }

                                setTimeout(()=> {

                                    Box.classList.remove('off');
                                    Box.classList.add('active');
                                    Box.classList.remove('activation');
                                    Box.style = null;
                                    canclose = false;

                                },415);

                            }

                            else if (canclose)
                            {

                                let closinganimationtime = 0;

                                setTimeout(()=>{


                                    Box.classList.add('deactivation');

                                    Box.style.width = DocW;
                                    Box.style.height = DocH;


                                    if(Box.classList.contains('auto-hide-show'))
                                    {

                                        for (let hsb of HSBox)
                                        {

                                              if(hsb.classList.contains('hidden'))
                                              {
                                                hsb.classList.add('show');
                                                hsb.classList.remove('hidden');
                                              }
                                              else if(hsb.classList.contains('show'))
                                              {
                                                hsb.classList.add('hidden');
                                                hsb.classList.remove('show');
                                              }
                                        }

                                    }


                                    setTimeout(()=> {

                                        Box.style.left = OriginalOffsetLeft;
                                        Box.style.top = OriginalOffsetTop;
                                        Box.style.width = OrginalWidth;
                                        Box.style.height = OriginalHeight;

                                    },10);

                                    setTimeout(()=> {

                                        Box.classList.remove('deactivation');
                                        Box.classList.add('off');
                                        Box.classList.remove('active');
                                        Box.style = null;

                                        Box.style.width = OrginalWidth;
                                        Box.style.height = OriginalHeight;

                                    },415);

                                },closinganimationtime)

                            }


                        },true);


                }

                else
                {

                        card.addEventListener('click', event => {


                            let Loader = [...document.querySelectorAll('.loader')][0],Href,isntBlank;


                            if( event.target instanceof HTMLLinkElement)
                            {
                                Href = event.target.getAttribute('href'),
                                isntBlank = event.target.getAttribute('target') == ('_top' && '_self' );
                            }

                            else if (event.target.closest('A'))
                            {
                              Href = event.target.parentElement.getAttribute('href'),
                              isntBlank = event.target.parentElement.getAttribute('target') == ('_top' && '_self' );
                            }

                            else
                            {
                              Href = card.querySelector('.card>a:last-child').getAttribute('href'),
                              isntBlank = card.querySelector('.card>a:last-child').getAttribute('target') == ('_top' && '_self' );
                            }


                            // event.preventDefault(),event.stopPropagation(),event.stopImmediatePropagation();

                            event = event || window.event;

                            if(event.target instanceof HTMLImageElement || event.target.parentElement instanceof HTMLImageElement) { return null; }

                            else
                            {

                                if(isntBlank)
                                {

                                    Loader.classList.add('off');
                                    Loader.classList.remove('hide');

                                    setTimeout( function(){
                                        Loader.classList.add('active');
                                        Loader.classList.remove('off');
                                    }, 50);


                                    setTimeout( function(){

                                        if(Href==='#')
                                        {
                                            location.reload();
                                        }
                                        else
                                        {
                                            location.href = Href;
                                        }
                                      
                                    }, 300);
                                
                                }

                                else
                                {
                                    window.open(Href, '_blank');
                                    //location.href = Href;
                                }

                            }

                        },true);

                }

            }


        }



    //--------------------------------------------------//



        const tabx = () =>
        {


            let alltabsx = [...document.querySelectorAll(".tabs-x")];

            for (let tab of alltabsx)
            {


                let mainmask  = tab.getElementsByClassName('mask')[0],
                    tlist     = tab.querySelectorAll('.title nav a'), 
                    wlist     = tab.querySelectorAll('.mask>.mask');


                // set elements to start
                for (let T of tlist) T.className = (name!='off' && name!='active') ? name='off' : T.className;
                for (let W of wlist) W.className = (name!='off' && name!='active') ? name='off' : W.className;


                let l = tlist.length;
                for (let i = 0; i < l; i++)
                {


                    let title = tlist[i], //tab title in list
                        wrap  = wlist[i]; //tab content wraps


                    //if start closed... hide contents
                    if(title.className.match('close active'))
                    {

                        for (let x = 0; x < l; x++)
                        {
                            if(x!=i)
                            {
                                tlist[x].classList.replace("active","off");
                                wlist[x].classList.replace("active","off");
                            }
                        }

                        //close is active
                        title.classList.replace("off","active");

                        //hide all
                        mainmask.style.height='0px';

                    }

                    // first tab is start
                    else
                    {

                        title.classList.add('off');
                        wrap.classList.add('off');

                        tlist[0].classList.replace('off','active');
                        wlist[0].classList.replace('off','active');

                        // set height
                        mainmask.style.height = wlist[0].scrollHeight+'px';

                    }


                    title.addEventListener( 'click', ev_tabtitleclick =>{


                        //if click on close...
                        if(title.className.match('close'))
                        {

                            //reset all
                            for (let x = 0; x < l; x++)
                            {
                                tlist[x].classList.replace("active","off");
                                wlist[x].classList.replace("active","off");
                            }
                            wrap.classList.add("off");

                            //close is active
                            title.classList.replace("off","active");

                            //hide all
                            mainmask.style.height='0px';

                        }

                        else
                        {

                            if(!title.className.match('active'))
                            {

                                for (let x = 0; x < l; x++)
                                {
                                    tlist[x].classList.replace("active","off");
                                    wlist[x].classList.replace("active","off");
                                }

                                title.classList.replace("off","active");
                                wrap.classList.replace("off","active");

                            }

                            // height adaption
                            setTimeout(()=>{
                                let active = mainmask.getElementsByClassName('active')[0];
                                if(active!=undefined) mainmask.style.height = active.scrollHeight+'px';
                            },100)
                        }



                    },true);


                }


            }


        }



    //--------------------------------------------------//



        const taby = () =>
        {


            let alltabsy = [...document.querySelectorAll(".tabs-y")], tabssize = alltabsy.length;

            for (let tab of alltabsy)
            {


                let titleslist = [...tab.querySelectorAll(".tabs-y>.title")], titlelength = titleslist.length;

                for (let title of titleslist)
                {


                    let closeicon = title.querySelectorAll('.close')[0],
                        content   = title.nextElementSibling;


                    title.classList.add('off');
                    content.classList.add('off');


                    if(title.className.match('active'))
                    {
                        title.classList.remove('off');
                        content.classList.remove('off');
                        content.style.height = content.scrollHeight+"px";
                        content.classList.add('active');
                    }


                    // on title click, open tab ...
                    title.addEventListener('click', ev_titleclick_tab_y =>{

                        if(ev_titleclick_tab_y.target != closeicon)
                        {

                            for (let x = 0; x < titlelength; x++)
                            {
                                titleslist[x].classList.add('off');
                                titleslist[x].classList.remove('active');
                                titleslist[x].nextElementSibling.classList.add('off');
                                titleslist[x].nextElementSibling.classList.remove('active');
                                titleslist[x].nextElementSibling.style.height = "0";
                            }
                          
                            content.style.height = content.firstElementChild.scrollHeight+"px";
                            content.classList.replace('off','active');
                            title.classList.replace('off','active');

                            return false;

                        }

                    },true);


                    // on close click, reset tabs ...
                    closeicon.addEventListener('click',
                    ()=>{

                        title.classList.replace('active','off');
                        title.nextElementSibling.classList.replace('active','off');
                        title.nextElementSibling.style.height = "0";

                    },true);


                }


            }


        }



    //--------------------------------------------------//



        const spoilers = () =>
        {


            let spoilerslist = [...document.querySelectorAll("[class^=spoiler]")];
            
            // prepare for start
            for (let spoiler of spoilerslist)
            { 
                if(!spoiler.getAttribute('open')  || (!spoiler.getAttribute('open') && !spoiler.querySelectorAll('.mask')[0].className.contains('active')) )
                {

                    spoiler.removeAttribute('open');
                    spoiler.querySelectorAll('.mask')[0].classList.add('off');

                }
            }
            
            
            for (let spoiler of spoilerslist) spoiler.querySelectorAll('.title')[0].addEventListener('click', ev_toggletree=>{ toggle(spoiler, spoiler.querySelectorAll('.mask')[0],ev_toggletree) },true)
            
            function toggle(spoiler,contents,ev_toggletree)
            {

                if(ev_toggletree.target.tagName.toLowerCase()!='a')
                {

                    if(!spoiler.getAttribute('open'))
                    {

                        contents.style.height = contents.scrollHeight+"px";
                        contents.classList.add('active');
                        contents.classList.remove('off');
                        spoiler.setAttribute('open',true);

                        setTimeout(()=>{
                            contents.style.height = "initial";
                        },155)

                    }

                    else
                    {

                        contents.style.height = contents.scrollHeight+"px";

                        setTimeout(()=>{

                            contents.classList.add('off');
                            contents.classList.remove('active');
                            spoiler.removeAttribute('open');
                            contents.style.height = "0px";

                        },200)

                    }

                }

            }


        }



    //--------------------------------------------------//


       // const details = () =>
       // {
       // 
       //    let AllDetails = [...document.querySelectorAll("details")];
       // 
       //    for (let Line of AllDetails) Line.querySelectorAll('summary')[0].addEventListener('click', ev_toggledetails=>{ toggledetails(Line,ev_toggledetails) },true)
       // 
       //    function toggledetails(Line,ev_toggledetails)
       //    {
       // 
       //       if(ev_toggletree.target.tagName.toLowerCase()!='a')
       //       {
       // 
       //          if(Line.classList.contains('active'))
       //          {
       //             Line.classList.add('off');
       //             Line.classList.remove('active');
       //          }
       //          else
       //          {
       //             Line.classList.add('active');
       //             Line.classList.remove('off');
       //          }
       // 
       //       }
       // 
       //    }         
       // 
       // }


   
   
    //--------------------------------------------------//



        const videos = () =>
        {


            let videotags =  [...document.querySelectorAll('.type-background, .type-player, .type-backscreen')];
            for (let i = 0; i < videotags.length; i++)
            {
                if(['iframe','video'].indexOf(videotags[i].tagName.toLowerCase())<0)
                {
                    videotags[i].parentNode.classList.add('debug-error');
                    debug(`:: [⚠ ui alert]: wrong video\n   ⮑ Framework support only <video> for create a preset.\n      read more on: https://git.io/vldt456`);
                }
            }


            let videobackgrouds = [...document.querySelectorAll('video.type-background')];
            for (let i = 0; i < videobackgrouds.length; i++)
            {
                videobackgrouds[i].parentNode.style.overflow = "hidden";
                videobackgrouds[i].parentNode.style.position = "relative";
            }


            let videoplayers = [...document.querySelectorAll('video.type-player')];
            for (let i = 0; i < videoplayers.length; i++)
            {

                let player = videoplayers[i], classes = [...player.classList].join('');

                if(!classes.includes('[ON]','[OFF]'))
                {

                    // all params
                    let error        = false,
                        ids          = player.getAttribute('id'),
                        srcstring    = player.src,
                        dataoptions  = player.dataset.options || null,
                        optionslist  = (dataoptions!=null)?dataoptions.split('[')[1].split(']')[0].split(','):'',
                        addoptions   = '',
                        addclasses   = '',
                        addids       = '',
                        addrelink    = '',
                        addlink      = '',
                        wrapper,
                        htmlcode;

                    // check video url
                    let isyouwatch 	= srcstring.match(/watch/gi),
                        isyoutu_be  = srcstring.match(/(?:youtu)(?:\.be)\/([\w\W]+)/i) ,
                        isyoutube 	= srcstring.match(/(?:youtube)(?:\.com)\/([\w\W]+)/i),
                        isVimeo 	  = srcstring.match(/(?:vimeo)(?:\.com)\/([\w\W]+)/i),
                        isInstagram = srcstring.match(/(?:instagram)(?:\.com)\/([\w\W]+)/i),
                        isFacebook  = srcstring.match(/(?:facebook)(?:\.com)\/([\w\W]+)/i)||srcstring.match(/(?:fb)(?:\.com)\/([\w\W]+)/i),
                        isTwitter   = srcstring.match(/(?:twitter)(?:\.com)\/([\w\W]+)/i),
                        isTwitch    = srcstring.match(/(?:twitch)(?:\.tv)\/([\w\W]+)/i);

                    // set by types

                    if(isyoutu_be||isyoutube||isyouwatch)
                    {

                            //stripe opts
                            
                            if(!ids){ addids=''; }else{ addids=' id="'+ids+'"'; }
                            
                            if(dataoptions!=null)
                            {
                                if(optionslist.includes('autohide'))          { (classes=='') ? addclasses='class="[youtube autohide]"' : addclasses=' class="'+classes+' [youtube autohide]"'; }
                                else if(optionslist.includes('autostop'))     { (classes=='') ? addclasses='class="[youtube autostop]"' : addclasses=' class="'+classes+' [youtube autostop]"'; }
                                else                                          { (classes=='') ? addclasses='class="[youtube]"' : addclasses=' class="'+classes+' [youtube]"'; }

                                if(optionslist.includes('clearui'))           { addoptions  += '&rel=0&modestbranding=1&showinfo=0&showtitle=0&iv_load_policy=3'; }else{ addoptions += '&iv_load_policy=1'; }
                                if(optionslist.includes('controls'))          { addoptions  += '&controls=1'; }else{ addoptions += '&controls=0'; }
                                if(optionslist.includes('lang'))              { addoptions  += '&hl='+optionslist.split('lang-')[1].split(',')[0]+'&cc_load_policy=1'; }
                                if(optionslist.includes('playlist'))          { addoptions  += '&list='+optionslist.split('playlist-')[1].split(',')[0]; }
                                if(optionslist.includes('autoplay'))          { addoptions  += '&autoplay=1&mute=1'; }
                                if(optionslist.includes('autopause'))         { addoptions  += '&autopause=1'; }
                                if(optionslist.includes('loop'))              { addoptions  += '&loop=1'; }
                                if(optionslist.includes('volume-'))           { addoptions  += '&volume='+optionslist.split('volume-')[1].split(',')[0]; }

                            }
                            else
                            {
                              (classes=='')? addclasses='class="[youtube]"':addclasses=' class="'+classes+' [youtube]"';
                              addoptions = '&iv_load_policy=1&controls=1';
                            }
                            
                            //make new link
                            
                            if(isyouwatch)      { addlink = 'https://www.youtube.com/embed/'+srcstring.split('\/watch?v=')[1].split('=')[0]+'?enablejsapi=1&version=3&playsinline=0'; }
                            else if(isyoutube)  { addlink = 'https://www.youtube.com/embed/'+srcstring.split('embed\/')[1].split('=')[0]+'?enablejsapi=1&version=3&playsinline=0'; }
                            else if(isyoutu_be) { addlink = 'https://www.youtube.com/embed/'+srcstring.split('\.be\/')[1]+'?enablejsapi=1&version=3&playsinline=0'; }
                            else                { error=true;  debug(`:: [⚠ ui alert]: wrong video\n   ⮑ Youtube video link unsupported\n      read more on: https://git.io/vldt456`);}
                            
                            if(error==false)
                            {

                                //create new elem
                                htmlcode = '<iframe '+addids+addclasses+' src="'+addlink+addoptions+'" scrolling="no" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
                                wrapper = document.createElement('div');

                                //wrap inside new code
                                wrapper.innerHTML = htmlcode;
                                player.parentNode.insertBefore(wrapper, player);

                                //unwrap, make free
                                wrapper.outerHTML = wrapper.innerHTML;
                                player.parentNode.removeChild(player);

                            }

                    }
                  
                    // vimeo

                    else if (isVimeo)
                    {

                            //stripe opts

                            if(ids==null){ addids=''}else{addids=' id="'+ids+'"'}
                            
                            if(dataoptions!=null)
                            {

                                if(optionslist.includes('autohide'))          {(classes=='')? addclasses='class="[vimeo autohide]"':addclasses=' class="'+classes+' [vimeo autohide]"';}
                                else if(optionslist.includes('autostop'))     {(classes=='')? addclasses='class="[vimeo autostop]"':addclasses=' class="'+classes+' [vimeo autostop]"';}
                                else                                          {(classes=='')? addclasses='class="[vimeo]"':addclasses=' class="'+classes+' [vimeo]"';}

                                if(optionslist.includes('autoplay'))          { addoptions += '&background=1&muted=1&autoplay=1&'; }else{ addoptions+='&background=1';}
                                if(optionslist.includes('clearui'))           { addoptions += '&byline=0&sidedock=0&title=0'; }
                                if(optionslist.includes('controls'))          { addoptions += '&controls=1'; }else{ addoptions += '&controls=0'; }
                                if(optionslist.includes('lang'))              { addoptions += '&texttrack='+optionslist.split('lang-')[1].split(',')[0] }
                                if(optionslist.includes('playlist'))          { addoptions += '&playlist=1'; }
                                if(optionslist.includes('loop'))              { addoptions += '&loop=1'; }
                                if(optionslist.includes('volume-'))           { addoptions += '&volume='+optionslist.split('volume-')[1].split(',')[0] } 

                            }

                            else
                            {
                                (classes=='')? addclasses='class="[vimeo]"':addclasses=' class="'+classes+' [vimeo]"';
                                addoptions = '&background=1&controls=1';
                            }

                            //make new link
                            addlink = 'https://player.vimeo.com/video/'+srcstring.split('.com/')[1]+'?dnt=1&autopause=1&playsinline=0&transparent=0';

                            //create new elem api=1&
                            htmlcode = '<iframe '+addids+addclasses+' src="'+addlink+addoptions+'&portrait=0" scrolling="no" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
                            wrapper = document.createElement('div');
                          
                            //wrap inside new code
                            wrapper.innerHTML = htmlcode;
                            player.parentNode.insertBefore(wrapper, player);
                          
                            //unwrap, make free
                            wrapper.outerHTML = wrapper.innerHTML;
                            player.parentNode.removeChild(player);

                    }

                    //twitter

                    else if(isTwitter)
                    {

                        // fetch('https://api.twitter.com/1.1/statuses/show/1234567890.json?tweet_mode=extended')
                        // .then(data => data.text() )
                        // .then(data => {
                        // 
                        //   let igVideoUrl = data.split('og:video" content="')[1].split('"')[0];
                        //   setTimeout(()=>{
                        // 
                        //     //stripe opts
                        //     if(dataoptions!=null)
                        //     {
                        //       if(optionslist.includes('autohide'))          { player.classList = [...player.classList].join() + " [twitter autohide]"; }
                        //       else if(optionslist.includes('autostop'))     { player.classList = [...player.classList].join() + " [twitter autostop]"; }
                        //       else                                          { player.classList = [...player.classList].join() + " [twitter]"; }
                        // 
                        //       if(optionslist.includes('clearui', 'lang','playlist'))
                        //       { debug(`:: [⚠ ui alert]: wrong video\n   ⮑ Twitter video not support: 'clearui','lang','playlist'.\n      read more on: https://git.io/vldt456`); }
                        //       else
                        //       {
                        // 
                        //         if(optionslist.includes('controls'))  { player.controls="true" }
                        //         if(optionslist.includes('autoplay'))  { player.muted="true"; player.autoplay="true"; }
                        //         if(optionslist.includes('loop'))      { player.loop="true"; }
                        //         if(optionslist.includes('volume-'))   { player.volume="0.5"; }
                        // 
                        //         player.removeAttribute('data-options');
                        //       }
                        // 
                        //     }
                        //     else
                        //     {
                        //       player.classList.add('[twitter]')
                        //     }
                        // 
                        //     player.src = igVideoUrl;
                        // 
                        //   },200)
                        // 
                        // });

                    }

                    // instagram
                    else if (isInstagram)
                    {


                        fetch(srcstring)
                        .then(data => data.text() )
                        .then(data => {

                            let igVideoUrl,container;
                            try{ igVideoUrl = data.split('og:video" content="')[1].split('"')[0]; }
                            catch
                            {

                                container = player.parentNode;

                                container.innerHTML = 
                                `
                                   <div>
                                      <div class="absolute-center pad-[20] align-center radius-medium" style="border: 2px solid #c2226d; max-width:400px">
                                         <img style="width: 75px; margin: 0 auto 20px;" src="data:image/svg+xml,%3Csvg viewBox='0 0 551.034 551.034' xmlns='http://www.w3.org/2000/svg'%3E%3Cg%3E%3ClinearGradient id='SVGID_1_' gradientUnits='userSpaceOnUse' x1='275.517' y1='4.57' x2='275.517' y2='549.72' gradientTransform='matrix(1 0 0 -1 0 554)'%3E%3Cstop offset='0' style='stop-color:%23E09B3D'%3E%3C/stop%3E%3Cstop offset='0.3' style='stop-color:%23C74C4D'%3E%3C/stop%3E%3Cstop offset='0.6' style='stop-color:%23C21975'%3E%3C/stop%3E%3Cstop offset='1' style='stop-color:%237024C4'%3E%3C/stop%3E%3C/linearGradient%3E%3Cpath style='fill:url(%23SVGID_1_);' d='M386.878,0H164.156C73.64,0,0,73.64,0,164.156v222.722 c0,90.516,73.64,164.156,164.156,164.156h222.722c90.516,0,164.156-73.64,164.156-164.156V164.156 C551.033,73.64,477.393,0,386.878,0z M495.6,386.878c0,60.045-48.677,108.722-108.722,108.722H164.156 c-60.045,0-108.722-48.677-108.722-108.722V164.156c0-60.046,48.677-108.722,108.722-108.722h222.722 c60.045,0,108.722,48.676,108.722,108.722L495.6,386.878L495.6,386.878z'%3E%3C/path%3E%3ClinearGradient id='SVGID_2_' gradientUnits='userSpaceOnUse' x1='275.517' y1='4.57' x2='275.517' y2='549.72' gradientTransform='matrix(1 0 0 -1 0 554)'%3E%3Cstop offset='0' style='stop-color:%23E09B3D'%3E%3C/stop%3E%3Cstop offset='0.3' style='stop-color:%23C74C4D'%3E%3C/stop%3E%3Cstop offset='0.6' style='stop-color:%23C21975'%3E%3C/stop%3E%3Cstop offset='1' style='stop-color:%237024C4'%3E%3C/stop%3E%3C/linearGradient%3E%3Cpath style='fill:url(%23SVGID_2_);' d='M275.517,133C196.933,133,133,196.933,133,275.516s63.933,142.517,142.517,142.517 S418.034,354.1,418.034,275.516S354.101,133,275.517,133z M275.517,362.6c-48.095,0-87.083-38.988-87.083-87.083 s38.989-87.083,87.083-87.083c48.095,0,87.083,38.988,87.083,87.083C362.6,323.611,323.611,362.6,275.517,362.6z'%3E%3C/path%3E%3ClinearGradient id='SVGID_3_' gradientUnits='userSpaceOnUse' x1='418.31' y1='4.57' x2='418.31' y2='549.72' gradientTransform='matrix(1 0 0 -1 0 554)'%3E%3Cstop offset='0' style='stop-color:%23E09B3D'%3E%3C/stop%3E%3Cstop offset='0.3' style='stop-color:%23C74C4D'%3E%3C/stop%3E%3Cstop offset='0.6' style='stop-color:%23C21975'%3E%3C/stop%3E%3Cstop offset='1' style='stop-color:%237024C4'%3E%3C/stop%3E%3C/linearGradient%3E%3Ccircle style='fill:url(%23SVGID_3_);' cx='418.31' cy='134.07' r='34.15'%3E%3C/circle%3E%3C/g%3E%3C/svg%3E" />
                                         <div class="pap-[10]"></div>
                                         <p style="font-size:11px;">You can't see this content if you not be logged in.</p>
                                         <div class="pap-[10]"></div>
                                         <a style="color:#c2226d;" target="_blank" href="https://www.instagram.com/">LOGIN INSTAGRAM</a>
                                      </div>
                                   </div>
                                `;

                                container.classList.add('status-[off]');

                                setTimeout(()=>{
                                   container.classList.remove('status-[off]');
                                   container.classList.remove('status-[on]');
                                },750)
                                
                            }
                            finally
                            {

                                //stripe opts
                                if(dataoptions!=null)
                                {

                                    if(optionslist.includes('autohide'))          { player.classList = [...player.classList].join() + " [instagram autohide]"; }
                                    else if(optionslist.includes('autostop'))     { player.classList = [...player.classList].join() + " [instagram autostop]"; }
                                    else                                          { player.classList = [...player.classList].join() + " [instagram]"; }

                                    if(optionslist.includes('clearui', 'lang','playlist'))
                                    { debug(`:: [⚠ ui alert]: wrong video\n   ⮑ Instagram video not support: 'clearui','lang','playlist'.\n      read more on: https://git.io/vldt456`); }
                                    else
                                    {

                                        if(optionslist.includes('controls'))  { player.controls="true" }
                                        if(optionslist.includes('autoplay'))  { player.muted="true"; player.autoplay="true"; }
                                        if(optionslist.includes('loop'))      { player.loop="true"; }
                                        if(optionslist.includes('volume-'))   { player.volume="0.5"; }

                                        player.removeAttribute('data-options');
                                    }
                                  
                                }

                                else
                                {
                                    player.classList.add('[instagram]')
                                }

                                player.src = igVideoUrl;

                            }


                        })

                    }
                  

                    // Facebook
                    else if (isFacebook)
                    {

                            if(dataoptions!=null)
                            {
                              
                              //stripe options
                              if(optionslist.includes('clearui'))   { addoptions += '&show_text=false&hide_cover=true'; }
                              if(optionslist.includes('autoplay'))  { addoptions += '&autoplay=true'; }else{ addoptions+='&autoplay=false'; }
                              if(optionslist.includes('loop'))      { addoptions += '&loop=true'; }


                              if(optionslist.includes('playlist','lang','volume','controls')) debug(`:: [⚠ ui alert]: wrong video\n   ⮑ Facebok video not support 'controls','playlist','lang','volume'\n      read more on: https://git.io/vldt456`);
                              if(optionslist.includes('autohide'))                            debug(`:: [⚠ ui alert]: wrong video\n   ⮑ Facebook video support only autounload\n      read more on: https://git.io/vldt456`);

                              if(optionslist.includes('autounload'))
                              {
                                (classes=='') ? addclasses='class="[facebook autounload]"' : addclasses=' class="'+classes+' [facebook autounload]"';
                                addrelink = ' data-relink="'+addlink+'"';
                              }
                              else
                              {
                                (classes=='') ? addclasses='class="[facebook]" data-autoplay="true"':addclasses=' class="'+classes+' [facebook]"';
                                addrelink = '';
                              }

                            }
                            else
                            {
                              (classes=='')? addclasses='class="[facebook] fb-post" data-autoplay="true"':addclasses=' class="'+classes+' [facebook] fb-post"';
                              addoptions += "&show_text=false&hide_cover=true"; //&autoplay=false
                            }

                            //make new link
                            if(srcstring.match("extid")) { error=true; debug(`:: [⚠ ui alert]: wrong video\n   ⮑ Facebook video link unsupported\n      read more on: https://git.io/vldt456`); }
                            else
                            { 

                              if(srcstring.match("videos")) { addlink = 'https://www.facebook.com/plugins/video.php?href='+encodeURIComponent(srcstring.replace('facebook','fb')); }
                              else if(srcstring.match("posts") || srcstring.match("story") || srcstring.match(/\?v=/g))    { addlink = 'https://www.facebook.com/plugins/post.php?href='+encodeURIComponent(srcstring.replace('facebook','fb')); }
                              else { error=true; debug(`:: [⚠ ui alert]: wrong video\n   ⮑ Facebook video link unsupported\n      read more on: https://git.io/vldt456`); }

                            }
                            

                            //make iframe
                            if(!error)
                            {

                              //+class,id,data
                              if(ids==null){ addids=''}else{ addids=' id="'+ids+'"' }
                              
                              
                              //create new elem api=1&
                              htmlcode = '<iframe '+addids+addclasses+addrelink+' src="'+addlink+addoptions+'&autohide=true" scrolling="no" data-show-text="false" data-autoplay="true" allow="encrypted-media" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
                              wrapper = document.createElement('div');
                              
                              //wrap inside new code
                              wrapper.innerHTML = htmlcode;
                              player.parentNode.insertBefore(wrapper, player);
                              
                              //unwrap, make free
                              wrapper.outerHTML = wrapper.innerHTML;
                              player.parentNode.removeChild(player);
                            }

                    }

                    // html player
                    else
                    {

                        player.setAttribute('controls','true');
                        player.setAttribute('preload','true');

                    }
                }

            }

        }



    //--------------------------------------------------//
 


        const fitup = () =>
        {

            setTimeout(()=>{

                let fits = [...document.querySelectorAll(".fit-up")];

                for (let fit of fits)
                {

                    fit.parentNode.style.position = "relative";

                    let H = fit.previousElementSibling.offsetHeight,
                        W = fit.previousElementSibling.offsetWidth;

                    fit.style.height = H+'px';
                    fit.style.width = W+'px';
                    fit.style.margin = ('-'+H+'px 0 -'+H+'px 0');

                }

            },10)

        }



    //--------------------------------------------------//



        const fitheight = () =>
        {

            let fits = [...document.querySelectorAll(".fit-height")];

            for (let fit of fits)
            {

                fit.parentNode.style.position = 'relative';

                let H = fit.parentNode.offsetHeight,
                    W = fit.parentNode.offsetWidth;

                fit.style.width = W+'px';
                fit.style.height = H+'px';

            }

        }



    //--------------------------------------------------//



        const parallax = () =>
        {
         

            window.addEventListener('touchmove', () => { checkparallax = setInterval( moveparallax() , 50); },false);
            window.addEventListener('scroll',    () => { moveparallax() },false);

            /*>>>>*/ moveparallax();
            function moveparallax()
            {

                setTimeout(()=>{


                    let parallaxList = [...document.querySelectorAll('*[class*="Parallax-["]')];

                    for (let parallax of  parallaxList)
                    {


                        let scale,sensibility;
                        if(parallax.className.match("mask"))
                        {
                            scale       = parallax.className.split('lax-[')[1].split('-mask]')[0].split('-')[1],
                            sensibility = parallax.className.split('lax-[')[1].split('-mask]')[0].split('-')[0];
                        }
                        else
                        {
                            scale = parallax.className.split('lax-[')[1].split(']')[0].split('-')[1],
                            sensibility = parallax.className.split('lax-[')[1].split(']')[0].split('-')[0];
                        }


                        //get all box values
                        let height            = parallax.offsetHeight,
                            width             = parallax.offsetWidth,
                            reltop            = parallax.offsetTop, // positon of box into page
                            relleft           = parallax.offsetLeft,
                            distancetotop     = parallax.getBoundingClientRect().top+(height/2), // scroll positon respect the top of screen
                            distancetoleft    = parallax.getBoundingClientRect().left+(width/2),
                            screen_h          = document.body.clientHeight,
                            screen_w          = document.body.clientWidth;



                        //starter box positon
                        let y_start =  (distancetotop-(screen_h/2))*-1,
                            x_start =  (distancetoleft-(screen_w/2))*-1;


                        //for all child of box
                        let counterbox = 1;

                        for (let innerbox = 0; i < l; i++)
                        {

                            counterbox++;

                            let Y =  ( y_start/screen_h )*(100-(counterbox*sensibility)),
                                X =  ( x_start/screen_w )*(100-(counterbox*sensibility));

                            innerbox.style.transformOrigin = "center";

                            if(parallax.className.match('xParallax-'))
                            {
                                innerbox.style.transform = "scale("+(scale)+") translate("+X+"px,"+0+"px)";
                            }
                            else if (parallax.className.match('yParallax-'))
                            {
                                innerbox.style.transform = "scale("+(scale)+") translate("+0+"px,"+Y+"px)";
                            }
                            else
                            {
                                innerbox.style.transform = "scale("+(scale)+") translate("+X+"px,"+Y+"px)";
                            }

                        }

                    }

                },50);

            };


        }



    //--------------------------------------------------//



        const effectors = () =>
        {

            let Efxs = [...document.querySelectorAll('[class*="fx-["]')];

            let efxssize = Efxs.length;
            for (let i = 0; i < efxssize; i++)
            {

                let params = Efxs[i].className.split('fx-[')[1].split(']')[0];

                let Target,
                    Trigger,
                    action,
                    cssin,
                    timerin,
                    delayin,
                    cssout,
                    timerout,
                    delayout,
                    toggle,
                    hide,
                    reset;

                if(params.match("on:"))
                {
                    action = ""+params.split("on:")[1].split(";")[0];
                }

                if(params.match("target:"))
                {
                    let targetstring = String(params.split("target:")[1].split(";")[0]);
                    Target = [...document.querySelectorAll('[class*="target-'+targetstring+'"]')];
                }
                else
                {
                    Target = [Efxs[i]];
                }

                if(params.match("trigger:"))
                {
                    let triggerstring = String(params.split("trigger:")[1].split(";")[0]);
                    Trigger = [...document.querySelectorAll('[class*="trigger-'+triggerstring+'"]')];
                }
                else
                {
                    Trigger = [Efxs[i]];
                }

                if(params.match("in:"))
                {

                    cssin = ""+params.split("in:")[1].split(";")[0].split(",")[0];
                    timerin = ""+params.split("in:")[1].split(";")[0].split(",")[1];
                    delayin = ""+params.split("in:")[1].split(";")[0].split(",")[2];

                    if(!timerin) { timerin = 1; }
                    if(!delayin) { delayin = 1; }

                } else { debug(`[⚠ ui alert]: wrong effector\n   ⮑ "in" parameter not found!`) };

                if(params.match("out:"))
                {
                    cssout = ""+params.split("out:")[1].split(";")[0].split(",")[0];
                    timerout = ""+params.split("out:")[1].split(";")[0].split(",")[1];
                    delayout = ""+params.split("out:")[1].split(";")[0].split(",")[2];

                    if(!timerout) { timerout = 1; }
                    if(!delayout) { delayout = 1; }

                } else { cssout = false; }

                if(params.match("toggle:"))
                {

                    toggle = ""+params.split("toggle:")[1].split(";")[0]; if(toggle == "true"){ toggle = true; } else {toggle= false;}

                } else { toggle = true; }

                if(params.match("hide:"))
                {
                    hide = ""+params.split("hide:")[1].split(";")[0];

                } else { hide = false; }

                if(params.match("reset:"))
                {
                    reset = ""+params.split("reset:")[1].split(";")[0]; if(reset == "true"){ reset = true; } else { reset = false; }

                } else { reset = false; }


                let triggersize =Trigger.length;
                for (let trs = 0; trs < triggersize; trs++)
                {


                    let targetsize =Target.length;
                    for (let i = 0; i < targetsize; i++)
                    {


                        if(hide && !Target[i].className.match('fx-active'))
                        {
                            Target[i].style.opacity = 0;
                        }

                        switch (action)
                        {

                            case 'unloadDoc':

                                debug(`:: [⚠ ui alert]: wrong effector\n   ⮑ unload not can be used in this version of fx. Sorry.`);

                            break;

                            case 'loadDoc':

                                setTimeout(()=>{
                                    setTimeout(()=>{

                                        Target[i].classList.add('fx-active',cssin);
                                        Target[i].classList.remove('fx-off',cssout);

                                        setTimeout(()=>{

                                            if(reset)
                                            {
                                                Target[i].classList.remove(cssin);
                                            }

                                        },timerin)

                                    },delayin);
                                },100);

                            break;

                            case "scroll":

                                if( Target[i].offsetTop < screen.height && !Target[i].className.match('cssin') )
                                {
                                    Target[i].classList.add('fx-active',cssin);
                                }

                                window.addEventListener("scroll", event => { makefx_scrolling(event); }, true);

                                let makefx_scrolling = (event) =>
                                {

                                    let	scrlDelPosIn = parseInt( document.documentElement.scrollTop + screen.height-(screen.height/10)),
                                        scrlDelPosOut = parseInt( document.documentElement.scrollTop + (screen.height/10)),
                                        scrlBodyPosIn = parseInt( document.body.scrollTop + screen.height-(screen.height/10)),
                                        scrlBodyPosOut = parseInt( document.body.scrollTop + (screen.height/10)),
                                        elPos = parseInt( Target[i].offsetTop );

                                    if(!Target[i].className.match('fx-active'))
                                    {

                                        if(
                                            (elPos < scrlDelPosIn && elPos > scrlDelPosOut)
                                            || (elPos < scrlBodyPosIn && elPos > scrlBodyPosOut)
                                          )
                                        {

                                            setTimeout(()=>{

                                                Target[i].classList.add(cssin);
                                                Target[i].classList.remove(cssout);

                                                setTimeout(()=>{

                                                    if(reset)
                                                    {
                                                        Target[i].classList.remove(cssin);
                                                    }
                                                    else
                                                    {
                                                        Target[i].classList.add('fx-off');
                                                        Target[i].classList.remove('fx-active');
                                                    }

                                                },timerin)


                                            },delayin+timerout);

                                        }

                                    }

                                    else if(
                                        ( (elPos < scrlDelPosOut || elPos > scrlDelPosIn)
                                          || (elPos < scrlBodyPosOut || elPos > scrlBodyPosIn ) )
                                        && Target[i].className.match('fx-off') && toggle
                                      )
                                    {

                                        Target[i].classList.add(cssout);
                                        Target[i].classList.remove(cssin);

                                        Target[i].classList.add('fx-active');
                                        Target[i].classList.remove('fx-off');

                                        if(reset)
                                        {
                                            setTimeout(()=>{
                                                Target[i].classList.remove(cssout);
                                            },timerout)
                                        }

                                    }

                                    return false;

                                }

                            break;

                            case "hover":

                                Trigger[trs].addEventListener("mouseover", event =>{ makefx_hoverin() },true);
                                Trigger[trs].addEventListener("mouseleave", event =>{ makefx_hoverout() },true);

                                let makefx_hoverin = () => {

                                    let l = Target.length;
                                    for (let i = 0; i < l; i++)
                                    {

                                        if(!Target[i].className.match('fx-active') || Target[i].className.match('fx-off'))
                                        {

                                            setTimeout(()=>{

                                                Target[i].classList.add('fx-active', cssin);
                                                Target[i].classList.remove(cssout, 'fx-off');

                                                setTimeout(()=>{

                                                    if(reset === true)
                                                    {
                                                        Target[i].classList.remove(cssin);
                                                        Target[i].classList.remove(cssin, 'fx-active');
                                                    }

                                                },timerin)

                                            },delayin);

                                        }

                                    }

                                }

                                let makefx_hoverout = () => {

                                    for (let i = 0; i < Target.length; i++)
                                    {

                                        if(Target[i].className.match('fx-active') && toggle)
                                        {

                                            setTimeout(()=>{

                                                Target[i].classList.add(cssout,'fx-off');
                                                Target[i].classList.remove(cssin,'fx-active');

                                                if(reset)
                                                {
                                                    setTimeout(()=>{
                                                        Target[i].classList.remove(cssout);
                                                    },timerout)
                                                }

                                            },delayout);

                                        }

                                    }

                                }


                            break;

                            case "click":


                                Trigger[trs].addEventListener("click", event =>{ makefx_click() },true);

                                let makefx_click = () => {


                                    for (let i = 0; i < Target.length; i++)
                                    {

                                        if(!Target[i].className.match('fx-active'))
                                        {

                                            setTimeout(()=>{

                                            Target[i].classList.add('fx-active',cssin);
                                            Target[i].classList.remove('fx-off',cssout);

                                            setTimeout(()=>{

                                                    if(reset)
                                                    {
                                                        Target[i].classList.remove('fx-active',cssin);
                                                    }

                                                },timerin)

                                            },delayin);

                                        }

                                        if(Target[i].className.match('fx-active') && toggle === true)
                                        {

                                            setTimeout(()=>{

                                                Target[i].classList.add('fx-off',cssout);
                                                Target[i].classList.remove('fx-active',cssin);

                                                if(reset)
                                                {
                                                    setTimeout(()=>{
                                                        Target[i].classList.remove('fx-off',cssout);
                                                    },timerout)
                                                }

                                            },delayout);

                                        }

                                    }

                                }

                            break;

                        }

                    }

                }

            }

        }



    //--------------------------------------------------//



        window.onunload = () => { lazyloader();  null; };

        document.addEventListener('DOMContentLoaded', 
        () => {

            lazyloader();
            tagcode();
            nomobar();
            modeapp();
            buttons();
            absolute();
            checkscrollersize();
            standardscroll();
            snapscroll();
            anchors();
            expansivecard();
            tabx();
            taby();
            spoilers();
            videos();
            grabs();
            grid_y(); 

        },false);

        window.addEventListener('load',(
        eventDone( () => {

            outbox();
            parallax();
            autocrop();
            fitheight();
            fitup();
            flange();
            unloader();
            checkLessJs();
            effectors();

        })),false);

        document.addEventListener('change',(
        eventDone( () => {

            outbox();

        })),false);


        window.addEventListener('resize',(
        eventDone( () => {

            grid_y();
            fitheight();
            fitup();
            expansivecard();
            videos();
            autocrop();
            flange();
            parallax();
            checkscrollersize();

        })),false);

        window.onresize = () =>{ nomobar(); }



    //--------------------------------------------------//



        function reload(fn)
        {

            if     (fn == 'condingtag')     tagcode();
            else if(fn == 'absolute')       absolute();
            else if(fn == 'checksize')      checkscrollersize();
            else if(fn == 'scrollers')      standardscroll();
            else if(fn == 'snaps')          snapscroll();
            else if(fn == 'anchors')        anchors();
            else if(fn == 'buttons')        buttons();
            else if(fn == 'fileloader')     fileloader();
            else if(fn == 'effectors')      grabs();
            else if(fn == 'cards')          expansivecard();
            else if(fn == 'tab-x')          tabx();
            else if(fn == 'tab-y')          taby();
            else if(fn == 'spoilers')       spoilers();
            else if(fn == 'video')          videos();
            else if(fn == 'grid-y')         grid_y(); 
            else if(fn == 'outboxes')       outbox();
            else if(fn == 'parallax')       parallax();
            else if(fn == 'autocrop')       autocrop();
            else if(fn == 'fitheight')      fitheight();
            else if(fn == 'fitup')          fitup();
            else if(fn == 'flanges')        flange();
            else if(fn == 'effectors')      effectors();
            else debug(`:: [⚠ ui alert]: wrong reload\n   ⮑ The name "`+fn+`" is not valid!\n      Actual valid names: https://git.io/vldt456`);
            //condingtag, absolute, checksize, scrollers, snaps, anchors, cards, tab-x, tab-y, spoilers, video, grid-y, buttons, outboxes, parallax, autocrop, fitheight, fitup, flanges, effectors
        }

        return { reload: reload };


})();
