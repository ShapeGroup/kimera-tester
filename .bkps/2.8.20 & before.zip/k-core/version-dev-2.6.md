
## 2.6.beta [<b>Release Notes</b>]
___

#### to do:



#### <b>BugFix:</b>

- other little fixing;

#### <b>Upgrades:</b>

- introduced float-group and auto clear fix.

- /!\ IMPORTANT update \n
  Update vieport - now "model"; --> read wiki on [Link]
- /!\ IMPORTANT update \n
  Span changed on layout: span now make a perfect inlined element (but remove the line-height, for restore that use div inside span) --> read wiki on [Link];
- introduced viewon-[on-off-off] for hide show elements on media query cuts... litterally: view on [ mobile - desktop - bigscreen ].


#### <b>Ui system:</b>



#### <b>Extra:</b>


```
https://github.com/ShapeGroup/kimera-frontend-framework
```

___
_Please! Create Issue for debug!_
